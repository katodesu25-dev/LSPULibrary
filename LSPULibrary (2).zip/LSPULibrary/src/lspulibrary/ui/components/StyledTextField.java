package lspulibrary.ui.components;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import lspulibrary.ui.Theme;

public class StyledTextField extends JTextField {
    private static final long serialVersionUID = 1L;
    private final String placeholder;
    private final boolean searchStyle;

    public StyledTextField(int columns, String placeholder) {
        this(columns, placeholder, false);
    }

    public StyledTextField(int columns, String placeholder, boolean searchStyle) {
        super(columns);
        this.placeholder = placeholder;
        this.searchStyle = searchStyle;
        setOpaque(false);
        setFont(Theme.regular(13));
        setForeground(Theme.TEXT_STRONG);
        setCaretColor(Theme.NAVY);
        setSelectionColor(Theme.ROW_SELECTED);
        setBorder(new EmptyBorder(9, searchStyle ? 36 : 12, 9, 12));
        addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        FieldPainter.paintBackground(g2, this, isFocusOwner(), isEnabled());
        if (searchStyle) {
            FieldPainter.paintSearchIcon(g2, this);
        }
        FieldPainter.paintPlaceholder(g2, this, placeholder, searchStyle);
        g2.dispose();
        super.paintComponent(g);
    }
}
