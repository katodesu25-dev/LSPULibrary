package lspulibrary.ui.components;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Theme;

public class ModernButton extends JButton {
    private static final long serialVersionUID = 1L;

    public enum Style { PRIMARY, SECONDARY, OUTLINE, DANGER, GHOST }

    private final Style style;

    public ModernButton(String text, Style style) {
        this(text, style, null);
    }

    public ModernButton(String text, Style style, String iconName) {
        super(text);
        this.style = style;
        setFont(Theme.bold(13));
        setForeground(textColor());
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setOpaque(false);
        setRolloverEnabled(true);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setBorder(new EmptyBorder(9, 16, 9, 16));
        setIconTextGap(8);
        if (iconName != null) {
            setIcon(Icons.icon(iconName, 16, textColor()));
        }
    }

    private Color textColor() {
        switch (style) {
            case PRIMARY:
                return Theme.NAVY;
            case SECONDARY:
            case DANGER:
                return Theme.WHITE;
            case GHOST:
                return Theme.NAVY_LIGHT;
            default:
                return Theme.TEXT_STRONG;
        }
    }

    private Color background() {
        boolean pressed = getModel().isPressed();
        boolean hover = getModel().isRollover();
        switch (style) {
            case PRIMARY:
                return pressed ? new Color(0xC99700) : hover ? Theme.GOLD_DARK : Theme.GOLD;
            case SECONDARY:
                return pressed ? Theme.NAVY : hover ? Theme.NAVY_LIGHT : Theme.NAVY_HOVER;
            case DANGER:
                return pressed ? new Color(0x991B1B) : hover ? new Color(0xB91C1C) : Theme.DANGER;
            case GHOST:
                return pressed ? new Color(0xE5E7EB) : hover ? new Color(0xF1F5F9) : Theme.alpha(Theme.WHITE, 0);
            default:
                return pressed ? new Color(0xE5E7EB) : hover ? new Color(0xF3F4F6) : Theme.WHITE;
        }
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        return new Dimension(d.width, Math.max(d.height, 38));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();
        if (!isEnabled()) {
            g2.setColor(new Color(0xE5E7EB));
            g2.fillRoundRect(0, 0, w, h, 12, 12);
            setForeground(new Color(0x9CA3AF));
        } else {
            setForeground(textColor());
            g2.setColor(background());
            g2.fillRoundRect(0, 0, w, h, 12, 12);
            if (style == Style.OUTLINE) {
                g2.setColor(Theme.BORDER);
                g2.drawRoundRect(0, 0, w - 1, h - 1, 12, 12);
            }
        }
        g2.dispose();
        super.paintComponent(g);
    }
}
