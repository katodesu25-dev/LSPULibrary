package lspulibrary.ui.components;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JComponent;
import lspulibrary.ui.Theme;

public class DonutChart extends JComponent {
    private static final long serialVersionUID = 1L;
    private Map<String, Integer> data = new LinkedHashMap<>();
    private Color[] colors;
    private String centerCaption = "";

    public DonutChart(Color... colors) {
        this.colors = colors;
        setOpaque(false);
        setPreferredSize(new Dimension(300, 190));
    }

    @Override
    public Dimension getMinimumSize() {
        return getPreferredSize();
    }

    public void setData(Map<String, Integer> data, String centerCaption) {
        this.data = data;
        this.centerCaption = centerCaption;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int total = 0;
        for (int v : data.values()) {
            total += v;
        }
        int diameter = Math.min(getHeight() - 10, (int) (getWidth() * 0.5));
        diameter = Math.max(diameter, 60);
        int x = 8;
        int y = (getHeight() - diameter) / 2;
        float stroke = Math.max(14f, diameter * 0.17f);
        g2.setStroke(new BasicStroke(stroke, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND));
        double inset = stroke / 2;
        double size = diameter - stroke;

        g2.setColor(new Color(0xF1F5F9));
        g2.draw(new Arc2D.Double(x + inset, y + inset, size, size, 0, 360, Arc2D.OPEN));
        if (total > 0) {
            double start = 90;
            int i = 0;
            for (Map.Entry<String, Integer> e : data.entrySet()) {
                double extent = -360.0 * e.getValue() / total;
                if (e.getValue() > 0) {
                    g2.setColor(colors[i % colors.length]);
                    g2.draw(new Arc2D.Double(x + inset, y + inset, size, size, start, extent, Arc2D.OPEN));
                }
                start += extent;
                i++;
            }
        }

        g2.setFont(Theme.bold(22));
        FontMetrics fm = g2.getFontMetrics();
        g2.setColor(Theme.NAVY);
        String totalText = String.valueOf(total);
        g2.drawString(totalText, x + (diameter - fm.stringWidth(totalText)) / 2, y + diameter / 2 + 2);
        g2.setFont(Theme.regular(11));
        fm = g2.getFontMetrics();
        g2.setColor(Theme.MUTED);
        g2.drawString(centerCaption, x + (diameter - fm.stringWidth(centerCaption)) / 2, y + diameter / 2 + 18);

        int legendX = x + diameter + 24;
        int rowHeight = 26;
        int legendY = (getHeight() - data.size() * rowHeight) / 2;
        int i = 0;
        for (Map.Entry<String, Integer> e : data.entrySet()) {
            int ly = legendY + i * rowHeight;
            g2.setColor(colors[i % colors.length]);
            g2.fillRoundRect(legendX, ly + 6, 12, 12, 4, 4);
            g2.setFont(Theme.regular(12));
            g2.setColor(Theme.TEXT);
            g2.drawString(e.getKey(), legendX + 20, ly + 16);
            g2.setFont(Theme.bold(12));
            g2.setColor(Theme.TEXT_STRONG);
            String value = String.valueOf(e.getValue());
            g2.drawString(value, getWidth() - 12 - g2.getFontMetrics().stringWidth(value), ly + 16);
            i++;
        }
        g2.dispose();
    }
}
