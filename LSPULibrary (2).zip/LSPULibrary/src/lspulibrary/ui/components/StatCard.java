package lspulibrary.ui.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Theme;

public class StatCard extends RoundedPanel {
    private static final long serialVersionUID = 1L;
    private final JLabel valueLabel = new JLabel("0");
    private final JLabel captionLabel = new JLabel();
    private final JLabel noteLabel = new JLabel(" ");

    public StatCard(String caption, String iconName, Color accent) {
        super(16, Theme.WHITE, Theme.BORDER, true);
        setLayout(new BorderLayout(0, 2));
        setBorder(BorderFactory.createEmptyBorder(14, 16, 18, 14));

        JComponent badge = new JComponent() {
            private static final long serialVersionUID = 1L;

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(40, 40);
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.alpha(accent, 32));
                g2.fillOval(0, 0, 40, 40);
                Icons.paint((Graphics2D) g2.create(9, 9, 22, 22), iconName, 22, accent);
                g2.dispose();
            }
        };
        JPanel badgeHolder = new JPanel(new BorderLayout());
        badgeHolder.setOpaque(false);
        badgeHolder.add(badge, BorderLayout.NORTH);

        valueLabel.setFont(Theme.bold(26));
        valueLabel.setForeground(Theme.NAVY);
        captionLabel.setText(caption);
        captionLabel.setFont(Theme.bold(12));
        captionLabel.setForeground(Theme.TEXT);
        noteLabel.setFont(Theme.regular(11));
        noteLabel.setForeground(Theme.MUTED);

        JPanel middle = new JPanel(new BorderLayout());
        middle.setOpaque(false);
        middle.add(valueLabel, BorderLayout.CENTER);
        middle.add(badgeHolder, BorderLayout.EAST);

        add(captionLabel, BorderLayout.NORTH);
        add(middle, BorderLayout.CENTER);
        add(noteLabel, BorderLayout.SOUTH);
    }

    public void setValue(String value) {
        valueLabel.setText(value);
    }

    public void setNote(String note) {
        noteLabel.setText(note == null || note.isEmpty() ? " " : note);
    }
}
