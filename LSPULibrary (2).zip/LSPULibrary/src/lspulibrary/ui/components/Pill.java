package lspulibrary.ui.components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JComponent;
import lspulibrary.ui.Theme;

public class Pill extends JComponent {
    private static final long serialVersionUID = 1L;
    private String text = "";
    private Color color = Theme.MUTED;

    public Pill() {
        setOpaque(false);
    }

    public void setPill(String text, Color color) {
        this.text = text;
        this.color = color;
        revalidate();
        repaint();
    }

    @Override
    public Dimension getPreferredSize() {
        FontMetrics fm = getFontMetrics(Theme.bold(12));
        return new Dimension(fm.stringWidth(text) + 24, 26);
    }

    @Override
    protected void paintComponent(Graphics g) {
        if (text.isEmpty()) {
            return;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setColor(Theme.alpha(color, 30));
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
        g2.setColor(color);
        g2.setFont(Theme.bold(12));
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(text, (getWidth() - fm.stringWidth(text)) / 2, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
        g2.dispose();
    }
}
