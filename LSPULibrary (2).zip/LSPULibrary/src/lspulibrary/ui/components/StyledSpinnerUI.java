package lspulibrary.ui.components;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JSpinner;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicSpinnerUI;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Theme;

public class StyledSpinnerUI extends BasicSpinnerUI {
    private JButton arrow(boolean up) {
        JButton button = new JButton() {
            private static final long serialVersionUID = 1L;

            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover()) {
                    g2.setColor(new java.awt.Color(0xF3F4F6));
                    g2.fillRect(0, 0, getWidth(), getHeight());
                }
                int size = 12;
                g2.translate((getWidth() - size) / 2.0, (getHeight() - size) / 2.0);
                if (up) {
                    g2.rotate(Math.PI, size / 2.0, size / 2.0);
                }
                Icons.paint(g2, Icons.CHEVRON, size, Theme.MUTED);
                g2.dispose();
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(24, 12);
            }
        };
        button.setBorder(null);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setRolloverEnabled(true);
        return button;
    }

    @Override
    protected Component createNextButton() {
        JButton b = arrow(true);
        installNextButtonListeners(b);
        return b;
    }

    @Override
    protected Component createPreviousButton() {
        JButton b = arrow(false);
        installPreviousButtonListeners(b);
        return b;
    }

    public static void install(JSpinner spinner) {
        spinner.setUI(new StyledSpinnerUI());
        spinner.setBackground(Theme.WHITE);
        JComponent editor = spinner.getEditor();
        if (editor instanceof JSpinner.DefaultEditor) {
            javax.swing.JFormattedTextField field = ((JSpinner.DefaultEditor) editor).getTextField();
            field.setBorder(new EmptyBorder(0, 4, 0, 4));
            field.setBackground(Theme.WHITE);
            field.setFont(Theme.regular(13));
        }
    }
}
