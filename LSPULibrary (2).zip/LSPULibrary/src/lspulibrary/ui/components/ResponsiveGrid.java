package lspulibrary.ui.components;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;

public class ResponsiveGrid implements LayoutManager {
    private final int minCellWidth;
    private final int hgap;
    private final int vgap;
    private final int maxColumns;

    public ResponsiveGrid(int minCellWidth, int hgap, int vgap, int maxColumns) {
        this.minCellWidth = minCellWidth;
        this.hgap = hgap;
        this.vgap = vgap;
        this.maxColumns = maxColumns;
    }

    private int availableWidth(Container parent) {
        Container outer = parent.getParent();
        int width = outer != null && outer.getWidth() > 0 ? outer.getWidth() : parent.getWidth();
        return width > 0 ? width : 1000;
    }

    private int columns(Container parent) {
        int n = parent.getComponentCount();
        if (n == 0) {
            return 1;
        }
        int max = Math.max(1, Math.min(maxColumns, (availableWidth(parent) + hgap) / (minCellWidth + hgap)));
        int rows = (int) Math.ceil(n / (double) max);
        return (int) Math.ceil(n / (double) rows);
    }

    @Override
    public void addLayoutComponent(String name, Component comp) {
    }

    @Override
    public void removeLayoutComponent(Component comp) {
    }

    @Override
    public Dimension preferredLayoutSize(Container parent) {
        int n = parent.getComponentCount();
        int cols = columns(parent);
        int rows = (int) Math.ceil(n / (double) cols);
        int cellH = 0;
        int cellW = 0;
        for (Component c : parent.getComponents()) {
            Dimension d = c.getPreferredSize();
            cellH = Math.max(cellH, d.height);
            cellW = Math.max(cellW, d.width);
        }
        Insets in = parent.getInsets();
        return new Dimension(in.left + in.right + cols * cellW + (cols - 1) * hgap,
                in.top + in.bottom + rows * cellH + Math.max(0, rows - 1) * vgap);
    }

    @Override
    public Dimension minimumLayoutSize(Container parent) {
        Dimension d = preferredLayoutSize(parent);
        return new Dimension(minCellWidth, d.height);
    }

    @Override
    public void layoutContainer(Container parent) {
        int n = parent.getComponentCount();
        if (n == 0) {
            return;
        }
        int cols = columns(parent);
        int rows = (int) Math.ceil(n / (double) cols);
        Insets in = parent.getInsets();
        int width = parent.getWidth() - in.left - in.right;
        int height = parent.getHeight() - in.top - in.bottom;
        int cellW = (width - (cols - 1) * hgap) / cols;
        int cellH = (height - (rows - 1) * vgap) / rows;
        for (int i = 0; i < n; i++) {
            int r = i / cols;
            int c = i % cols;
            parent.getComponent(i).setBounds(in.left + c * (cellW + hgap), in.top + r * (cellH + vgap), cellW, cellH);
        }
    }
}
