package lspulibrary.ui.components;

import javax.swing.table.DefaultTableModel;

public class ReadOnlyTableModel extends DefaultTableModel {
    private static final long serialVersionUID = 1L;
    private final Class<?>[] types;

    public ReadOnlyTableModel(String[] columns, Class<?>[] types) {
        super(columns, 0);
        this.types = types;
    }

    @Override
    public boolean isCellEditable(int row, int column) {
        return false;
    }

    @Override
    public Class<?> getColumnClass(int column) {
        return types[column];
    }
}
