package lspulibrary.ui.components;

public final class TableActions {
    private final String[] labels;

    public TableActions(String... labels) {
        this.labels = labels;
    }

    public String[] getLabels() {
        return labels;
    }

    @Override
    public String toString() {
        return String.join(" ", labels);
    }
}
