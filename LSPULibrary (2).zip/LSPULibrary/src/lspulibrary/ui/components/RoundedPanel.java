package lspulibrary.ui.components;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import lspulibrary.ui.Theme;

public class RoundedPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private final int radius;
    private final Color fill;
    private final Color outline;
    private final boolean shadow;

    public RoundedPanel(int radius, Color fill, Color outline, boolean shadow) {
        this.radius = radius;
        this.fill = fill;
        this.outline = outline;
        this.shadow = shadow;
        setOpaque(false);
    }

    public static RoundedPanel card(LayoutManager layout, int padding) {
        RoundedPanel panel = new RoundedPanel(16, Theme.WHITE, Theme.BORDER, true);
        panel.setLayout(layout);
        panel.setBorder(new EmptyBorder(padding, padding + 2, padding + 4, padding + 2));
        return panel;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();
        int bottom = shadow ? 4 : 1;
        if (shadow) {
            g2.setColor(new Color(15, 23, 42, 10));
            g2.fillRoundRect(0, 3, w, h - 3, radius + 2, radius + 2);
            g2.setColor(new Color(15, 23, 42, 12));
            g2.fillRoundRect(1, 2, w - 2, h - 4, radius + 1, radius + 1);
        }
        g2.setColor(fill);
        g2.fillRoundRect(0, 0, w - 1, h - bottom, radius, radius);
        if (outline != null) {
            g2.setColor(outline);
            g2.drawRoundRect(0, 0, w - 1, h - bottom - 1, radius, radius);
        }
        g2.dispose();
        super.paintComponent(g);
    }
}
