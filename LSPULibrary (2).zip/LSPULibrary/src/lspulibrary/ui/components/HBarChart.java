package lspulibrary.ui.components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.JComponent;
import lspulibrary.ui.Theme;

public class HBarChart extends JComponent {
    private static final long serialVersionUID = 1L;
    private List<Map.Entry<String, Integer>> entries = new ArrayList<>();
    private final Color barColor;
    private final int rowHeight;

    public HBarChart(Color barColor, int rowHeight) {
        this.barColor = barColor;
        this.rowHeight = rowHeight;
        setOpaque(false);
        setPreferredSize(new Dimension(300, 120));
    }

    @Override
    public Dimension getMinimumSize() {
        return getPreferredSize();
    }

    public void setData(List<Map.Entry<String, Integer>> entries) {
        this.entries = entries;
        setPreferredSize(new Dimension(300, Math.max(70, entries.size() * rowHeight + 8)));
        revalidate();
        repaint();
    }

    private static String fit(String text, FontMetrics fm, int width) {
        if (fm.stringWidth(text) <= width) {
            return text;
        }
        String cut = text;
        while (cut.length() > 1 && fm.stringWidth(cut + "...") > width) {
            cut = cut.substring(0, cut.length() - 1);
        }
        return cut.trim() + "...";
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setFont(Theme.regular(12));
        FontMetrics fm = g2.getFontMetrics();
        if (entries.isEmpty()) {
            g2.setColor(Theme.MUTED);
            String msg = "No data yet";
            g2.drawString(msg, (getWidth() - fm.stringWidth(msg)) / 2, getHeight() / 2);
            g2.dispose();
            return;
        }
        int max = 1;
        for (Map.Entry<String, Integer> e : entries) {
            max = Math.max(max, e.getValue());
        }
        int labelWidth = Math.min(getWidth() / 2, 170);
        int valueWidth = 34;
        int barArea = Math.max(20, getWidth() - labelWidth - valueWidth - 16);
        int y = 4;
        for (Map.Entry<String, Integer> e : entries) {
            g2.setColor(Theme.TEXT);
            g2.drawString(fit(e.getKey(), fm, labelWidth - 8), 0, y + (rowHeight - 6) / 2 + fm.getAscent() / 2);
            int barHeight = 12;
            int by = y + (rowHeight - 6 - barHeight) / 2;
            g2.setColor(new Color(0xF1F5F9));
            g2.fillRoundRect(labelWidth, by, barArea, barHeight, barHeight, barHeight);
            int w = Math.max(barHeight, (int) Math.round(barArea * e.getValue() / (double) max));
            g2.setColor(barColor);
            g2.fillRoundRect(labelWidth, by, w, barHeight, barHeight, barHeight);
            g2.setColor(Theme.TEXT_STRONG);
            g2.setFont(Theme.bold(12));
            g2.drawString(String.valueOf(e.getValue()), labelWidth + barArea + 10,
                    y + (rowHeight - 6) / 2 + fm.getAscent() / 2);
            g2.setFont(Theme.regular(12));
            y += rowHeight;
        }
        g2.dispose();
    }
}
