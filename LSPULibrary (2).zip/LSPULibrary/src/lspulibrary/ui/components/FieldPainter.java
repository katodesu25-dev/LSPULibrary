package lspulibrary.ui.components;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JComponent;
import javax.swing.text.JTextComponent;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Theme;

final class FieldPainter {
    private FieldPainter() {
    }

    static void paintBackground(Graphics2D g2, JComponent c, boolean focused, boolean enabled) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(enabled ? Theme.WHITE : new Color(0xF3F4F6));
        g2.fillRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 12, 12);
        g2.setColor(focused ? Theme.GOLD_DARK : Theme.BORDER);
        g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 12, 12);
        if (focused) {
            g2.setColor(Theme.alpha(Theme.GOLD, 70));
            g2.drawRoundRect(1, 1, c.getWidth() - 3, c.getHeight() - 3, 10, 10);
        }
    }

    static void paintPlaceholder(Graphics2D g2, JTextComponent c, String placeholder, boolean hasIcon) {
        if (placeholder == null || placeholder.isEmpty() || c.getText().length() > 0) {
            return;
        }
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setColor(new Color(0x9CA3AF));
        g2.setFont(c.getFont());
        FontMetrics fm = g2.getFontMetrics();
        int x = c.getInsets().left;
        int y = (c.getHeight() - fm.getHeight()) / 2 + fm.getAscent();
        g2.drawString(placeholder, x, y);
    }

    static void paintSearchIcon(Graphics2D g2, JComponent c) {
        Icons.paint((Graphics2D) g2.create(10, (c.getHeight() - 16) / 2, 16, 16), Icons.SEARCH, 16, new Color(0x9CA3AF));
    }
}
