package lspulibrary.ui.components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComponent;
import lspulibrary.ui.Theme;

public class BarChart extends JComponent {
    private static final long serialVersionUID = 1L;
    private List<String> labels = new ArrayList<>();
    private String[] seriesNames = new String[0];
    private double[][] values = new double[0][0];
    private Color[] colors = {Theme.GOLD, Theme.NAVY};

    public BarChart() {
        setOpaque(false);
        setPreferredSize(new Dimension(300, 220));
    }

    @Override
    public Dimension getMinimumSize() {
        return getPreferredSize();
    }

    public void setData(List<String> labels, String[] seriesNames, double[][] values) {
        this.labels = labels;
        this.seriesNames = seriesNames;
        this.values = values;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        double max = 0;
        for (double[] series : values) {
            for (double v : series) {
                max = Math.max(max, v);
            }
        }
        if (labels.isEmpty() || max <= 0) {
            g2.setFont(Theme.regular(13));
            g2.setColor(Theme.MUTED);
            String msg = "No activity to display yet";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(msg, (getWidth() - fm.stringWidth(msg)) / 2, getHeight() / 2);
            g2.dispose();
            return;
        }

        int steps = (int) Math.max(1, Math.min(5, Math.ceil(max)));
        double top = Math.ceil(max / steps) * steps;
        int legendHeight = seriesNames.length > 1 ? 24 : 0;
        int left = 34;
        int bottom = 26;
        int chartTop = 8 + legendHeight;
        int chartHeight = getHeight() - chartTop - bottom;
        int chartWidth = getWidth() - left - 8;

        g2.setFont(Theme.regular(11));
        FontMetrics fm = g2.getFontMetrics();
        for (int i = 0; i <= steps; i++) {
            int y = chartTop + chartHeight - (int) (chartHeight * i / (double) steps);
            g2.setColor(new Color(0xEEF0F3));
            g2.drawLine(left, y, left + chartWidth, y);
            g2.setColor(Theme.MUTED);
            String label = String.valueOf((int) Math.round(top * i / steps));
            g2.drawString(label, left - 8 - fm.stringWidth(label), y + fm.getAscent() / 2 - 1);
        }

        int groups = labels.size();
        double groupWidth = chartWidth / (double) groups;
        int seriesCount = values.length;
        double barWidth = Math.min(28, groupWidth * 0.7 / seriesCount);
        for (int i = 0; i < groups; i++) {
            double groupStart = left + i * groupWidth + (groupWidth - barWidth * seriesCount - (seriesCount - 1) * 3) / 2;
            for (int s = 0; s < seriesCount; s++) {
                double v = values[s][i];
                int h = (int) Math.round(chartHeight * v / top);
                int x = (int) Math.round(groupStart + s * (barWidth + 3));
                int y = chartTop + chartHeight - h;
                if (v > 0) {
                    g2.setColor(colors[s % colors.length]);
                    g2.fillRoundRect(x, y, (int) barWidth, h + 4, 8, 8);
                    g2.setColor(Theme.WHITE);
                    g2.fillRect(x - 1, chartTop + chartHeight, (int) barWidth + 2, 6);
                    if (seriesCount == 1 || barWidth > 16) {
                        g2.setColor(Theme.TEXT);
                        String text = String.valueOf((int) v);
                        g2.drawString(text, x + ((int) barWidth - fm.stringWidth(text)) / 2, y - 4);
                    }
                }
            }
            g2.setColor(Theme.MUTED);
            String label = labels.get(i);
            g2.drawString(label, (int) (left + i * groupWidth + (groupWidth - fm.stringWidth(label)) / 2),
                    getHeight() - 8);
        }

        if (seriesNames.length > 1) {
            int x = left;
            for (int s = 0; s < seriesNames.length; s++) {
                g2.setColor(colors[s % colors.length]);
                g2.fillRoundRect(x, 6, 12, 12, 4, 4);
                g2.setColor(Theme.TEXT);
                g2.drawString(seriesNames[s], x + 18, 16);
                x += 18 + fm.stringWidth(seriesNames[s]) + 20;
            }
        }
        g2.dispose();
    }
}
