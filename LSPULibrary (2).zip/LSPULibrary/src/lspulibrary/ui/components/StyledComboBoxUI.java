package lspulibrary.ui.components;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.plaf.basic.BasicComboBoxUI;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Theme;

public class StyledComboBoxUI extends BasicComboBoxUI {
    @Override
    protected JButton createArrowButton() {
        JButton button = new JButton() {
            private static final long serialVersionUID = 1L;

            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Icons.paint((Graphics2D) g2.create((getWidth() - 14) / 2, (getHeight() - 14) / 2, 14, 14),
                        Icons.CHEVRON, 14, Theme.MUTED);
                g2.dispose();
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(28, 28);
            }
        };
        button.setBorder(null);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        return button;
    }

    @Override
    public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
        g.setColor(Theme.WHITE);
        g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
    }

    public static void install(JComboBox<?> combo) {
        combo.setUI(new StyledComboBoxUI());
        combo.setFont(Theme.regular(13));
        combo.setBackground(Theme.WHITE);
        combo.setForeground(Theme.TEXT_STRONG);
        combo.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.LineBorder(Theme.BORDER, 1, true),
                new javax.swing.border.EmptyBorder(4, 8, 4, 2)));
        combo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            private static final long serialVersionUID = 1L;

            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                setBorder(new javax.swing.border.EmptyBorder(6, 10, 6, 10));
                setFont(Theme.regular(13));
                setBackground(isSelected ? Theme.ROW_SELECTED : Theme.WHITE);
                setForeground(Theme.TEXT_STRONG);
                return this;
            }
        });
        combo.setPreferredSize(new Dimension(Math.max(combo.getPreferredSize().width, 140), 38));
    }
}
