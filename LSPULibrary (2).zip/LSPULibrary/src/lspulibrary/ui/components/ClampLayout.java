package lspulibrary.ui.components;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;

public class ClampLayout implements LayoutManager {
    private final int maxWidth;

    public ClampLayout(int maxWidth) {
        this.maxWidth = maxWidth;
    }

    @Override
    public void addLayoutComponent(String name, Component comp) {
    }

    @Override
    public void removeLayoutComponent(Component comp) {
    }

    @Override
    public Dimension preferredLayoutSize(Container parent) {
        Dimension d = parent.getComponentCount() > 0 ? parent.getComponent(0).getPreferredSize() : new Dimension();
        return new Dimension(Math.min(maxWidth, d.width), d.height);
    }

    @Override
    public Dimension minimumLayoutSize(Container parent) {
        Dimension d = parent.getComponentCount() > 0 ? parent.getComponent(0).getMinimumSize() : new Dimension();
        return new Dimension(d.width, d.height);
    }

    @Override
    public void layoutContainer(Container parent) {
        if (parent.getComponentCount() == 0) {
            return;
        }
        Component c = parent.getComponent(0);
        int h = c.getPreferredSize().height;
        int w = Math.min(maxWidth, parent.getWidth());
        c.setBounds((parent.getWidth() - w) / 2, (parent.getHeight() - h) / 2, w, h);
    }
}
