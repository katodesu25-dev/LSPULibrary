package lspulibrary.ui.components;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import lspulibrary.ui.Theme;

public class StyledPasswordField extends JPasswordField {
    private static final long serialVersionUID = 1L;
    private final String placeholder;

    public StyledPasswordField(int columns, String placeholder) {
        super(columns);
        this.placeholder = placeholder;
        setOpaque(false);
        setFont(Theme.regular(13));
        setForeground(Theme.TEXT_STRONG);
        setCaretColor(Theme.NAVY);
        setBorder(new EmptyBorder(9, 12, 9, 12));
        addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        FieldPainter.paintBackground(g2, this, isFocusOwner(), isEnabled());
        FieldPainter.paintPlaceholder(g2, this, placeholder, false);
        g2.dispose();
        super.paintComponent(g);
    }
}
