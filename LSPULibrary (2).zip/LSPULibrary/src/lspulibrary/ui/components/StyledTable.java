package lspulibrary.ui.components;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import lspulibrary.ui.Theme;
import lspulibrary.util.Format;

public class StyledTable extends JTable {
    private static final long serialVersionUID = 1L;

    public interface ActionHandler {
        void onAction(String label, int modelRow);
    }

    public interface RowHandler {
        void onRow(int modelRow);
    }

    private final ReadOnlyTableModel tableModel;
    private final TableRowSorter<ReadOnlyTableModel> sorter;
    private final Set<Integer> pillColumns = new HashSet<>();
    private int actionColumn = -1;
    private ActionHandler actionHandler;
    private RowHandler doubleClickHandler;

    public StyledTable(ReadOnlyTableModel model) {
        super(model);
        this.tableModel = model;
        this.sorter = new TableRowSorter<>(model);
        setRowSorter(sorter);
        setRowHeight(42);
        setShowGrid(false);
        setIntercellSpacing(new Dimension(0, 0));
        setFont(Theme.regular(13));
        setForeground(Theme.TEXT);
        setSelectionBackground(Theme.ROW_SELECTED);
        setSelectionForeground(Theme.TEXT_STRONG);
        setFillsViewportHeight(true);
        setBackground(Theme.WHITE);
        setFocusable(true);
        setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
        getTableHeader().setReorderingAllowed(false);
        getTableHeader().setDefaultRenderer(new HeaderRenderer());
        getTableHeader().setPreferredSize(new Dimension(100, 40));
        setDefaultRenderer(Object.class, new TextRenderer());
        setDefaultRenderer(String.class, new TextRenderer());
        setDefaultRenderer(Integer.class, new TextRenderer());
        setDefaultRenderer(Double.class, new TextRenderer());
        setDefaultRenderer(LocalDateTime.class, new TextRenderer());
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleClick(e);
            }
        });
        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(actionAt(e.getPoint()) != null
                        ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
            }
        });
    }

    public ReadOnlyTableModel getTableModel() {
        return tableModel;
    }

    public TableRowSorter<ReadOnlyTableModel> getSorter() {
        return sorter;
    }

    public void setPillColumn(int column) {
        pillColumns.add(column);
        getColumnModel().getColumn(column).setCellRenderer(new PillRenderer());
    }

    public void setActionColumn(int column, ActionHandler handler) {
        this.actionColumn = column;
        this.actionHandler = handler;
        getColumnModel().getColumn(column).setCellRenderer(new ActionsRenderer());
        sorter.setSortable(column, false);
    }

    public void setDoubleClickHandler(RowHandler handler) {
        this.doubleClickHandler = handler;
    }

    public void setColumnWidths(int... widths) {
        for (int i = 0; i < widths.length && i < getColumnCount(); i++) {
            TableColumn col = getColumnModel().getColumn(i);
            col.setPreferredWidth(widths[i]);
            col.setMinWidth(Math.min(widths[i], 56));
        }
    }

    public int selectedModelRow() {
        int row = getSelectedRow();
        return row < 0 ? -1 : convertRowIndexToModel(row);
    }

    @Override
    public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
        Component c = super.prepareRenderer(renderer, row, column);
        if (isRowSelected(row)) {
            c.setBackground(Theme.ROW_SELECTED);
        } else {
            c.setBackground(row % 2 == 0 ? Theme.WHITE : Theme.ROW_ALT);
        }
        return c;
    }

    private static int[][] layoutActions(FontMetrics fm, String[] labels) {
        int[][] zones = new int[labels.length][2];
        int x = 8;
        for (int i = 0; i < labels.length; i++) {
            int w = fm.stringWidth(labels[i]) + 18;
            zones[i][0] = x;
            zones[i][1] = w;
            x += w + 6;
        }
        return zones;
    }

    private static Color actionColor(String label) {
        switch (label) {
            case "Delete":
                return Theme.DANGER;
            case "Edit":
                return Theme.INFO;
            case "Return":
            case "Activate":
                return Theme.SUCCESS;
            case "Deactivate":
                return Theme.WARNING;
            default:
                return Theme.NAVY_LIGHT;
        }
    }

    private String actionAt(Point p) {
        if (actionColumn < 0) {
            return null;
        }
        int viewRow = rowAtPoint(p);
        int viewCol = columnAtPoint(p);
        if (viewRow < 0 || viewCol < 0 || convertColumnIndexToModel(viewCol) != actionColumn) {
            return null;
        }
        Object value = getValueAt(viewRow, viewCol);
        if (!(value instanceof TableActions)) {
            return null;
        }
        String[] labels = ((TableActions) value).getLabels();
        Rectangle cell = getCellRect(viewRow, viewCol, false);
        int[][] zones = layoutActions(getFontMetrics(Theme.bold(12)), labels);
        int relX = p.x - cell.x;
        for (int i = 0; i < labels.length; i++) {
            if (relX >= zones[i][0] && relX <= zones[i][0] + zones[i][1]) {
                return labels[i];
            }
        }
        return null;
    }

    private void handleClick(MouseEvent e) {
        if (e.getButton() != MouseEvent.BUTTON1) {
            return;
        }
        String action = actionAt(e.getPoint());
        int viewRow = rowAtPoint(e.getPoint());
        if (action != null && actionHandler != null && viewRow >= 0) {
            actionHandler.onAction(action, convertRowIndexToModel(viewRow));
            return;
        }
        if (e.getClickCount() == 2 && doubleClickHandler != null && viewRow >= 0) {
            doubleClickHandler.onRow(convertRowIndexToModel(viewRow));
        }
    }

    private static class HeaderRenderer extends DefaultTableCellRenderer {
        private static final long serialVersionUID = 1L;

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, false, false, row, column);
            setBackground(Theme.NAVY);
            setForeground(Theme.WHITE);
            setFont(Theme.bold(12));
            setBorder(new EmptyBorder(0, 10, 0, 10));
            setHorizontalAlignment(table.getColumnClass(column) == Integer.class
                    || table.getColumnClass(column) == Double.class ? SwingConstants.CENTER : SwingConstants.LEFT);
            JTableHeader header = table.getTableHeader();
            if (header != null && table.getRowSorter() != null) {
                java.util.List<? extends javax.swing.RowSorter.SortKey> keys = table.getRowSorter().getSortKeys();
                if (!keys.isEmpty() && keys.get(0).getColumn() == table.convertColumnIndexToModel(column)) {
                    boolean asc = keys.get(0).getSortOrder() == javax.swing.SortOrder.ASCENDING;
                    setText(value + (asc ? "  \u25B2" : "  \u25BC"));
                }
            }
            return this;
        }
    }

    private static class TextRenderer extends DefaultTableCellRenderer {
        private static final long serialVersionUID = 1L;

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            String text;
            if (value instanceof LocalDateTime) {
                text = Format.date((LocalDateTime) value);
            } else if (value instanceof Double) {
                text = Format.peso((Double) value);
            } else {
                text = value == null ? "-" : String.valueOf(value);
            }
            super.getTableCellRendererComponent(table, text, isSelected, false, row, column);
            setBorder(new EmptyBorder(0, 12, 0, 12));
            setFont(Theme.regular(13));
            boolean centered = value instanceof Integer || value instanceof Double;
            setHorizontalAlignment(centered ? SwingConstants.CENTER : SwingConstants.LEFT);
            setForeground(isSelected ? Theme.TEXT_STRONG : Theme.TEXT);
            return this;
        }
    }

    private static class PillRenderer extends JComponent implements TableCellRenderer {
        private static final long serialVersionUID = 1L;
        private String text = "";

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            text = value == null ? "" : value.toString();
            return this;
        }

        @Override
        public boolean isOpaque() {
            return true;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRect(0, 0, getWidth(), getHeight());
            if (!text.isEmpty()) {
                g2.setFont(Theme.bold(12));
                FontMetrics fm = g2.getFontMetrics();
                int w = fm.stringWidth(text) + 20;
                int h = 24;
                int x = 8;
                int y = (getHeight() - h) / 2;
                Color c = Theme.pillColor(text);
                g2.setColor(Theme.alpha(c, 28));
                g2.fillRoundRect(x, y, w, h, h, h);
                g2.setColor(c);
                g2.drawString(text, x + 10, y + (h - fm.getHeight()) / 2 + fm.getAscent());
            }
            g2.dispose();
        }
    }

    private class ActionsRenderer extends JComponent implements TableCellRenderer {
        private static final long serialVersionUID = 1L;
        private String[] labels = new String[0];

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            labels = value instanceof TableActions ? ((TableActions) value).getLabels() : new String[0];
            return this;
        }

        @Override
        public boolean isOpaque() {
            return true;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setFont(Theme.bold(12));
            FontMetrics fm = g2.getFontMetrics();
            int[][] zones = layoutActions(fm, labels);
            int h = 26;
            int y = (getHeight() - h) / 2;
            for (int i = 0; i < labels.length; i++) {
                Color c = actionColor(labels[i]);
                g2.setColor(Theme.alpha(c, 24));
                g2.fillRoundRect(zones[i][0], y, zones[i][1], h, 10, 10);
                g2.setColor(c);
                g2.drawString(labels[i], zones[i][0] + 9, y + (h - fm.getHeight()) / 2 + fm.getAscent());
            }
            g2.dispose();
        }
    }

    public static JLabel emptyLabel(String text) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(Theme.regular(13));
        label.setForeground(Theme.MUTED);
        return label;
    }
}
