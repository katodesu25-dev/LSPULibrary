package lspulibrary.ui.dialogs;

import java.time.LocalDateTime;
import java.util.List;
import lspulibrary.models.Borrowing;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.StyledTable;

public final class LoanTables {
    private LoanTables() {
    }

    public static StyledTable build(List<Borrowing> loans, boolean showBook, boolean showBorrower) {
        String subject = showBook && showBorrower ? "Book / Borrower" : showBook ? "Book" : "Borrower";
        ReadOnlyTableModel model = new ReadOnlyTableModel(
                new String[]{"ID", subject, "Borrowed", "Due", "Returned", "Status", "Fine"},
                new Class<?>[]{Integer.class, String.class, LocalDateTime.class, LocalDateTime.class,
                    LocalDateTime.class, String.class, Double.class});
        LocalDateTime now = LocalDateTime.now();
        for (Borrowing b : loans) {
            String label = showBook && showBorrower ? b.getBook().getTitle() + " - " + b.getBorrower().getName()
                    : showBook ? b.getBook().getTitle() : b.getBorrower().getName();
            model.addRow(new Object[]{b.getId(), label, b.getBorrowedAt(), b.getDueAt(), b.getReturnedAt(),
                b.statusAt(now), b.getFine()});
        }
        StyledTable table = new StyledTable(model);
        table.setPillColumn(5);
        table.setRowHeight(38);
        table.setColumnWidths(60, 220, 150, 150, 150, 100, 90);
        return table;
    }
}
