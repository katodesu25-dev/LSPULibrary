package lspulibrary.ui.dialogs;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import lspulibrary.AppContext;
import lspulibrary.members.LibraryMember;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;

public final class BorrowerDetailsDialog {
    private BorrowerDetailsDialog() {
    }

    public static void show(Component parent, AppContext ctx, Borrower borrower) {
        BaseDialog dialog = new BaseDialog(parent, borrower.getName(), "Borrower profile, active loans and history");
        List<Borrowing> all = ctx.circulation().getLoansOf(borrower);
        List<Borrowing> active = new ArrayList<>();
        for (Borrowing b : all) {
            if (!b.isReturned()) {
                active.add(b);
            }
        }
        LibraryMember member = borrower.asMember(active.size());

        JPanel info = new JPanel(new GridLayout(0, 4, 14, 10));
        info.setOpaque(false);
        info.add(InfoBlock.make("Borrower ID", String.valueOf(borrower.getId())));
        info.add(InfoBlock.make("School ID", borrower.getIdNumber()));
        info.add(InfoBlock.make("Member type", borrower.getTypeLabel()));
        info.add(InfoBlock.make("Status", borrower.isActive() ? "Active" : "Inactive"));
        info.add(InfoBlock.make("Email", borrower.getEmail().isEmpty() ? "-" : borrower.getEmail()));
        info.add(InfoBlock.make("Borrowed now", active.size() + " of " + member.getBorrowLimit()));
        info.add(InfoBlock.make("Loan period", member.getLoanDays() + " days"));
        info.add(InfoBlock.make("Fine per day", lspulibrary.util.Format.peso(member.getFinePerDay())));

        JScrollPane activeScroll = UI.scroll(LoanTables.build(active, true, false));
        activeScroll.setPreferredSize(new Dimension(780, 120));
        activeScroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        JScrollPane historyScroll = UI.scroll(LoanTables.build(all, true, false));
        historyScroll.setPreferredSize(new Dimension(780, 190));
        historyScroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER));

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(new EmptyBorder(0, 0, 8, 0));
        info.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(info);
        content.add(javax.swing.Box.createVerticalStrut(16));
        content.add(left(UI.sectionTitle("Active borrowed books (" + active.size() + ")")));
        content.add(javax.swing.Box.createVerticalStrut(6));
        content.add(left(activeScroll));
        content.add(javax.swing.Box.createVerticalStrut(14));
        content.add(left(UI.sectionTitle("Borrowing history (" + all.size() + ")")));
        content.add(javax.swing.Box.createVerticalStrut(6));
        content.add(left(historyScroll));
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(content, BorderLayout.NORTH);
        dialog.body.add(wrap);

        ModernButton close = new ModernButton("Close", ModernButton.Style.SECONDARY);
        close.addActionListener(e -> dialog.dispose());
        dialog.footer.add(close);
        dialog.open(840);
    }

    private static Component left(javax.swing.JComponent c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        return c;
    }
}
