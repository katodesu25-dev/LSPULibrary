package lspulibrary.ui.dialogs;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import lspulibrary.AppContext;
import lspulibrary.models.Book;
import lspulibrary.models.Borrowing;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.StyledTable;

public final class BookDetailsDialog {
    private BookDetailsDialog() {
    }

    public static void show(Component parent, AppContext ctx, Book book) {
        BaseDialog dialog = new BaseDialog(parent, book.getTitle(), "Book details and borrowing history");

        JPanel info = new JPanel(new GridLayout(0, 3, 14, 10));
        info.setOpaque(false);
        info.add(InfoBlock.make("Book ID", String.valueOf(book.getId())));
        info.add(InfoBlock.make("Author", book.getAuthor().isEmpty() ? "-" : book.getAuthor()));
        info.add(InfoBlock.make("Category", book.getCategory().isEmpty() ? "-" : book.getCategory()));
        info.add(InfoBlock.make("Total copies", String.valueOf(book.getTotalCopies())));
        info.add(InfoBlock.make("Available", String.valueOf(book.getAvailableCopies())));
        info.add(InfoBlock.make("On loan", String.valueOf(book.getBorrowedCopies())));

        List<Borrowing> history = new ArrayList<>();
        for (Borrowing b : ctx.circulation().getBorrowings()) {
            if (b.getBook().getId() == book.getId()) {
                history.add(b);
            }
        }
        StyledTable table = LoanTables.build(history, false, true);
        var scroll = UI.scroll(table);
        scroll.setPreferredSize(new Dimension(760, 220));
        scroll.setBorder(javax.swing.BorderFactory.createLineBorder(Theme.BORDER));

        JPanel center = new JPanel(new BorderLayout(0, 10));
        center.setOpaque(false);
        center.setBorder(new EmptyBorder(0, 0, 10, 0));
        JPanel top = new JPanel(new BorderLayout(0, 14));
        top.setOpaque(false);
        top.add(info, BorderLayout.NORTH);
        top.add(UI.sectionTitle("Borrowing history (" + history.size() + ")"), BorderLayout.SOUTH);
        center.add(top, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);
        dialog.body.add(center);

        ModernButton close = new ModernButton("Close", ModernButton.Style.SECONDARY);
        close.addActionListener(e -> dialog.dispose());
        dialog.footer.add(close);
        dialog.open(820);
    }
}
