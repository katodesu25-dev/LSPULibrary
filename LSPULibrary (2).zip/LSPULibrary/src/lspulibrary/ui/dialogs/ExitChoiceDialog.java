package lspulibrary.ui.dialogs;

import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;

public final class ExitChoiceDialog {
    private ExitChoiceDialog() {
    }

    public static int ask(Component parent) {
        BaseDialog dialog = new BaseDialog(parent, "Logout / Exit", "Choose what you would like to do");
        final int[] choice = {0};
        JLabel text = UI.label("<html><body style='width:300px'>You can log out and return to the sign-in screen, "
                + "or close the application completely. Your data is saved automatically.</body></html>",
                Theme.regular(13), Theme.TEXT);
        JPanel box = new JPanel(new BorderLayout());
        box.setOpaque(false);
        box.setBorder(new EmptyBorder(0, 0, 12, 0));
        box.add(text);
        dialog.body.add(box);

        ModernButton cancel = new ModernButton("Cancel", ModernButton.Style.OUTLINE);
        cancel.addActionListener(e -> dialog.dispose());
        ModernButton logout = new ModernButton("Logout", ModernButton.Style.SECONDARY);
        logout.addActionListener(e -> {
            choice[0] = 1;
            dialog.dispose();
        });
        ModernButton exit = new ModernButton("Exit application", ModernButton.Style.DANGER);
        exit.addActionListener(e -> {
            choice[0] = 2;
            dialog.dispose();
        });
        dialog.footer.add(cancel);
        dialog.footer.add(logout);
        dialog.footer.add(exit);
        dialog.setResizable(false);
        dialog.open(420);
        return choice[0];
    }
}
