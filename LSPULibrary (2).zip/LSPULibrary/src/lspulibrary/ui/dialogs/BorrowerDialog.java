package lspulibrary.ui.dialogs;

import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import lspulibrary.members.MemberFactory;
import lspulibrary.models.Borrower;
import lspulibrary.services.CirculationService;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.StyledTextField;

public final class BorrowerDialog {
    private BorrowerDialog() {
    }

    public static boolean show(Component parent, CirculationService service, Borrower existing) {
        boolean editing = existing != null;
        BaseDialog dialog = new BaseDialog(parent, editing ? "Edit Borrower" : "Register New Borrower",
                editing ? "Update the borrower information below" : "Enter the details of the new borrower");
        final boolean[] saved = {false};

        StyledTextField name = new StyledTextField(26, "Full name");
        StyledTextField idNumber = new StyledTextField(14, "e.g. 2024-0001");
        StyledTextField email = new StyledTextField(26, "name@lspu.edu.ph (optional)");
        JComboBox<String> type = UI.combo(new String[]{"Student", "Faculty", "Staff"});
        JLabel rules = UI.label(" ", Theme.regular(12), Theme.MUTED);

        Runnable updateRules = () -> {
            String selected = String.valueOf(type.getSelectedItem());
            rules.setText("<html><body style='width:360px'>Rules: "
                    + MemberFactory.make(selected, "x", "x", "", 0).describe().replaceFirst("^x \\(\\w+\\) - ", "")
                    + "</body></html>");
        };
        type.addActionListener(e -> updateRules.run());

        if (editing) {
            name.setText(existing.getName());
            idNumber.setText(existing.getIdNumber());
            email.setText(existing.getEmail());
            type.setSelectedItem(existing.getTypeLabel());
        }
        updateRules.run();

        JPanel pair = new JPanel(new GridLayout(1, 2, 14, 0));
        pair.setOpaque(false);
        pair.add(BaseDialog.fieldBox("School ID number *", idNumber));
        pair.add(BaseDialog.fieldBox("Member type *", type));

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.add(BaseDialog.fieldBox("Full name *", name));
        form.add(pair);
        form.add(BaseDialog.fieldBox("Email address", email));
        form.add(rules);
        dialog.body.add(form);

        ModernButton cancel = new ModernButton("Cancel", ModernButton.Style.OUTLINE);
        cancel.addActionListener(e -> dialog.dispose());
        ModernButton save = new ModernButton(editing ? "Save Changes" : "Register Borrower", ModernButton.Style.PRIMARY);
        save.addActionListener(e -> {
            try {
                String selected = String.valueOf(type.getSelectedItem());
                if (editing) {
                    service.updateBorrower(existing.getId(), name.getText(), idNumber.getText(), email.getText(), selected);
                } else {
                    service.registerBorrower(name.getText(), idNumber.getText(), email.getText(), selected);
                }
                saved[0] = true;
                dialog.dispose();
            } catch (IllegalArgumentException | IllegalStateException ex) {
                dialog.showError(ex.getMessage());
            }
        });
        dialog.footer.add(cancel);
        dialog.footer.add(save);
        dialog.getRootPane().setDefaultButton(save);
        dialog.open(500);
        return saved[0];
    }
}
