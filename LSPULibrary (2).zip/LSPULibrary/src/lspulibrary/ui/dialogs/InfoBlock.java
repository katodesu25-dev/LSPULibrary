package lspulibrary.ui.dialogs;

import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;

final class InfoBlock {
    private InfoBlock() {
    }

    static JComponent make(String caption, String value) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(UI.label(caption, Theme.regular(11), Theme.MUTED));
        p.add(UI.label(value, Theme.bold(14), Theme.TEXT_STRONG));
        return p;
    }
}
