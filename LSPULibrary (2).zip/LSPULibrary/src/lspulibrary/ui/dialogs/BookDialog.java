package lspulibrary.ui.dialogs;

import java.awt.Component;
import java.awt.GridLayout;
import java.util.Set;
import java.util.TreeSet;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import lspulibrary.models.Book;
import lspulibrary.services.CirculationService;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.StyledTextField;

public final class BookDialog {
    private BookDialog() {
    }

    public static boolean show(Component parent, CirculationService service, Book existing) {
        boolean editing = existing != null;
        BaseDialog dialog = new BaseDialog(parent, editing ? "Edit Book" : "Add New Book",
                editing ? "Update the book information below" : "Enter the details of the new book");
        final boolean[] saved = {false};

        StyledTextField title = new StyledTextField(26, "e.g. Noli Me Tangere");
        StyledTextField author = new StyledTextField(26, "e.g. Jose Rizal");
        Set<String> categories = new TreeSet<>();
        for (Book b : service.getBooks()) {
            if (!b.getCategory().isEmpty()) {
                categories.add(b.getCategory());
            }
        }
        JComboBox<String> category = UI.combo(categories.toArray(new String[0]));
        category.setEditable(true);
        category.setSelectedItem("");
        JSpinner copies = UI.spinner(1, 1, 1000);

        if (editing) {
            title.setText(existing.getTitle());
            author.setText(existing.getAuthor());
            category.setSelectedItem(existing.getCategory());
            copies.setValue(existing.getTotalCopies());
        }

        JPanel pair = new JPanel(new GridLayout(1, 2, 14, 0));
        pair.setOpaque(false);
        pair.add(BaseDialog.fieldBox("Category", category));
        pair.add(BaseDialog.fieldBox("Total copies", copies));

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new javax.swing.BoxLayout(form, javax.swing.BoxLayout.Y_AXIS));
        form.add(BaseDialog.fieldBox("Book title *", title));
        form.add(BaseDialog.fieldBox("Author", author));
        form.add(pair);
        if (editing) {
            form.add(UI.label("Currently on loan: " + existing.getBorrowedCopies() + " | Available: "
                    + existing.getAvailableCopies(), lspulibrary.ui.Theme.regular(12), lspulibrary.ui.Theme.MUTED));
        }
        dialog.body.add(form);

        ModernButton cancel = new ModernButton("Cancel", ModernButton.Style.OUTLINE);
        cancel.addActionListener(e -> dialog.dispose());
        ModernButton save = new ModernButton(editing ? "Save Changes" : "Add Book", ModernButton.Style.PRIMARY);
        save.addActionListener(e -> {
            try {
                String categoryText = String.valueOf(category.getEditor().getItem()).trim();
                int total = (Integer) copies.getValue();
                if (editing) {
                    service.updateBook(existing.getId(), title.getText(), author.getText(), categoryText, total);
                } else {
                    service.addBook(title.getText(), author.getText(), categoryText, total);
                }
                saved[0] = true;
                dialog.dispose();
            } catch (IllegalArgumentException | IllegalStateException ex) {
                dialog.showError(ex.getMessage());
            }
        });
        dialog.footer.add(cancel);
        dialog.footer.add(save);
        dialog.getRootPane().setDefaultButton(save);
        dialog.open(460);
        return saved[0];
    }
}
