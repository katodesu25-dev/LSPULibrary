package lspulibrary.ui.dialogs;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import lspulibrary.AppContext;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;
import lspulibrary.ui.Modules;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.StyledTable;

public final class SearchResultsDialog {
    private SearchResultsDialog() {
    }

    private static boolean has(String haystack, String needle) {
        return haystack != null && haystack.toLowerCase().contains(needle);
    }

    public static void show(Component parent, AppContext ctx, String query, Navigator nav) {
        String q = query.toLowerCase().trim();
        List<String[]> rows = new ArrayList<>();
        List<String> modules = new ArrayList<>();
        List<String> terms = new ArrayList<>();

        for (Book b : ctx.circulation().getBooks()) {
            if (has(b.getTitle(), q) || has(b.getAuthor(), q) || has(b.getCategory(), q) || String.valueOf(b.getId()).equals(q)) {
                rows.add(new String[]{"Book", b.getTitle(), b.getAuthor() + " | " + b.getCategory() + " | "
                    + b.getAvailableCopies() + "/" + b.getTotalCopies() + " available"});
                modules.add(Modules.BOOKS);
                terms.add(b.getTitle());
            }
        }
        for (Borrower b : ctx.circulation().getBorrowers()) {
            if (has(b.getName(), q) || has(b.getIdNumber(), q) || has(b.getEmail(), q)) {
                rows.add(new String[]{"Borrower", b.getName(), b.getTypeLabel() + " | " + b.getIdNumber()});
                modules.add(Modules.BORROWERS);
                terms.add(b.getName());
            }
        }
        LocalDateTime now = LocalDateTime.now();
        for (Borrowing b : ctx.circulation().getBorrowings()) {
            if (has(b.getBook().getTitle(), q) || has(b.getBorrower().getName(), q) || String.valueOf(b.getId()).equals(q)) {
                rows.add(new String[]{"Transaction", "#" + b.getId() + " " + b.getBook().getTitle(),
                    b.getBorrower().getName() + " | " + b.statusAt(now)});
                modules.add(Modules.TRANSACTIONS);
                terms.add(String.valueOf(b.getId()).equals(q) ? q : b.getBook().getTitle());
            }
        }

        BaseDialog dialog = new BaseDialog(parent, "Search results", rows.size() + " result(s) for \"" + query + "\"");
        ReadOnlyTableModel model = new ReadOnlyTableModel(new String[]{"Type", "Match", "Details"},
                new Class<?>[]{String.class, String.class, String.class});
        for (String[] r : rows) {
            model.addRow(r);
        }
        StyledTable table = new StyledTable(model);
        table.setPillColumn(0);
        table.setColumnWidths(110, 260, 380);
        Runnable open = () -> {
            int row = table.selectedModelRow();
            if (row >= 0) {
                dialog.dispose();
                nav.navigate(modules.get(row), terms.get(row));
            }
        };
        table.setDoubleClickHandler(r -> open.run());

        var scroll = UI.scroll(table);
        scroll.setPreferredSize(new Dimension(720, 300));
        scroll.setBorder(javax.swing.BorderFactory.createLineBorder(Theme.BORDER));
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(scroll);
        if (rows.isEmpty()) {
            wrap.add(UI.label("Nothing matched your search. Try a title, author, name, or ID number.",
                    Theme.regular(13), Theme.MUTED), BorderLayout.SOUTH);
        }
        dialog.body.add(wrap);

        ModernButton close = new ModernButton("Close", ModernButton.Style.OUTLINE);
        close.addActionListener(e -> dialog.dispose());
        ModernButton openButton = new ModernButton("Open selected", ModernButton.Style.PRIMARY);
        openButton.addActionListener(e -> open.run());
        dialog.footer.add(close);
        dialog.footer.add(openButton);
        dialog.open(760);
    }
}
