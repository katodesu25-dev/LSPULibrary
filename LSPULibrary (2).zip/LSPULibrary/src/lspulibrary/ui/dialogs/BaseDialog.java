package lspulibrary.ui.dialogs;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Window;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;

public class BaseDialog extends JDialog {
    private static final long serialVersionUID = 1L;
    protected final JPanel body = new JPanel(new BorderLayout());
    protected final JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
    protected final JLabel errorLabel = new JLabel(" ");
    private final Window owner;

    public BaseDialog(Component parent, String title, String subtitle) {
        super(parent == null ? null : SwingUtilities.getWindowAncestor(parent), title, ModalityType.APPLICATION_MODAL);
        this.owner = parent == null ? null : SwingUtilities.getWindowAncestor(parent);

        JPanel header = new JPanel(new BorderLayout(0, 3));
        header.setBackground(Theme.NAVY);
        header.setBorder(new EmptyBorder(18, 24, 16, 24));
        header.add(UI.label(title, Theme.bold(17), Theme.WHITE), BorderLayout.NORTH);
        header.add(UI.label(subtitle, Theme.regular(12), Theme.SIDEBAR_TEXT), BorderLayout.CENTER);

        body.setBackground(Theme.WHITE);
        body.setBorder(new EmptyBorder(20, 24, 6, 24));

        errorLabel.setFont(Theme.bold(12));
        errorLabel.setForeground(Theme.DANGER);
        errorLabel.setBorder(new EmptyBorder(0, 24, 10, 24));

        footer.setBackground(new java.awt.Color(0xF9FAFB));
        footer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Theme.BORDER), new EmptyBorder(12, 16, 12, 16)));

        JPanel south = new JPanel(new BorderLayout());
        south.setBackground(Theme.WHITE);
        south.add(errorLabel, BorderLayout.NORTH);
        south.add(footer, BorderLayout.CENTER);

        getContentPane().setBackground(Theme.WHITE);
        getContentPane().add(header, BorderLayout.NORTH);
        getContentPane().add(body, BorderLayout.CENTER);
        getContentPane().add(south, BorderLayout.SOUTH);
    }

    public void showError(String message) {
        errorLabel.setText("<html>" + message.replace("<", "&lt;") + "</html>");
        pack();
    }

    public void clearError() {
        errorLabel.setText(" ");
    }

    public void open(int minWidth) {
        pack();
        Dimension d = getPreferredSize();
        setSize(Math.max(d.width, minWidth), d.height);
        setLocationRelativeTo(owner);
        setVisible(true);
    }

    public static JComponent fieldBox(String label, JComponent component) {
        JPanel box = new JPanel(new BorderLayout(0, 5));
        box.setOpaque(false);
        box.setBorder(new EmptyBorder(0, 0, 14, 0));
        box.add(UI.label(label, Theme.bold(12), Theme.TEXT), BorderLayout.NORTH);
        box.add(component, BorderLayout.CENTER);
        return box;
    }
}
