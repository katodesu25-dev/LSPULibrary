package lspulibrary.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Sidebar extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final String LOGOUT = "logout";
    private final Map<String, NavItem> items = new LinkedHashMap<>();

    public Sidebar(Consumer<String> onNavigate, Runnable onLogout) {
        setBackground(Theme.NAVY);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setPreferredSize(new Dimension(252, 0));
        setBorder(new EmptyBorder(18, 12, 14, 12));

        LogoPanel logo = new LogoPanel(1f);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        logo.setBorder(new EmptyBorder(0, 10, 0, 0));
        JPanel logoHolder = new JPanel(new BorderLayout());
        logoHolder.setOpaque(false);
        logoHolder.setBorder(new EmptyBorder(0, 10, 0, 0));
        logoHolder.add(logo, BorderLayout.CENTER);
        logoHolder.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
        logoHolder.setAlignmentX(Component.LEFT_ALIGNMENT);
        add(logoHolder);
        add(Box.createVerticalStrut(18));

        add(caption("MENU"));
        addItem(Modules.DASHBOARD, "Dashboard", Icons.DASHBOARD, onNavigate);
        addItem(Modules.BOOKS, "Book Management", Icons.BOOKS, onNavigate);
        addItem(Modules.BORROWERS, "Borrower Management", Icons.USERS, onNavigate);
        addItem(Modules.BORROW, "Borrow Books", Icons.BORROW, onNavigate);
        addItem(Modules.RETURN, "Return Books", Icons.RETURN, onNavigate);
        addItem(Modules.TRANSACTIONS, "Borrowing Transactions", Icons.LIST, onNavigate);
        addItem(Modules.REPORTS, "Reports and Analytics", Icons.CHART, onNavigate);
        add(Box.createVerticalStrut(10));
        add(caption("SYSTEM"));
        addItem(Modules.SETTINGS, "Settings", Icons.SETTINGS, onNavigate);
        add(Box.createVerticalGlue());

        NavItem logout = new NavItem(LOGOUT, "Logout / Exit", Icons.LOGOUT);
        logout.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                onLogout.run();
            }
        });
        logout.setAlignmentX(Component.LEFT_ALIGNMENT);
        add(logout);
        add(Box.createVerticalStrut(8));
        JLabel version = UI.label("Library Borrowing System v2.0", Theme.regular(11), new java.awt.Color(0x6F819F));
        version.setBorder(new EmptyBorder(0, 16, 0, 0));
        version.setAlignmentX(Component.LEFT_ALIGNMENT);
        add(version);
    }

    private JLabel caption(String text) {
        JLabel l = UI.label(text, Theme.bold(10), new java.awt.Color(0x6F819F));
        l.setBorder(new EmptyBorder(0, 16, 8, 0));
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private void addItem(String key, String label, String icon, Consumer<String> onNavigate) {
        NavItem item = new NavItem(key, label, icon);
        item.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                onNavigate.accept(key);
            }
        });
        item.setAlignmentX(Component.LEFT_ALIGNMENT);
        items.put(key, item);
        add(item);
    }

    public void setActive(String key) {
        for (Map.Entry<String, NavItem> e : items.entrySet()) {
            e.getValue().setActive(e.getKey().equals(key));
        }
    }

    private static class NavItem extends JComponent {
        private static final long serialVersionUID = 1L;
        private final String label;
        private final String icon;
        private boolean active;
        private boolean hover;

        NavItem(String key, String label, String icon) {
            this.label = label;
            this.icon = icon;
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(228, 46));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    repaint();
                }
            });
        }

        void setActive(boolean active) {
            this.active = active;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            if (active) {
                g2.setColor(Theme.NAVY_LIGHT);
                g2.fillRoundRect(0, 3, w, h - 6, 12, 12);
                g2.setColor(Theme.GOLD);
                g2.fillRoundRect(0, 11, 4, h - 22, 4, 4);
            } else if (hover) {
                g2.setColor(Theme.alpha(Theme.NAVY_LIGHT, 120));
                g2.fillRoundRect(0, 3, w, h - 6, 12, 12);
            }
            java.awt.Color color = active ? Theme.GOLD : hover ? Theme.WHITE : Theme.SIDEBAR_TEXT;
            Icons.paint((Graphics2D) g2.create(18, (h - 20) / 2, 20, 20), icon, 20, color);
            g2.setFont(active ? Theme.bold(13) : Theme.regular(13));
            g2.setColor(active || hover ? Theme.WHITE : Theme.SIDEBAR_TEXT);
            java.awt.FontMetrics fm = g2.getFontMetrics();
            g2.drawString(label, 50, (h - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }
}
