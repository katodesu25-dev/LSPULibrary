package lspulibrary.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.Icon;

public final class Icons {
    public static final String DASHBOARD = "dashboard";
    public static final String BOOKS = "books";
    public static final String USERS = "users";
    public static final String BORROW = "borrow";
    public static final String RETURN = "return";
    public static final String LIST = "list";
    public static final String CHART = "chart";
    public static final String SETTINGS = "settings";
    public static final String LOGOUT = "logout";
    public static final String BELL = "bell";
    public static final String SEARCH = "search";
    public static final String PLUS = "plus";
    public static final String CHECK = "check";
    public static final String WARNING = "warning";
    public static final String CLOCK = "clock";
    public static final String CHEVRON = "chevron";
    public static final String DOWNLOAD = "download";

    private Icons() {
    }

    public static Icon icon(String name, int size, Color color) {
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.translate(x, y);
                paint(g2, name, size, color);
                g2.dispose();
            }

            @Override
            public int getIconWidth() {
                return size;
            }

            @Override
            public int getIconHeight() {
                return size;
            }
        };
    }

    public static void paint(Graphics2D g, String name, int size, Color color) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g2.scale(size / 24.0, size / 24.0);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        switch (name) {
            case DASHBOARD:
                g2.draw(new RoundRectangle2D.Double(3.5, 3.5, 6.5, 6.5, 2, 2));
                g2.draw(new RoundRectangle2D.Double(14, 3.5, 6.5, 6.5, 2, 2));
                g2.draw(new RoundRectangle2D.Double(3.5, 14, 6.5, 6.5, 2, 2));
                g2.draw(new RoundRectangle2D.Double(14, 14, 6.5, 6.5, 2, 2));
                break;
            case BOOKS:
                g2.draw(new RoundRectangle2D.Double(5, 3, 14, 18, 3, 3));
                g2.draw(new Line2D.Double(9.5, 3, 9.5, 21));
                g2.draw(new Line2D.Double(13, 8, 16, 8));
                g2.draw(new Line2D.Double(13, 12, 16, 12));
                break;
            case USERS:
                g2.draw(new Ellipse2D.Double(8, 3.5, 8, 8));
                g2.draw(new Arc2D.Double(4.5, 14.5, 15, 12, 0, 180, Arc2D.OPEN));
                break;
            case BORROW:
                g2.draw(poly(new double[][]{{4, 15}, {4, 20}, {20, 20}, {20, 15}}));
                g2.draw(new Line2D.Double(12, 15, 12, 4));
                g2.draw(poly(new double[][]{{7.5, 8}, {12, 3.5}, {16.5, 8}}));
                break;
            case RETURN:
                g2.draw(poly(new double[][]{{4, 15}, {4, 20}, {20, 20}, {20, 15}}));
                g2.draw(new Line2D.Double(12, 3.5, 12, 14.5));
                g2.draw(poly(new double[][]{{7.5, 10}, {12, 14.5}, {16.5, 10}}));
                break;
            case LIST:
                g2.draw(new Line2D.Double(9, 6, 20, 6));
                g2.draw(new Line2D.Double(9, 12, 20, 12));
                g2.draw(new Line2D.Double(9, 18, 20, 18));
                g2.fill(new Ellipse2D.Double(3.5, 4.5, 3, 3));
                g2.fill(new Ellipse2D.Double(3.5, 10.5, 3, 3));
                g2.fill(new Ellipse2D.Double(3.5, 16.5, 3, 3));
                break;
            case CHART:
                g2.fill(new RoundRectangle2D.Double(4, 13, 4, 8, 1.5, 1.5));
                g2.fill(new RoundRectangle2D.Double(10, 8, 4, 13, 1.5, 1.5));
                g2.fill(new RoundRectangle2D.Double(16, 3.5, 4, 17.5, 1.5, 1.5));
                break;
            case SETTINGS:
                g2.draw(new Ellipse2D.Double(8.5, 8.5, 7, 7));
                g2.setStroke(new BasicStroke(2.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                for (int i = 0; i < 8; i++) {
                    double a = Math.toRadians(i * 45);
                    g2.draw(new Line2D.Double(12 + Math.cos(a) * 7.2, 12 + Math.sin(a) * 7.2,
                            12 + Math.cos(a) * 9.6, 12 + Math.sin(a) * 9.6));
                }
                g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.draw(new Ellipse2D.Double(4.8, 4.8, 14.4, 14.4));
                break;
            case LOGOUT:
                g2.draw(poly(new double[][]{{10, 4}, {5, 4}, {5, 20}, {10, 20}}));
                g2.draw(new Line2D.Double(9, 12, 20, 12));
                g2.draw(poly(new double[][]{{16, 8}, {20, 12}, {16, 16}}));
                break;
            case BELL:
                Path2D bell = new Path2D.Double();
                bell.moveTo(6, 17);
                bell.lineTo(6, 11);
                bell.curveTo(6, 4.5, 18, 4.5, 18, 11);
                bell.lineTo(18, 17);
                bell.closePath();
                g2.draw(bell);
                g2.draw(new Line2D.Double(4, 17, 20, 17));
                g2.draw(new Arc2D.Double(9.5, 17.5, 5, 4, 180, 180, Arc2D.OPEN));
                break;
            case SEARCH:
                g2.draw(new Ellipse2D.Double(4, 4, 12, 12));
                g2.draw(new Line2D.Double(14, 14, 20, 20));
                break;
            case PLUS:
                g2.draw(new Line2D.Double(12, 5, 12, 19));
                g2.draw(new Line2D.Double(5, 12, 19, 12));
                break;
            case CHECK:
                g2.draw(poly(new double[][]{{5, 12.5}, {10, 17.5}, {19, 7}}));
                break;
            case WARNING:
                g2.draw(poly(new double[][]{{12, 3.5}, {21, 19.5}, {3, 19.5}, {12, 3.5}}));
                g2.draw(new Line2D.Double(12, 9.5, 12, 14));
                g2.fill(new Ellipse2D.Double(11, 15.7, 2, 2));
                break;
            case CLOCK:
                g2.draw(new Ellipse2D.Double(3.5, 3.5, 17, 17));
                g2.draw(poly(new double[][]{{12, 7.5}, {12, 12}, {15.5, 14}}));
                break;
            case CHEVRON:
                g2.draw(poly(new double[][]{{6, 9}, {12, 15}, {18, 9}}));
                break;
            case DOWNLOAD:
                g2.draw(new Line2D.Double(12, 4, 12, 15));
                g2.draw(poly(new double[][]{{7.5, 11}, {12, 15.5}, {16.5, 11}}));
                g2.draw(poly(new double[][]{{4, 17}, {4, 20}, {20, 20}, {20, 17}}));
                break;
            default:
                break;
        }
        g2.dispose();
    }

    private static Path2D poly(double[][] points) {
        Path2D p = new Path2D.Double();
        p.moveTo(points[0][0], points[0][1]);
        for (int i = 1; i < points.length; i++) {
            p.lineTo(points[i][0], points[i][1]);
        }
        return p;
    }
}
