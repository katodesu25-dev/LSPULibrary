package lspulibrary.ui;

import java.awt.Component;
import lspulibrary.models.Administrator;

public interface Navigator {
    void navigate(String module);

    void navigate(String module, String search);

    void dataChanged();

    void toast(String message, boolean success);

    Component dialogParent();

    Administrator administrator();

    void logout();
}
