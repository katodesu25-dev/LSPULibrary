package lspulibrary.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public final class Theme {
    public static final Color NAVY = new Color(0x0B1F3A);
    public static final Color NAVY_LIGHT = new Color(0x16315A);
    public static final Color NAVY_HOVER = new Color(0x112948);
    public static final Color GOLD = new Color(0xF2B705);
    public static final Color GOLD_DARK = new Color(0xD9A400);
    public static final Color GOLD_SOFT = new Color(0xFFF4CC);
    public static final Color WHITE = Color.WHITE;
    public static final Color BACKGROUND = new Color(0xF3F4F6);
    public static final Color TEXT = new Color(0x374151);
    public static final Color TEXT_STRONG = new Color(0x111827);
    public static final Color MUTED = new Color(0x6B7280);
    public static final Color BORDER = new Color(0xE5E7EB);
    public static final Color ROW_ALT = new Color(0xF8FAFC);
    public static final Color ROW_SELECTED = new Color(0xFFF1BF);
    public static final Color SUCCESS = new Color(0x16A34A);
    public static final Color DANGER = new Color(0xDC2626);
    public static final Color WARNING = new Color(0xD97706);
    public static final Color INFO = new Color(0x2563EB);
    public static final Color PURPLE = new Color(0x7C3AED);
    public static final Color TEAL = new Color(0x0D9488);
    public static final Color SIDEBAR_TEXT = new Color(0xB8C4D9);

    private static final String FAMILY = pickFamily();

    private Theme() {
    }

    private static String pickFamily() {
        Set<String> available = new HashSet<>(Arrays.asList(
                GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
        String[] preferred = {"Segoe UI", "Inter", "SF Pro Text", "Helvetica Neue", "Roboto", "Noto Sans", "DejaVu Sans"};
        for (String name : preferred) {
            if (available.contains(name)) {
                return name;
            }
        }
        return Font.SANS_SERIF;
    }

    public static Font regular(float size) {
        return new Font(FAMILY, Font.PLAIN, 1).deriveFont(size);
    }

    public static Font bold(float size) {
        return new Font(FAMILY, Font.BOLD, 1).deriveFont(Font.BOLD, size);
    }

    public static Color pillColor(String text) {
        switch (text) {
            case "Available":
            case "Returned":
            case "Active":
            case "Eligible":
                return SUCCESS;
            case "Low stock":
                return WARNING;
            case "Out of stock":
            case "Overdue":
            case "Not eligible":
                return DANGER;
            case "Borrowed":
            case "Student":
                return INFO;
            case "Faculty":
                return PURPLE;
            case "Staff":
                return TEAL;
            default:
                return MUTED;
        }
    }

    public static Color alpha(Color c, int alpha) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), alpha);
    }
}
