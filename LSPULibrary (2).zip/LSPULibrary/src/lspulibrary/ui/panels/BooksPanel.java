package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import lspulibrary.AppContext;
import lspulibrary.models.Book;
import lspulibrary.ui.Dialogs;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.StyledTable;
import lspulibrary.ui.components.StyledTextField;
import lspulibrary.ui.components.TableActions;
import lspulibrary.ui.dialogs.BookDetailsDialog;
import lspulibrary.ui.dialogs.BookDialog;

public class BooksPanel extends ModulePanel {
    private static final long serialVersionUID = 1L;
    private static final String ALL = "All categories";
    private final StyledTextField search = new StyledTextField(26, "Search by title, author, category or ID...", true);
    private final JComboBox<String> category = UI.combo(new String[]{ALL});
    private final JLabel count = UI.label(" ", Theme.regular(12), Theme.MUTED);
    private final StyledTable table;
    private boolean updating;
    private List<Book> books = new ArrayList<>();

    public BooksPanel(AppContext ctx, Navigator nav) {
        super(ctx, nav);
        ReadOnlyTableModel model = new ReadOnlyTableModel(
                new String[]{"ID", "Title", "Author", "Category", "Total", "Available", "Status", "Actions"},
                new Class<?>[]{Integer.class, String.class, String.class, String.class, Integer.class, Integer.class,
                    String.class, Object.class});
        table = new StyledTable(model);
        table.setPillColumn(6);
        table.setActionColumn(7, this::onAction);
        table.setDoubleClickHandler(row -> view(row));
        table.setColumnWidths(60, 260, 190, 140, 60, 80, 120, 200);

        ModernButton add = new ModernButton("Add Book", ModernButton.Style.PRIMARY, Icons.PLUS);
        add.addActionListener(e -> {
            if (BookDialog.show(this, ctx.circulation(), null)) {
                nav.toast("Book added successfully.", true);
                nav.dataChanged();
            }
        });
        add(UI.header("Book Management", "Add, edit and track every book in the library collection", add), BorderLayout.NORTH);

        search.setPreferredSize(new java.awt.Dimension(340, 40));
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                applyFilter();
            }
        });
        category.addActionListener(e -> {
            if (!updating) {
                applyFilter();
            }
        });

        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(false);
        bar.add(UI.toolbar(search, category), BorderLayout.WEST);
        bar.add(count, BorderLayout.EAST);

        JPanel inner = new JPanel(new BorderLayout(0, 12));
        inner.setOpaque(false);
        inner.add(bar, BorderLayout.NORTH);
        var scroll = UI.scroll(table);
        scroll.setBorder(javax.swing.BorderFactory.createLineBorder(Theme.BORDER));
        inner.add(scroll, BorderLayout.CENTER);

        lspulibrary.ui.components.RoundedPanel card = lspulibrary.ui.components.RoundedPanel.card(new BorderLayout(), 16);
        card.add(inner);
        add(card, BorderLayout.CENTER);
    }

    @Override
    public void refresh() {
        books = ctx.circulation().getBooks();
        Set<String> categories = new TreeSet<>();
        for (Book b : books) {
            if (!b.getCategory().isEmpty()) {
                categories.add(b.getCategory());
            }
        }
        Object selected = category.getSelectedItem();
        updating = true;
        category.removeAllItems();
        category.addItem(ALL);
        for (String c : categories) {
            category.addItem(c);
        }
        category.setSelectedItem(selected != null && (ALL.equals(selected) || categories.contains(selected)) ? selected : ALL);
        updating = false;

        ReadOnlyTableModel model = table.getTableModel();
        model.setRowCount(0);
        for (Book b : books) {
            String status = b.getAvailableCopies() == 0 ? "Out of stock"
                    : b.getAvailableCopies() <= 1 && b.getTotalCopies() > 1 ? "Low stock" : "Available";
            model.addRow(new Object[]{b.getId(), b.getTitle(), b.getAuthor(), b.getCategory(), b.getTotalCopies(),
                b.getAvailableCopies(), status, new TableActions("View", "Edit", "Delete")});
        }
        applyFilter();
    }

    @Override
    public void applySearch(String text) {
        updating = true;
        category.setSelectedItem(ALL);
        updating = false;
        search.setText(text);
        applyFilter();
    }

    private void applyFilter() {
        String q = search.getText().trim().toLowerCase();
        Object selected = category.getSelectedItem();
        String cat = selected == null ? ALL : selected.toString();
        table.getSorter().setRowFilter(new RowFilter<ReadOnlyTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends ReadOnlyTableModel, ? extends Integer> entry) {
                if (!ALL.equals(cat) && !cat.equals(String.valueOf(entry.getValue(3)))) {
                    return false;
                }
                if (q.isEmpty()) {
                    return true;
                }
                for (int i = 0; i < 4; i++) {
                    if (String.valueOf(entry.getValue(i)).toLowerCase().contains(q)) {
                        return true;
                    }
                }
                return false;
            }
        });
        count.setText("Showing " + table.getRowCount() + " of " + books.size() + " books");
    }

    private Book bookAt(int modelRow) {
        int id = (Integer) table.getTableModel().getValueAt(modelRow, 0);
        for (Book b : books) {
            if (b.getId() == id) {
                return b;
            }
        }
        return null;
    }

    private void view(int modelRow) {
        Book book = bookAt(modelRow);
        if (book != null) {
            BookDetailsDialog.show(this, ctx, book);
        }
    }

    private void onAction(String action, int modelRow) {
        Book book = bookAt(modelRow);
        if (book == null) {
            return;
        }
        switch (action) {
            case "View":
                view(modelRow);
                break;
            case "Edit":
                if (BookDialog.show(this, ctx.circulation(), book)) {
                    nav.toast("Book updated successfully.", true);
                    nav.dataChanged();
                }
                break;
            case "Delete":
                if (Dialogs.confirm(this, "Delete book", "Delete \"" + book.getTitle()
                        + "\" from the collection? This cannot be undone.", "Delete", true)) {
                    try {
                        ctx.circulation().deleteBook(book.getId());
                        nav.toast("Book deleted.", true);
                        nav.dataChanged();
                    } catch (RuntimeException ex) {
                        Dialogs.error(this, ex.getMessage());
                    }
                }
                break;
            default:
                break;
        }
    }
}
