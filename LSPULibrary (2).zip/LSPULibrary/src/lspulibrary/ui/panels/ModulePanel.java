package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import lspulibrary.AppContext;
import lspulibrary.ui.Navigator;

public abstract class ModulePanel extends JPanel {
    private static final long serialVersionUID = 1L;
    protected final AppContext ctx;
    protected final Navigator nav;

    protected ModulePanel(AppContext ctx, Navigator nav) {
        super(new BorderLayout());
        this.ctx = ctx;
        this.nav = nav;
        setOpaque(false);
        setBorder(new EmptyBorder(22, 28, 14, 28));
    }

    public abstract void refresh();

    public void applySearch(String text) {
    }
}
