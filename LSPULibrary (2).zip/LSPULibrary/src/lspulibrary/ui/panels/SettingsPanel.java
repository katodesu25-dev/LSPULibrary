package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import lspulibrary.AppContext;
import lspulibrary.members.LibraryMember;
import lspulibrary.members.MemberFactory;
import lspulibrary.models.Administrator;
import lspulibrary.ui.Dialogs;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.ScrollablePanel;
import lspulibrary.ui.components.StyledPasswordField;
import lspulibrary.ui.components.StyledTable;
import lspulibrary.ui.components.StyledTextField;
import lspulibrary.ui.dialogs.BaseDialog;
import lspulibrary.util.Format;
import lspulibrary.data.SampleData;

public class SettingsPanel extends ModulePanel {
    private static final long serialVersionUID = 1L;
    private final StyledTextField fullName = new StyledTextField(20, "Full name");
    private final StyledTextField username = new StyledTextField(20, "");
    private final StyledPasswordField current = new StyledPasswordField(20, "Current password");
    private final StyledPasswordField replacement = new StyledPasswordField(20, "New password");
    private final StyledPasswordField confirmation = new StyledPasswordField(20, "Confirm new password");
    private final JLabel dataSummary = UI.label(" ", Theme.regular(12), Theme.MUTED);

    public SettingsPanel(AppContext ctx, Navigator nav) {
        super(ctx, nav);
        add(UI.header("Settings", "Manage your account, review borrowing rules and maintain library data"), BorderLayout.NORTH);

        username.setEnabled(false);

        ModernButton saveProfile = new ModernButton("Save Profile", ModernButton.Style.PRIMARY);
        saveProfile.addActionListener(e -> {
            try {
                ctx.auth().updateFullName(nav.administrator(), fullName.getText());
                nav.toast("Profile updated.", true);
                SwingUtilities.getWindowAncestor(this).repaint();
            } catch (IllegalArgumentException ex) {
                Dialogs.error(this, ex.getMessage());
            }
        });
        JPanel profile = column(BaseDialog.fieldBox("Full name", fullName), BaseDialog.fieldBox("Username", username),
                alignRight(saveProfile));

        ModernButton changePassword = new ModernButton("Update Password", ModernButton.Style.SECONDARY);
        changePassword.addActionListener(e -> {
            try {
                ctx.auth().changePassword(nav.administrator(), current.getPassword(), replacement.getPassword(),
                        confirmation.getPassword());
                current.setText("");
                replacement.setText("");
                confirmation.setText("");
                nav.toast("Password changed successfully.", true);
            } catch (IllegalArgumentException ex) {
                Dialogs.error(this, ex.getMessage());
            }
        });
        JPanel password = column(BaseDialog.fieldBox("Current password", current),
                BaseDialog.fieldBox("New password", replacement), BaseDialog.fieldBox("Confirm new password", confirmation),
                alignRight(changePassword));

        ReadOnlyTableModel rulesModel = new ReadOnlyTableModel(
                new String[]{"Member type", "Max books", "Loan days", "Fine per day", "Fine cap"},
                new Class<?>[]{String.class, Integer.class, Integer.class, Double.class, String.class});
        for (String type : MemberFactory.types()) {
            LibraryMember m = MemberFactory.make(type, "x", "x", "", 0);
            double huge = m.computeFine(10000);
            String cap = huge < 10000 * m.getFinePerDay() ? Format.peso(huge) : "None";
            rulesModel.addRow(new Object[]{m.getRole(), m.getBorrowLimit(), m.getLoanDays(), m.getFinePerDay(), cap});
        }
        StyledTable rules = new StyledTable(rulesModel);
        rules.setRowHeight(38);
        var rulesScroll = UI.scroll(rules);
        rulesScroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        rulesScroll.setPreferredSize(new Dimension(420, 40 + 3 * 38 + 2));
        JPanel rulesBox = new JPanel(new BorderLayout(0, 8));
        rulesBox.setOpaque(false);
        rulesBox.add(rulesScroll, BorderLayout.CENTER);
        rulesBox.add(UI.label("These rules come from the member classes and apply to every borrowing and return.",
                Theme.regular(12), Theme.MUTED), BorderLayout.SOUTH);

        ModernButton sample = new ModernButton("Load Sample Data", ModernButton.Style.OUTLINE);
        sample.addActionListener(e -> loadSample());
        ModernButton reset = new ModernButton("Reset All Data", ModernButton.Style.DANGER);
        reset.addActionListener(e -> resetData());
        JPanel dataButtons = UI.toolbar(sample, reset);
        dataButtons.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        JPanel data = column(left(UI.label("Storage", Theme.bold(12), Theme.TEXT)),
                left(UI.label("<html><body style='width:380px'>" + escape(ctx.getRepository().describe()) + "</body></html>",
                        Theme.regular(12), Theme.MUTED)),
                javax.swing.Box.createVerticalStrut(6), left(dataSummary), javax.swing.Box.createVerticalStrut(12), dataButtons);

        ScrollablePanel root = new ScrollablePanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1;
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(0, 0, 16, 8);
        root.add(UI.card("Administrator profile", profile), c);
        c.gridx = 1;
        c.insets = new Insets(0, 8, 16, 0);
        root.add(UI.card("Borrowing rules", rulesBox), c);
        c.gridx = 0;
        c.gridy = 1;
        c.insets = new Insets(0, 0, 8, 8);
        root.add(UI.card("Change password", password), c);
        c.gridx = 1;
        c.insets = new Insets(0, 8, 8, 0);
        root.add(UI.card("Data management", data), c);
        add(UI.pageScroll(root), BorderLayout.CENTER);
    }

    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;");
    }

    private static JComponent left(JComponent c) {
        c.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        return c;
    }

    private JComponent alignRight(JComponent c) {
        JPanel p = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 0));
        p.setOpaque(false);
        p.add(c);
        p.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        return p;
    }

    private JPanel column(java.awt.Component... parts) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        for (java.awt.Component part : parts) {
            if (part instanceof JComponent) {
                ((JComponent) part).setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            }
            p.add(part);
        }
        return p;
    }

    @Override
    public void refresh() {
        Administrator admin = nav.administrator();
        fullName.setText(admin.getFullName());
        username.setText(admin.getUsername());
        dataSummary.setText(ctx.circulation().getBooks().size() + " books, " + ctx.circulation().getBorrowers().size()
                + " borrowers, " + ctx.circulation().getBorrowings().size() + " transactions");
    }

    private void loadSample() {
        boolean empty = ctx.circulation().getBooks().isEmpty() && ctx.circulation().getBorrowers().isEmpty()
                && ctx.circulation().getBorrowings().isEmpty();
        if (!empty) {
            Dialogs.error(this, "Sample data can only be loaded into an empty library. Use \"Reset All Data\" first.");
            return;
        }
        if (Dialogs.confirm(this, "Load sample data", "Add sample books, borrowers and transactions?", "Load", false)) {
            try {
                SampleData.load(ctx.getRepository());
                nav.toast("Sample data loaded.", true);
                nav.dataChanged();
            } catch (RuntimeException ex) {
                Dialogs.error(this, ex.getMessage());
            }
        }
    }

    private void resetData() {
        if (Dialogs.confirm(this, "Reset all data", "This permanently deletes every book, borrower and transaction.\n"
                + "Administrator accounts are kept. This cannot be undone.", "Delete everything", true)) {
            try {
                ctx.getRepository().clearLibraryData();
                nav.toast("All library data was deleted.", true);
                nav.dataChanged();
            } catch (RuntimeException ex) {
                Dialogs.error(this, ex.getMessage());
            }
        }
    }
}
