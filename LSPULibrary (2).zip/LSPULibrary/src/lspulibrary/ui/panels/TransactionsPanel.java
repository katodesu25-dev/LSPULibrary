package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import lspulibrary.AppContext;
import lspulibrary.models.Borrowing;
import lspulibrary.ui.Dialogs;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Modules;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.RoundedPanel;
import lspulibrary.ui.components.StyledTable;
import lspulibrary.ui.components.StyledTextField;
import lspulibrary.ui.components.TableActions;
import lspulibrary.util.Format;

public class TransactionsPanel extends ModulePanel {
    private static final long serialVersionUID = 1L;
    private final StyledTextField search = new StyledTextField(24, "Search by ID, book or borrower...", true);
    private final JComboBox<String> status = UI.combo(new String[]{"All status", "Borrowed", "Overdue", "Returned"});
    private final JComboBox<String> sort = UI.combo(new String[]{"Newest first", "Oldest first", "Due date (soonest)",
        "Highest fine"});
    private final JLabel count = UI.label(" ", Theme.regular(12), Theme.MUTED);
    private final StyledTable table;
    private List<Borrowing> loans = new ArrayList<>();
    private boolean updating;

    public TransactionsPanel(AppContext ctx, Navigator nav) {
        super(ctx, nav);
        ReadOnlyTableModel model = new ReadOnlyTableModel(
                new String[]{"ID", "Book Title", "Borrower", "Borrowed", "Due Date", "Returned", "Status", "Fine", "Actions"},
                new Class<?>[]{Integer.class, String.class, String.class, LocalDateTime.class, LocalDateTime.class,
                    LocalDateTime.class, String.class, Double.class, Object.class});
        table = new StyledTable(model);
        table.setPillColumn(6);
        table.setActionColumn(8, (action, row) -> {
            if ("Return".equals(action)) {
                nav.navigate(Modules.RETURN, "id:" + table.getTableModel().getValueAt(row, 0));
            }
        });
        table.setColumnWidths(60, 220, 150, 140, 140, 140, 100, 80, 90);

        ModernButton export = new ModernButton("Export CSV", ModernButton.Style.OUTLINE, Icons.DOWNLOAD);
        export.addActionListener(e -> exportCsv());
        add(UI.header("Borrowing Transactions", "Every borrowing and return recorded in the library", export), BorderLayout.NORTH);

        search.setPreferredSize(new java.awt.Dimension(300, 40));
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                applyFilter();
            }
        });
        status.addActionListener(e -> applyFilter());
        sort.addActionListener(e -> {
            if (!updating) {
                applySort();
            }
        });

        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(false);
        bar.add(UI.toolbar(search, status, sort), BorderLayout.WEST);
        bar.add(count, BorderLayout.EAST);

        JPanel inner = new JPanel(new BorderLayout(0, 12));
        inner.setOpaque(false);
        inner.add(bar, BorderLayout.NORTH);
        var scroll = UI.scroll(table);
        scroll.setBorder(javax.swing.BorderFactory.createLineBorder(Theme.BORDER));
        inner.add(scroll, BorderLayout.CENTER);

        RoundedPanel card = RoundedPanel.card(new BorderLayout(), 16);
        card.add(inner);
        add(card, BorderLayout.CENTER);
    }

    @Override
    public void refresh() {
        loans = ctx.circulation().getBorrowings();
        LocalDateTime now = LocalDateTime.now();
        ReadOnlyTableModel model = table.getTableModel();
        model.setRowCount(0);
        for (Borrowing b : loans) {
            String statusText = b.statusAt(now);
            TableActions actions = b.isReturned() ? new TableActions() : new TableActions("Return");
            model.addRow(new Object[]{b.getId(), b.getBook().getTitle(), b.getBorrower().getName(), b.getBorrowedAt(),
                b.getDueAt(), b.getReturnedAt(), statusText, b.getFine(), actions});
        }
        applySort();
        applyFilter();
    }

    @Override
    public void applySearch(String text) {
        if (text != null && text.startsWith("status:")) {
            search.setText("");
            status.setSelectedItem(text.substring(7));
        } else {
            status.setSelectedIndex(0);
            search.setText(text);
        }
        applyFilter();
    }

    private void applySort() {
        int col;
        SortOrder order;
        switch (sort.getSelectedIndex()) {
            case 1:
                col = 0;
                order = SortOrder.ASCENDING;
                break;
            case 2:
                col = 4;
                order = SortOrder.ASCENDING;
                break;
            case 3:
                col = 7;
                order = SortOrder.DESCENDING;
                break;
            default:
                col = 0;
                order = SortOrder.DESCENDING;
                break;
        }
        updating = true;
        table.getSorter().setSortKeys(Collections.singletonList(new RowSorter.SortKey(col, order)));
        updating = false;
    }

    private void applyFilter() {
        String q = search.getText().trim().toLowerCase();
        String statusSel = String.valueOf(status.getSelectedItem());
        table.getSorter().setRowFilter(new RowFilter<ReadOnlyTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends ReadOnlyTableModel, ? extends Integer> entry) {
                if (!"All status".equals(statusSel) && !statusSel.equals(String.valueOf(entry.getValue(6)))) {
                    return false;
                }
                if (q.isEmpty()) {
                    return true;
                }
                for (int i = 0; i < 3; i++) {
                    if (String.valueOf(entry.getValue(i)).toLowerCase().contains(q)) {
                        return true;
                    }
                }
                return false;
            }
        });
        count.setText("Showing " + table.getRowCount() + " of " + loans.size() + " transactions");
    }

    private static String csv(String value) {
        String v = value == null ? "" : value;
        return "\"" + v.replace("\"", "\"\"") + "\"";
    }

    private void exportCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("borrowing_transactions.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        try (PrintWriter out = new PrintWriter(file, StandardCharsets.UTF_8.name())) {
            out.println("ID,Book Title,Borrower,Borrowed,Due Date,Returned,Status,Fine");
            for (int viewRow = 0; viewRow < table.getRowCount(); viewRow++) {
                int row = table.convertRowIndexToModel(viewRow);
                ReadOnlyTableModel m = table.getTableModel();
                out.println(String.join(",",
                        String.valueOf(m.getValueAt(row, 0)),
                        csv(String.valueOf(m.getValueAt(row, 1))),
                        csv(String.valueOf(m.getValueAt(row, 2))),
                        csv(Format.dateTime((LocalDateTime) m.getValueAt(row, 3))),
                        csv(Format.dateTime((LocalDateTime) m.getValueAt(row, 4))),
                        csv(Format.dateTime((LocalDateTime) m.getValueAt(row, 5))),
                        csv(String.valueOf(m.getValueAt(row, 6))),
                        String.format("%.2f", (Double) m.getValueAt(row, 7))));
            }
            nav.toast("Exported " + table.getRowCount() + " transactions to " + file.getName(), true);
        } catch (IOException ex) {
            Dialogs.error(this, "The file could not be saved: " + ex.getMessage());
        }
    }
}
