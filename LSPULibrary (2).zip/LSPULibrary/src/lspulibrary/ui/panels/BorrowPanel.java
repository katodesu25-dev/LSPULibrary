package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import lspulibrary.AppContext;
import lspulibrary.members.LibraryMember;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;
import lspulibrary.ui.Dialogs;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.Pill;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.RoundedPanel;
import lspulibrary.ui.components.ScrollablePanel;
import lspulibrary.ui.components.StyledTable;
import lspulibrary.ui.components.StyledTextField;
import lspulibrary.util.Format;

public class BorrowPanel extends ModulePanel {
    private static final long serialVersionUID = 1L;
    private final StyledTextField borrowerSearch = new StyledTextField(20, "Search borrowers...", true);
    private final StyledTextField bookSearch = new StyledTextField(20, "Search available books...", true);
    private final StyledTable borrowerTable;
    private final StyledTable bookTable;
    private final JLabel borrowerName = UI.label("No borrower selected", Theme.bold(15), Theme.NAVY);
    private final JLabel borrowerMeta = UI.label("Select a borrower from the list above", Theme.regular(12), Theme.MUTED);
    private final JLabel borrowerRules = UI.label(" ", Theme.regular(12), Theme.TEXT);
    private final Pill eligibility = new Pill();
    private final JLabel eligibilityNote = UI.label(" ", Theme.regular(12), Theme.MUTED);
    private final JLabel sumBorrower = UI.label("-", Theme.bold(14), Theme.TEXT_STRONG);
    private final JLabel sumBook = UI.label("-", Theme.bold(14), Theme.TEXT_STRONG);
    private final JLabel sumBorrowed = UI.label("-", Theme.bold(14), Theme.TEXT_STRONG);
    private final JLabel sumDue = UI.label("-", Theme.bold(14), Theme.TEXT_STRONG);
    private final ModernButton confirm = new ModernButton("Confirm Borrowing", ModernButton.Style.PRIMARY, Icons.CHECK);
    private List<Borrower> borrowers = new ArrayList<>();
    private List<Book> books = new ArrayList<>();
    private boolean loading;

    public BorrowPanel(AppContext ctx, Navigator nav) {
        super(ctx, nav);
        add(UI.header("Borrow Books", "Select a borrower and an available book, then confirm the transaction"), BorderLayout.NORTH);

        ReadOnlyTableModel borrowerModel = new ReadOnlyTableModel(
                new String[]{"Name", "School ID", "Type", "Loans", "Status"},
                new Class<?>[]{String.class, String.class, String.class, String.class, String.class});
        borrowerTable = new StyledTable(borrowerModel);
        borrowerTable.setPillColumn(2);
        borrowerTable.setPillColumn(4);
        borrowerTable.setRowHeight(38);
        borrowerTable.setColumnWidths(140, 100, 84, 56, 86);
        borrowerTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !loading) {
                updateSummary();
            }
        });

        ReadOnlyTableModel bookModel = new ReadOnlyTableModel(
                new String[]{"Title", "Author", "Category", "Available"},
                new Class<?>[]{String.class, String.class, String.class, Integer.class});
        bookTable = new StyledTable(bookModel);
        bookTable.setRowHeight(38);
        bookTable.setColumnWidths(220, 150, 110, 70);
        bookTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !loading) {
                updateSummary();
            }
        });

        hookSearch(borrowerSearch, borrowerTable, 0, 1);
        hookSearch(bookSearch, bookTable, 0, 1, 2);

        JPanel borrowerInfo = new JPanel();
        borrowerInfo.setOpaque(false);
        borrowerInfo.setLayout(new BoxLayout(borrowerInfo, BoxLayout.Y_AXIS));
        borrowerInfo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Theme.BORDER), BorderFactory.createEmptyBorder(12, 0, 0, 0)));
        JPanel nameRow = new JPanel(new BorderLayout());
        nameRow.setOpaque(false);
        nameRow.add(borrowerName, BorderLayout.WEST);
        nameRow.add(eligibility, BorderLayout.EAST);
        borrowerInfo.add(left(nameRow));
        borrowerInfo.add(javax.swing.Box.createVerticalStrut(3));
        borrowerInfo.add(left(borrowerMeta));
        borrowerInfo.add(javax.swing.Box.createVerticalStrut(3));
        borrowerInfo.add(left(borrowerRules));
        borrowerInfo.add(javax.swing.Box.createVerticalStrut(3));
        borrowerInfo.add(left(eligibilityNote));

        JPanel leftContent = new JPanel(new BorderLayout(0, 10));
        leftContent.setOpaque(false);
        borrowerSearch.setPreferredSize(new Dimension(100, 40));
        leftContent.add(borrowerSearch, BorderLayout.NORTH);
        var bs = UI.scroll(borrowerTable);
        bs.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        bs.setPreferredSize(new Dimension(420, 210));
        leftContent.add(bs, BorderLayout.CENTER);
        leftContent.add(borrowerInfo, BorderLayout.SOUTH);

        JPanel rightContent = new JPanel(new BorderLayout(0, 10));
        rightContent.setOpaque(false);
        bookSearch.setPreferredSize(new Dimension(100, 40));
        rightContent.add(bookSearch, BorderLayout.NORTH);
        var ks = UI.scroll(bookTable);
        ks.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        ks.setPreferredSize(new Dimension(420, 210));
        rightContent.add(ks, BorderLayout.CENTER);

        ModernButton clear = new ModernButton("Clear", ModernButton.Style.OUTLINE);
        clear.addActionListener(e -> clearSelection());
        confirm.addActionListener(e -> process());

        JPanel summaryGrid = new JPanel(new GridLayout(1, 4, 16, 0));
        summaryGrid.setOpaque(false);
        summaryGrid.add(block("Borrower", sumBorrower));
        summaryGrid.add(block("Book", sumBook));
        summaryGrid.add(block("Borrow date", sumBorrowed));
        summaryGrid.add(block("Due date (auto-calculated)", sumDue));
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.setOpaque(false);
        buttons.add(clear);
        buttons.add(confirm);
        JPanel summaryContent = new JPanel(new BorderLayout(20, 0));
        summaryContent.setOpaque(false);
        summaryContent.add(summaryGrid, BorderLayout.CENTER);
        summaryContent.add(buttons, BorderLayout.EAST);

        ScrollablePanel root = new ScrollablePanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1;
        c.weighty = 1;
        c.gridy = 0;
        c.insets = new Insets(0, 0, 16, 8);
        c.gridx = 0;
        root.add(UI.card("1. Select borrower", leftContent), c);
        c.gridx = 1;
        c.insets = new Insets(0, 8, 16, 0);
        root.add(UI.card("2. Select book", rightContent), c);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 2;
        c.weighty = 0;
        c.insets = new Insets(0, 0, 8, 0);
        root.add(UI.card("3. Review and confirm", summaryContent), c);
        add(UI.pageScroll(root), BorderLayout.CENTER);
        updateSummary();
    }

    private static JComponent left(JComponent c) {
        c.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        return c;
    }

    private JComponent block(String caption, JLabel value) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(left(UI.label(caption, Theme.regular(11), Theme.MUTED)));
        p.add(left(value));
        return p;
    }

    private void hookSearch(StyledTextField field, StyledTable table, int... columns) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            private void apply() {
                String q = field.getText().trim().toLowerCase();
                table.getSorter().setRowFilter(q.isEmpty() ? null : new RowFilter<ReadOnlyTableModel, Integer>() {
                    @Override
                    public boolean include(Entry<? extends ReadOnlyTableModel, ? extends Integer> entry) {
                        for (int col : columns) {
                            if (String.valueOf(entry.getValue(col)).toLowerCase().contains(q)) {
                                return true;
                            }
                        }
                        return false;
                    }
                });
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                apply();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                apply();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                apply();
            }
        });
    }

    @Override
    public void refresh() {
        Borrower previousBorrower = selectedBorrower();
        Book previousBook = selectedBook();
        loading = true;
        borrowers = ctx.circulation().getBorrowers();
        books = new ArrayList<>();
        for (Book b : ctx.circulation().getBooks()) {
            if (b.isAvailable()) {
                books.add(b);
            }
        }
        ReadOnlyTableModel bm = borrowerTable.getTableModel();
        bm.setRowCount(0);
        for (Borrower b : borrowers) {
            LibraryMember m = ctx.circulation().memberOf(b);
            bm.addRow(new Object[]{b.getName(), b.getIdNumber(), b.getTypeLabel(),
                m.getActiveLoans() + " / " + m.getBorrowLimit(), b.isActive() ? "Active" : "Inactive"});
        }
        ReadOnlyTableModel km = bookTable.getTableModel();
        km.setRowCount(0);
        for (Book b : books) {
            km.addRow(new Object[]{b.getTitle(), b.getAuthor(), b.getCategory(), b.getAvailableCopies()});
        }
        loading = false;
        if (previousBorrower != null) {
            selectRow(borrowerTable, indexOfBorrower(previousBorrower.getId()));
        }
        if (previousBook != null) {
            selectRow(bookTable, indexOfBook(previousBook.getId()));
        }
        updateSummary();
    }

    private int indexOfBorrower(int id) {
        for (int i = 0; i < borrowers.size(); i++) {
            if (borrowers.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }

    private int indexOfBook(int id) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }

    private void selectRow(StyledTable table, int modelRow) {
        if (modelRow < 0) {
            return;
        }
        int view = table.convertRowIndexToView(modelRow);
        if (view >= 0) {
            loading = true;
            table.setRowSelectionInterval(view, view);
            loading = false;
        }
    }

    private Borrower selectedBorrower() {
        int row = borrowerTable.selectedModelRow();
        return row >= 0 && row < borrowers.size() ? borrowers.get(row) : null;
    }

    private Book selectedBook() {
        int row = bookTable.selectedModelRow();
        return row >= 0 && row < books.size() ? books.get(row) : null;
    }

    private void clearSelection() {
        borrowerTable.clearSelection();
        bookTable.clearSelection();
        borrowerSearch.setText("");
        bookSearch.setText("");
        updateSummary();
    }

    private String blockingReason(Borrower borrower, Book book) {
        LibraryMember member = ctx.circulation().memberOf(borrower);
        if (!borrower.isActive()) {
            return borrower.getName() + " is deactivated.";
        }
        if (!member.canBorrow()) {
            return "Borrowing limit of " + member.getBorrowLimit() + " books has been reached.";
        }
        if (book != null && ctx.circulation().hasActiveLoan(book.getId(), borrower.getId())) {
            return "This borrower already has \"" + book.getTitle() + "\" on loan.";
        }
        return null;
    }

    private void updateSummary() {
        Borrower borrower = selectedBorrower();
        Book book = selectedBook();
        String reason = null;

        if (borrower == null) {
            borrowerName.setText("No borrower selected");
            borrowerMeta.setText("Select a borrower from the list above");
            borrowerRules.setText(" ");
            eligibility.setPill("", Theme.MUTED);
            eligibilityNote.setText(" ");
            sumBorrower.setText("-");
        } else {
            LibraryMember member = ctx.circulation().memberOf(borrower);
            reason = blockingReason(borrower, book);
            borrowerName.setText(borrower.getName());
            borrowerMeta.setText(borrower.getTypeLabel() + "  |  " + borrower.getIdNumber()
                    + (borrower.getEmail().isEmpty() ? "" : "  |  " + borrower.getEmail()));
            borrowerRules.setText("Borrowed " + member.getActiveLoans() + " of " + member.getBorrowLimit()
                    + " books  |  Loan period " + member.getLoanDays() + " days  |  Fine " + Format.peso(member.getFinePerDay()) + "/day");
            eligibility.setPill(reason == null ? "Eligible" : "Not eligible", reason == null ? Theme.SUCCESS : Theme.DANGER);
            eligibilityNote.setText(reason == null ? "Within the borrowing limit." : reason);
            eligibilityNote.setForeground(reason == null ? Theme.MUTED : Theme.DANGER);
            sumBorrower.setText(borrower.getName() + " (" + borrower.getTypeLabel() + ")");
        }

        sumBook.setText(book == null ? "-" : book.getTitle());
        if (borrower != null && book != null) {
            LocalDateTime now = LocalDateTime.now();
            sumBorrowed.setText(Format.date(now));
            sumDue.setText(Format.date(now.plusDays(ctx.circulation().memberOf(borrower).getLoanDays())));
        } else {
            sumBorrowed.setText("-");
            sumDue.setText("-");
        }
        confirm.setEnabled(borrower != null && book != null && reason == null);
    }

    private void process() {
        Borrower borrower = selectedBorrower();
        Book book = selectedBook();
        if (borrower == null || book == null) {
            Dialogs.error(this, "Select both a borrower and a book first.");
            return;
        }
        LibraryMember member = ctx.circulation().memberOf(borrower);
        String due = Format.date(LocalDateTime.now().plusDays(member.getLoanDays()));
        if (!Dialogs.confirm(this, "Confirm borrowing", "Lend \"" + book.getTitle() + "\" to " + borrower.getName()
                + "?\nIt will be due on " + due + ".", "Confirm", false)) {
            return;
        }
        try {
            Borrowing b = ctx.circulation().borrow(book.getId(), borrower.getId());
            clearSelection();
            nav.dataChanged();
            Dialogs.success(this, "Book borrowed", "Transaction #" + b.getId() + " recorded.\n\""
                    + b.getBook().getTitle() + "\" was borrowed by " + b.getBorrower().getName()
                    + ".\nDue date: " + Format.dateTime(b.getDueAt()));
        } catch (RuntimeException ex) {
            Dialogs.error(this, ex.getMessage());
            refresh();
        }
    }
}
