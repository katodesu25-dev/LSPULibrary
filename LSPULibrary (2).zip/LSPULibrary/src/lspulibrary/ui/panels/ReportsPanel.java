package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import lspulibrary.AppContext;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;
import lspulibrary.services.LibraryStats;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.BarChart;
import lspulibrary.ui.components.DonutChart;
import lspulibrary.ui.components.HBarChart;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.ScrollablePanel;
import lspulibrary.ui.components.StatCard;
import lspulibrary.ui.components.StyledTable;
import lspulibrary.util.Format;

public class ReportsPanel extends ModulePanel {
    private static final long serialVersionUID = 1L;
    private final StatCard borrowed = new StatCard("Total Books Borrowed", Icons.BORROW, Theme.INFO);
    private final StatCard activeBorrowers = new StatCard("Active Borrowers", Icons.USERS, Theme.PURPLE);
    private final StatCard overdue = new StatCard("Overdue Transactions", Icons.WARNING, Theme.DANGER);
    private final StatCard returned = new StatCard("Returned Books", Icons.CHECK, Theme.SUCCESS);
    private final StatCard fines = new StatCard("Fines Recorded", Icons.CLOCK, Theme.GOLD_DARK);
    private final HBarChart mostBorrowed = new HBarChart(Theme.NAVY_LIGHT, 32);
    private final BarChart monthly = new BarChart();
    private final DonutChart status = new DonutChart(Theme.INFO, Theme.DANGER, Theme.SUCCESS);
    private final HBarChart byType = new HBarChart(Theme.GOLD, 36);
    private final StyledTable overdueTable;
    private final StyledTable activeTable;

    public ReportsPanel(AppContext ctx, Navigator nav) {
        super(ctx, nav);
        add(UI.header("Reports and Analytics", "Borrowing trends, popular titles and overdue follow-ups"), BorderLayout.NORTH);

        overdueTable = new StyledTable(new ReadOnlyTableModel(
                new String[]{"ID", "Borrower", "Book", "Days late", "Fine so far"},
                new Class<?>[]{Integer.class, String.class, String.class, Integer.class, Double.class}));
        overdueTable.setRowHeight(36);
        overdueTable.setColumnWidths(60, 140, 200, 70, 90);
        activeTable = new StyledTable(new ReadOnlyTableModel(
                new String[]{"Borrower", "Type", "Books on loan"},
                new Class<?>[]{String.class, String.class, Integer.class}));
        activeTable.setPillColumn(1);
        activeTable.setRowHeight(36);
        activeTable.setColumnWidths(200, 100, 100);

        JPanel stats = new JPanel(new lspulibrary.ui.components.ResponsiveGrid(170, 14, 14, 5));
        stats.setOpaque(false);
        stats.add(borrowed);
        stats.add(activeBorrowers);
        stats.add(overdue);
        stats.add(returned);
        stats.add(fines);

        monthly.setPreferredSize(new Dimension(300, 250));
        status.setPreferredSize(new Dimension(300, 190));
        byType.setPreferredSize(new Dimension(300, 140));

        var overdueScroll = UI.scroll(overdueTable);
        overdueScroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        overdueScroll.setPreferredSize(new Dimension(420, 40 + 5 * 36 + 2));
        var activeScroll = UI.scroll(activeTable);
        activeScroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        activeScroll.setPreferredSize(new Dimension(420, 40 + 5 * 36 + 2));

        ScrollablePanel root = new ScrollablePanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        c.insets = new Insets(0, 0, 16, 0);
        root.add(stats, c);

        c.gridwidth = 1;
        c.gridy = 1;
        c.weighty = 1;
        c.insets = new Insets(0, 0, 16, 8);
        root.add(UI.card("Most borrowed books", mostBorrowed), c);
        c.gridx = 1;
        c.insets = new Insets(0, 8, 16, 0);
        root.add(UI.card("Borrowing activity - last 6 months", monthly), c);

        c.gridx = 0;
        c.gridy = 2;
        c.insets = new Insets(0, 0, 16, 8);
        root.add(UI.card("Transaction status", status), c);
        c.gridx = 1;
        c.insets = new Insets(0, 8, 16, 0);
        root.add(UI.card("Borrowings by member type", byType), c);

        c.gridx = 0;
        c.gridy = 3;
        c.insets = new Insets(0, 0, 8, 8);
        root.add(UI.card("Overdue transactions", overdueScroll), c);
        c.gridx = 1;
        c.insets = new Insets(0, 8, 8, 0);
        root.add(UI.card("Active borrowers", activeScroll), c);

        add(UI.pageScroll(root), BorderLayout.CENTER);
    }

    @Override
    public void refresh() {
        LibraryStats s = ctx.reports().snapshot();
        borrowed.setValue(String.valueOf(s.transactions));
        borrowed.setNote("all-time borrowings");
        activeBorrowers.setValue(String.valueOf(s.activeBorrowers));
        activeBorrowers.setNote("with books on loan");
        overdue.setValue(String.valueOf(s.overdue));
        overdue.setNote(s.overdue == 0 ? "none right now" : "past their due date");
        returned.setValue(String.valueOf(s.returned));
        returned.setNote(s.transactions == 0 ? "" : Math.round(100.0 * s.returned / s.transactions) + "% of borrowings");
        fines.setValue(Format.peso(s.totalFines));
        fines.setNote("from returned books");

        mostBorrowed.setData(ctx.reports().mostBorrowed(8));

        Map<String, Integer> months = ctx.reports().borrowingsByMonth(6);
        double[][] values = new double[1][months.size()];
        int i = 0;
        for (int v : months.values()) {
            values[0][i++] = v;
        }
        monthly.setData(new ArrayList<>(months.keySet()), new String[]{"Borrowings"}, values);

        status.setData(ctx.reports().statusBreakdown(), "transactions");
        byType.setData(new ArrayList<>(ctx.reports().borrowingsByMemberType().entrySet()));

        ReadOnlyTableModel om = overdueTable.getTableModel();
        om.setRowCount(0);
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        for (Borrowing b : ctx.reports().overdueLoans()) {
            int late = b.daysOverdue(now);
            om.addRow(new Object[]{b.getId(), b.getBorrower().getName(), b.getBook().getTitle(), late,
                ctx.circulation().previewFine(b, now)});
        }

        ReadOnlyTableModel am = activeTable.getTableModel();
        am.setRowCount(0);
        List<Map.Entry<Borrower, Integer>> ranking = ctx.reports().activeBorrowerRanking(50);
        for (Map.Entry<Borrower, Integer> e : ranking) {
            am.addRow(new Object[]{e.getKey().getName(), e.getKey().getTypeLabel(), e.getValue()});
        }
    }
}
