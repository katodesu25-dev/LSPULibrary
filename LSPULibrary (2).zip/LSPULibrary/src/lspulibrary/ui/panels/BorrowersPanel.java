package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import lspulibrary.AppContext;
import lspulibrary.members.LibraryMember;
import lspulibrary.models.Borrower;
import lspulibrary.ui.Dialogs;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.RoundedPanel;
import lspulibrary.ui.components.StyledTable;
import lspulibrary.ui.components.StyledTextField;
import lspulibrary.ui.components.TableActions;
import lspulibrary.ui.dialogs.BorrowerDetailsDialog;
import lspulibrary.ui.dialogs.BorrowerDialog;

public class BorrowersPanel extends ModulePanel {
    private static final long serialVersionUID = 1L;
    private final StyledTextField search = new StyledTextField(26, "Search by name, school ID or email...", true);
    private final JComboBox<String> type = UI.combo(new String[]{"All types", "Student", "Faculty", "Staff"});
    private final JComboBox<String> status = UI.combo(new String[]{"All status", "Active", "Inactive"});
    private final JLabel count = UI.label(" ", Theme.regular(12), Theme.MUTED);
    private final StyledTable table;
    private List<Borrower> borrowers = new ArrayList<>();

    public BorrowersPanel(AppContext ctx, Navigator nav) {
        super(ctx, nav);
        ReadOnlyTableModel model = new ReadOnlyTableModel(
                new String[]{"ID", "Full Name", "School ID", "Email", "Type", "Borrowed", "Status", "Actions"},
                new Class<?>[]{Integer.class, String.class, String.class, String.class, String.class, String.class,
                    String.class, Object.class});
        table = new StyledTable(model);
        table.setPillColumn(4);
        table.setPillColumn(6);
        table.setActionColumn(7, this::onAction);
        table.setDoubleClickHandler(this::view);
        table.setColumnWidths(60, 170, 115, 200, 95, 85, 95, 300);

        ModernButton add = new ModernButton("Register Borrower", ModernButton.Style.PRIMARY, Icons.PLUS);
        add.addActionListener(e -> {
            if (BorrowerDialog.show(this, ctx.circulation(), null)) {
                nav.toast("Borrower registered successfully.", true);
                nav.dataChanged();
            }
        });
        add(UI.header("Borrower Management", "Register students, faculty and staff, and review their borrowing activity", add),
                BorderLayout.NORTH);

        search.setPreferredSize(new java.awt.Dimension(320, 40));
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                applyFilter();
            }
        });
        type.addActionListener(e -> applyFilter());
        status.addActionListener(e -> applyFilter());

        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(false);
        bar.add(UI.toolbar(search, type, status), BorderLayout.WEST);
        bar.add(count, BorderLayout.EAST);

        JPanel inner = new JPanel(new BorderLayout(0, 12));
        inner.setOpaque(false);
        inner.add(bar, BorderLayout.NORTH);
        var scroll = UI.scroll(table);
        scroll.setBorder(javax.swing.BorderFactory.createLineBorder(Theme.BORDER));
        inner.add(scroll, BorderLayout.CENTER);

        RoundedPanel card = RoundedPanel.card(new BorderLayout(), 16);
        card.add(inner);
        add(card, BorderLayout.CENTER);
    }

    @Override
    public void refresh() {
        borrowers = ctx.circulation().getBorrowers();
        ReadOnlyTableModel model = table.getTableModel();
        model.setRowCount(0);
        for (Borrower b : borrowers) {
            LibraryMember m = ctx.circulation().memberOf(b);
            String[] actions = b.isActive() ? new String[]{"View", "Edit", "Deactivate", "Delete"}
                    : new String[]{"View", "Edit", "Activate", "Delete"};
            model.addRow(new Object[]{b.getId(), b.getName(), b.getIdNumber(), b.getEmail().isEmpty() ? "-" : b.getEmail(),
                b.getTypeLabel(), m.getActiveLoans() + " / " + m.getBorrowLimit(), b.isActive() ? "Active" : "Inactive",
                new TableActions(actions)});
        }
        applyFilter();
    }

    @Override
    public void applySearch(String text) {
        type.setSelectedIndex(0);
        status.setSelectedIndex(0);
        search.setText(text);
        applyFilter();
    }

    private void applyFilter() {
        String q = search.getText().trim().toLowerCase();
        String typeSel = String.valueOf(type.getSelectedItem());
        String statusSel = String.valueOf(status.getSelectedItem());
        table.getSorter().setRowFilter(new RowFilter<ReadOnlyTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends ReadOnlyTableModel, ? extends Integer> entry) {
                if (!"All types".equals(typeSel) && !typeSel.equals(String.valueOf(entry.getValue(4)))) {
                    return false;
                }
                if (!"All status".equals(statusSel) && !statusSel.equals(String.valueOf(entry.getValue(6)))) {
                    return false;
                }
                if (q.isEmpty()) {
                    return true;
                }
                for (int i = 0; i < 4; i++) {
                    if (String.valueOf(entry.getValue(i)).toLowerCase().contains(q)) {
                        return true;
                    }
                }
                return false;
            }
        });
        count.setText("Showing " + table.getRowCount() + " of " + borrowers.size() + " borrowers");
    }

    private Borrower borrowerAt(int modelRow) {
        int id = (Integer) table.getTableModel().getValueAt(modelRow, 0);
        for (Borrower b : borrowers) {
            if (b.getId() == id) {
                return b;
            }
        }
        return null;
    }

    private void view(int modelRow) {
        Borrower b = borrowerAt(modelRow);
        if (b != null) {
            BorrowerDetailsDialog.show(this, ctx, b);
        }
    }

    private void onAction(String action, int modelRow) {
        Borrower borrower = borrowerAt(modelRow);
        if (borrower == null) {
            return;
        }
        switch (action) {
            case "View":
                view(modelRow);
                break;
            case "Edit":
                if (BorrowerDialog.show(this, ctx.circulation(), borrower)) {
                    nav.toast("Borrower updated successfully.", true);
                    nav.dataChanged();
                }
                break;
            case "Deactivate":
            case "Activate":
                boolean activate = "Activate".equals(action);
                String verb = activate ? "reactivate" : "deactivate";
                if (Dialogs.confirm(this, activate ? "Activate borrower" : "Deactivate borrower",
                        "Do you want to " + verb + " " + borrower.getName() + "?"
                        + (activate ? "" : "\nThey will not be able to borrow books until reactivated."),
                        activate ? "Activate" : "Deactivate", !activate)) {
                    ctx.circulation().setBorrowerActive(borrower.getId(), activate);
                    nav.toast(borrower.getName() + (activate ? " is now active." : " has been deactivated."), true);
                    nav.dataChanged();
                }
                break;
            case "Delete":
                if (Dialogs.confirm(this, "Delete borrower", "Delete " + borrower.getName()
                        + "? Their past transactions will remain in the records.", "Delete", true)) {
                    try {
                        ctx.circulation().deleteBorrower(borrower.getId());
                        nav.toast("Borrower deleted.", true);
                        nav.dataChanged();
                    } catch (RuntimeException ex) {
                        Dialogs.error(this, ex.getMessage());
                    }
                }
                break;
            default:
                break;
        }
    }
}
