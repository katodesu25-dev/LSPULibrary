package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import lspulibrary.AppContext;
import lspulibrary.models.Borrowing;
import lspulibrary.services.LibraryStats;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Modules;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.BarChart;
import lspulibrary.ui.components.DonutChart;
import lspulibrary.ui.components.HBarChart;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.ScrollablePanel;
import lspulibrary.ui.components.StatCard;
import lspulibrary.ui.components.StyledTable;
import lspulibrary.ui.dialogs.BookDialog;
import lspulibrary.ui.dialogs.BorrowerDialog;

public class DashboardPanel extends ModulePanel {
    private static final long serialVersionUID = 1L;
    private final StatCard totalBooks = new StatCard("Total Books", Icons.BOOKS, Theme.NAVY_LIGHT);
    private final StatCard availableBooks = new StatCard("Available Books", Icons.CHECK, Theme.SUCCESS);
    private final StatCard borrowedBooks = new StatCard("Borrowed Books", Icons.BORROW, Theme.INFO);
    private final StatCard borrowers = new StatCard("Registered Borrowers", Icons.USERS, Theme.PURPLE);
    private final StatCard overdue = new StatCard("Overdue Books", Icons.WARNING, Theme.DANGER);
    private final StatCard transactions = new StatCard("Total Transactions", Icons.LIST, Theme.GOLD_DARK);
    private final BarChart activity = new BarChart();
    private final DonutChart availability = new DonutChart(Theme.SUCCESS, Theme.INFO);
    private final HBarChart popular = new HBarChart(Theme.GOLD, 34);
    private final StyledTable recent;

    public DashboardPanel(AppContext ctx, Navigator nav) {
        super(ctx, nav);
        add(UI.header("Dashboard", "A quick overview of today's library activity"), BorderLayout.NORTH);

        ReadOnlyTableModel model = new ReadOnlyTableModel(new String[]{"ID", "Book", "Borrower", "Borrowed", "Status"},
                new Class<?>[]{Integer.class, String.class, String.class, LocalDateTime.class, String.class});
        recent = new StyledTable(model);
        recent.setPillColumn(4);
        recent.setRowHeight(38);
        recent.setColumnWidths(60, 190, 140, 110, 96);

        JPanel stats = new JPanel(new lspulibrary.ui.components.ResponsiveGrid(155, 14, 14, 6));
        stats.setOpaque(false);
        stats.add(totalBooks);
        stats.add(availableBooks);
        stats.add(borrowedBooks);
        stats.add(borrowers);
        stats.add(overdue);
        stats.add(transactions);

        activity.setPreferredSize(new Dimension(300, 230));
        availability.setPreferredSize(new Dimension(280, 230));

        var recentScroll = UI.scroll(recent);
        recentScroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        recentScroll.setPreferredSize(new Dimension(500, 40 + 7 * 38 + 2));

        JPanel actions = new JPanel(new GridLayout(2, 2, 10, 10));
        actions.setOpaque(false);
        ModernButton addBook = new ModernButton("Add Book", ModernButton.Style.PRIMARY, Icons.PLUS);
        addBook.addActionListener(e -> {
            if (BookDialog.show(this, ctx.circulation(), null)) {
                nav.toast("Book added successfully.", true);
                nav.dataChanged();
            }
        });
        ModernButton addBorrower = new ModernButton("Add Borrower", ModernButton.Style.SECONDARY, Icons.USERS);
        addBorrower.addActionListener(e -> {
            if (BorrowerDialog.show(this, ctx.circulation(), null)) {
                nav.toast("Borrower registered successfully.", true);
                nav.dataChanged();
            }
        });
        ModernButton borrow = new ModernButton("Borrow Book", ModernButton.Style.OUTLINE, Icons.BORROW);
        borrow.addActionListener(e -> nav.navigate(Modules.BORROW));
        ModernButton giveBack = new ModernButton("Return Book", ModernButton.Style.OUTLINE, Icons.RETURN);
        giveBack.addActionListener(e -> nav.navigate(Modules.RETURN));
        actions.add(addBook);
        actions.add(addBorrower);
        actions.add(borrow);
        actions.add(giveBack);

        JPanel rightColumn = new JPanel(new GridBagLayout());
        rightColumn.setOpaque(false);
        GridBagConstraints rc = new GridBagConstraints();
        rc.fill = GridBagConstraints.BOTH;
        rc.weightx = 1;
        rc.gridx = 0;
        rc.weighty = 1;
        rc.insets = new Insets(0, 0, 14, 0);
        rightColumn.add(UI.card("Popular books", popular), rc);
        rc.gridy = 1;
        rc.weighty = 0;
        rc.insets = new Insets(0, 0, 0, 0);
        rightColumn.add(UI.card("Quick actions", actions), rc);

        ScrollablePanel root = new ScrollablePanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        c.weightx = 1;
        c.insets = new Insets(0, 0, 16, 0);
        root.add(stats, c);

        c.gridy = 1;
        c.gridwidth = 1;
        c.weightx = 2;
        c.insets = new Insets(0, 0, 16, 8);
        root.add(UI.card("Borrowing activity - last 7 days", activity), c);
        c.gridx = 1;
        c.weightx = 1;
        c.insets = new Insets(0, 8, 16, 0);
        root.add(UI.card("Book availability overview", availability), c);

        c.gridx = 0;
        c.gridy = 2;
        c.weightx = 2;
        c.weighty = 1;
        c.insets = new Insets(0, 0, 8, 8);
        root.add(UI.card("Recent borrowing transactions", recentScroll), c);
        c.gridx = 1;
        c.weightx = 1;
        c.insets = new Insets(0, 8, 8, 0);
        root.add(rightColumn, c);

        add(UI.pageScroll(root), BorderLayout.CENTER);
    }

    @Override
    public void refresh() {
        LibraryStats s = ctx.reports().snapshot();
        totalBooks.setValue(String.valueOf(s.totalCopies));
        totalBooks.setNote(s.titles + " titles");
        availableBooks.setValue(String.valueOf(s.availableCopies));
        availableBooks.setNote(s.totalCopies == 0 ? "" : Math.round(100.0 * s.availableCopies / s.totalCopies) + "% on the shelf");
        borrowedBooks.setValue(String.valueOf(s.activeLoans));
        borrowedBooks.setNote("currently on loan");
        borrowers.setValue(String.valueOf(s.borrowers));
        borrowers.setNote(s.activeBorrowers + " with active loans");
        overdue.setValue(String.valueOf(s.overdue));
        overdue.setNote(s.overdue == 0 ? "all on schedule" : "need follow-up");
        transactions.setValue(String.valueOf(s.transactions));
        transactions.setNote(s.returned + " returned");

        Map<String, int[]> days = ctx.reports().activityLastDays(7);
        List<String> labels = new ArrayList<>(days.keySet());
        double[][] values = new double[2][labels.size()];
        int i = 0;
        for (int[] v : days.values()) {
            values[0][i] = v[0];
            values[1][i] = v[1];
            i++;
        }
        activity.setData(labels, new String[]{"Borrowed", "Returned"}, values);

        Map<String, Integer> split = new LinkedHashMap<>();
        split.put("Available", s.availableCopies);
        split.put("Borrowed", s.totalCopies - s.availableCopies);
        availability.setData(split, "copies");

        popular.setData(ctx.reports().mostBorrowed(5));

        ReadOnlyTableModel model = recent.getTableModel();
        model.setRowCount(0);
        LocalDateTime now = LocalDateTime.now();
        for (Borrowing b : ctx.reports().recentTransactions(7)) {
            model.addRow(new Object[]{b.getId(), b.getBook().getTitle(), b.getBorrower().getName(), b.getBorrowedAt(),
                b.statusAt(now)});
        }
    }
}
