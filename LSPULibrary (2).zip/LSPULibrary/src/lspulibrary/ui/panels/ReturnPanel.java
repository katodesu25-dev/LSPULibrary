package lspulibrary.ui.panels;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.RowFilter;
import javax.swing.SpinnerDateModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import lspulibrary.AppContext;
import lspulibrary.models.Borrowing;
import lspulibrary.ui.Dialogs;
import lspulibrary.ui.Icons;
import lspulibrary.ui.Navigator;
import lspulibrary.ui.Theme;
import lspulibrary.ui.UI;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.ReadOnlyTableModel;
import lspulibrary.ui.components.RoundedPanel;
import lspulibrary.ui.components.ScrollablePanel;
import lspulibrary.ui.components.StyledTable;
import lspulibrary.ui.components.StyledTextField;
import lspulibrary.util.Format;

public class ReturnPanel extends ModulePanel {
    private static final long serialVersionUID = 1L;
    private final StyledTextField search = new StyledTextField(26, "Search by transaction ID, book or borrower...", true);
    private final StyledTable table;
    private final JLabel txn = value();
    private final JLabel book = value();
    private final JLabel borrower = value();
    private final JLabel borrowedOn = value();
    private final JLabel dueOn = value();
    private final JLabel overdueDays = value();
    private final JLabel rate = value();
    private final JLabel fineAmount = UI.label("-", Theme.bold(28), Theme.NAVY);
    private final JLabel fineNote = UI.label(" ", Theme.regular(12), Theme.MUTED);
    private final JSpinner returnDate = new JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.DAY_OF_MONTH));
    private final ModernButton process = new ModernButton("Process Return", ModernButton.Style.PRIMARY, Icons.RETURN);
    private List<Borrowing> loans = new ArrayList<>();
    private boolean loading;

    public ReturnPanel(AppContext ctx, Navigator nav) {
        super(ctx, nav);
        add(UI.header("Return Books", "Find a borrowed book, review the fine and process the return"), BorderLayout.NORTH);

        ReadOnlyTableModel model = new ReadOnlyTableModel(
                new String[]{"ID", "Book", "Borrower", "Borrowed", "Due", "Status", "Days late"},
                new Class<?>[]{Integer.class, String.class, String.class, LocalDateTime.class, LocalDateTime.class,
                    String.class, Integer.class});
        table = new StyledTable(model);
        table.setPillColumn(5);
        table.setRowHeight(38);
        table.setColumnWidths(60, 230, 160, 140, 140, 100, 80);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !loading) {
                resetReturnDate();
                updateDetails();
            }
        });
        search.getDocument().addDocumentListener(new DocumentListener() {
            private void apply() {
                String q = search.getText().trim().toLowerCase();
                table.getSorter().setRowFilter(q.isEmpty() ? null : new RowFilter<ReadOnlyTableModel, Integer>() {
                    @Override
                    public boolean include(Entry<? extends ReadOnlyTableModel, ? extends Integer> entry) {
                        for (int col = 0; col < 3; col++) {
                            if (String.valueOf(entry.getValue(col)).toLowerCase().contains(q)) {
                                return true;
                            }
                        }
                        return false;
                    }
                });
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                apply();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                apply();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                apply();
            }
        });

        JSpinner.DateEditor editor = new JSpinner.DateEditor(returnDate, "yyyy-MM-dd");
        returnDate.setEditor(editor);
        returnDate.setFont(Theme.regular(13));
        returnDate.setBorder(BorderFactory.createCompoundBorder(
                new javax.swing.border.LineBorder(Theme.BORDER, 1, true), BorderFactory.createEmptyBorder(4, 6, 4, 2)));
        returnDate.setPreferredSize(new Dimension(150, 38));
        lspulibrary.ui.components.StyledSpinnerUI.install(returnDate);
        returnDate.addChangeListener(e -> {
            if (!loading) {
                updateDetails();
            }
        });

        search.setPreferredSize(new Dimension(100, 40));
        JPanel listContent = new JPanel(new BorderLayout(0, 10));
        listContent.setOpaque(false);
        listContent.add(search, BorderLayout.NORTH);
        var scroll = UI.scroll(table);
        scroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        scroll.setPreferredSize(new Dimension(600, 230));
        listContent.add(scroll, BorderLayout.CENTER);

        JPanel grid = new JPanel(new GridLayout(2, 4, 16, 14));
        grid.setOpaque(false);
        grid.add(block("Transaction", txn));
        grid.add(block("Book", book));
        grid.add(block("Borrower", borrower));
        grid.add(block("Borrowed on", borrowedOn));
        grid.add(block("Due date", dueOn));
        JPanel dateBlock = new JPanel();
        dateBlock.setOpaque(false);
        dateBlock.setLayout(new BoxLayout(dateBlock, BoxLayout.Y_AXIS));
        dateBlock.add(left(UI.label("Return date", Theme.regular(11), Theme.MUTED)));
        dateBlock.add(javax.swing.Box.createVerticalStrut(3));
        dateBlock.add(left(returnDate));
        grid.add(dateBlock);
        grid.add(block("Days overdue", overdueDays));
        grid.add(block("Fine rate", rate));

        process.addActionListener(e -> processReturn());
        RoundedPanel finePanel = new RoundedPanel(14, new java.awt.Color(0xF8FAFC), Theme.BORDER, false);
        finePanel.setLayout(new BorderLayout(0, 6));
        finePanel.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        finePanel.add(UI.label("Fine to collect", Theme.bold(12), Theme.TEXT), BorderLayout.NORTH);
        JPanel fineCenter = new JPanel(new BorderLayout());
        fineCenter.setOpaque(false);
        fineCenter.add(fineAmount, BorderLayout.NORTH);
        fineCenter.add(fineNote, BorderLayout.CENTER);
        finePanel.add(fineCenter, BorderLayout.CENTER);
        finePanel.add(process, BorderLayout.SOUTH);
        finePanel.setPreferredSize(new Dimension(250, 150));

        JPanel detailContent = new JPanel(new BorderLayout(24, 0));
        detailContent.setOpaque(false);
        detailContent.add(grid, BorderLayout.CENTER);
        detailContent.add(finePanel, BorderLayout.EAST);

        ScrollablePanel root = new ScrollablePanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1;
        c.gridx = 0;
        c.weighty = 1;
        c.insets = new Insets(0, 0, 16, 0);
        root.add(UI.card("Borrowed books awaiting return", listContent), c);
        c.gridy = 1;
        c.weighty = 0;
        c.insets = new Insets(0, 0, 8, 0);
        root.add(UI.card("Return details", detailContent), c);
        add(UI.pageScroll(root), BorderLayout.CENTER);
        updateDetails();
    }

    private JLabel value() {
        return UI.label("-", Theme.bold(14), Theme.TEXT_STRONG);
    }

    private static JComponent left(JComponent c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        return c;
    }

    private JComponent block(String caption, JLabel value) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(left(UI.label(caption, Theme.regular(11), Theme.MUTED)));
        p.add(javax.swing.Box.createVerticalStrut(3));
        p.add(left(value));
        return p;
    }

    @Override
    public void refresh() {
        Borrowing previous = selected();
        loading = true;
        loans = ctx.circulation().getActiveLoans();
        loans.sort(java.util.Comparator.comparing(Borrowing::getDueAt));
        LocalDateTime now = LocalDateTime.now();
        ReadOnlyTableModel model = table.getTableModel();
        model.setRowCount(0);
        for (Borrowing b : loans) {
            model.addRow(new Object[]{b.getId(), b.getBook().getTitle(), b.getBorrower().getName(), b.getBorrowedAt(),
                b.getDueAt(), b.statusAt(now), b.daysOverdue(now)});
        }
        loading = false;
        if (previous != null) {
            selectById(previous.getId());
        } else {
            updateDetails();
        }
    }

    @Override
    public void applySearch(String text) {
        if (text != null && text.startsWith("id:")) {
            search.setText("");
            selectById(Integer.parseInt(text.substring(3).trim()));
        } else {
            search.setText(text);
        }
    }

    private void selectById(int id) {
        for (int i = 0; i < loans.size(); i++) {
            if (loans.get(i).getId() == id) {
                int view = table.convertRowIndexToView(i);
                if (view >= 0) {
                    table.setRowSelectionInterval(view, view);
                    table.scrollRectToVisible(table.getCellRect(view, 0, true));
                }
                return;
            }
        }
        updateDetails();
    }

    private Borrowing selected() {
        int row = table.selectedModelRow();
        return row >= 0 && row < loans.size() ? loans.get(row) : null;
    }

    private void resetReturnDate() {
        loading = true;
        returnDate.setValue(new Date());
        loading = false;
    }

    private LocalDateTime chosenReturnTime() {
        Date date = (Date) returnDate.getValue();
        LocalDate day = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDateTime now = LocalDateTime.now();
        return day.equals(now.toLocalDate()) ? now : day.atTime(now.toLocalTime());
    }

    private void updateDetails() {
        Borrowing b = selected();
        if (b == null) {
            for (JLabel l : new JLabel[]{txn, book, borrower, borrowedOn, dueOn, overdueDays, rate}) {
                l.setText("-");
            }
            fineAmount.setText("-");
            fineNote.setText("Select a transaction above");
            process.setEnabled(false);
            return;
        }
        LocalDateTime when = chosenReturnTime();
        int late = b.daysOverdue(when);
        double fine = ctx.circulation().previewFine(b, when);
        txn.setText("#" + b.getId());
        book.setText(shorten(b.getBook().getTitle(), 26));
        borrower.setText(b.getBorrower().getName() + " (" + b.getBorrower().getTypeLabel() + ")");
        borrowedOn.setText(Format.dateTime(b.getBorrowedAt()));
        dueOn.setText(Format.dateTime(b.getDueAt()));
        overdueDays.setText(late == 0 ? "On time" : Format.plural(late, "day"));
        overdueDays.setForeground(late == 0 ? Theme.SUCCESS : Theme.DANGER);
        rate.setText(Format.peso(b.getBorrower().asMember(0).getFinePerDay()) + " per day");
        fineAmount.setText(Format.peso(fine));
        fineAmount.setForeground(fine > 0 ? Theme.DANGER : Theme.NAVY);
        fineNote.setText(fine > 0 ? "Overdue by " + Format.plural(late, "day") : "No fine - returned on time");
        process.setEnabled(true);
    }

    private static String shorten(String text, int max) {
        return text.length() <= max ? text : text.substring(0, max - 3) + "...";
    }

    private void processReturn() {
        Borrowing b = selected();
        if (b == null) {
            Dialogs.error(this, "Select a transaction to return first.");
            return;
        }
        LocalDateTime when = chosenReturnTime();
        if (when.isBefore(b.getBorrowedAt())) {
            Dialogs.error(this, "The return date cannot be earlier than the borrowing date ("
                    + Format.date(b.getBorrowedAt()) + ").");
            return;
        }
        double fine = ctx.circulation().previewFine(b, when);
        String message = "Return \"" + b.getBook().getTitle() + "\" from " + b.getBorrower().getName() + "?"
                + (fine > 0 ? "\nA fine of " + Format.peso(fine) + " applies." : "\nNo fine applies.");
        if (!Dialogs.confirm(this, "Confirm return", message, "Process return", false)) {
            return;
        }
        try {
            Borrowing done = ctx.circulation().returnBook(b.getId(), when);
            nav.dataChanged();
            Dialogs.success(this, "Book returned", "Transaction #" + done.getId() + " is complete.\n\""
                    + done.getBook().getTitle() + "\" was returned by " + done.getBorrower().getName() + ".\n"
                    + "Days overdue: " + done.daysOverdue(done.getReturnedAt()) + "\nFine: " + Format.peso(done.getFine())
                    + "\nCopies available again: " + ctx.circulation().findBook(done.getBook().getId()).getAvailableCopies());
        } catch (RuntimeException ex) {
            Dialogs.error(this, ex.getMessage());
            refresh();
        }
    }
}
