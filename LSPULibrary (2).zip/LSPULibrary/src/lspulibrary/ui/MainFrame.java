package lspulibrary.ui;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import lspulibrary.AppContext;
import lspulibrary.models.Administrator;

public class MainFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    public MainFrame(AppContext ctx, Administrator admin, Runnable onLogout) {
        super("LSPU Library Borrowing Management System");
        setIconImage(LogoPanel.windowIcon());
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        Runnable exit = () -> {
            dispose();
            ctx.close();
            System.exit(0);
        };
        Runnable logout = () -> {
            dispose();
            onLogout.run();
        };
        setContentPane(new AppShell(ctx, admin, logout, exit));

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (Dialogs.confirm(MainFrame.this, "Exit application", "Close the Library Borrowing Management System?",
                        "Exit", false)) {
                    exit.run();
                }
            }
        });

        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int width = Math.min(1440, (int) (screen.width * 0.94));
        int height = Math.min(880, (int) (screen.height * 0.92));
        setMinimumSize(new Dimension(Math.min(1100, screen.width), Math.min(680, screen.height)));
        setBounds(new Rectangle((screen.width - width) / 2, (screen.height - height) / 2, width, height));
    }
}
