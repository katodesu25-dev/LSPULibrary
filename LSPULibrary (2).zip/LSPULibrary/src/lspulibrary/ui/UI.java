package lspulibrary.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;
import lspulibrary.ui.components.RoundedPanel;
import lspulibrary.ui.components.SlimScrollBarUI;
import lspulibrary.ui.components.StyledComboBoxUI;

public final class UI {
    private UI() {
    }

    public static JLabel label(String text, Font font, java.awt.Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font);
        l.setForeground(color);
        return l;
    }

    public static JLabel sectionTitle(String text) {
        return label(text, Theme.bold(15), Theme.NAVY);
    }

    public static JScrollPane scroll(Component view) {
        JScrollPane pane = new JScrollPane(view);
        if (view instanceof javax.swing.JTable) {
            pane.setColumnHeaderView(((javax.swing.JTable) view).getTableHeader());
            JPanel corner = new JPanel();
            corner.setBackground(Theme.NAVY);
            pane.setCorner(JScrollPane.UPPER_RIGHT_CORNER, corner);
        }
        pane.setBorder(BorderFactory.createEmptyBorder());
        pane.getViewport().setBackground(Theme.WHITE);
        pane.getVerticalScrollBar().setUI(new SlimScrollBarUI());
        pane.getHorizontalScrollBar().setUI(new SlimScrollBarUI());
        pane.getVerticalScrollBar().setUnitIncrement(18);
        pane.setOpaque(false);
        return pane;
    }

    public static JScrollPane pageScroll(JComponent view) {
        JScrollPane pane = scroll(view);
        pane.getViewport().setOpaque(false);
        pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        return pane;
    }

    public static <T> JComboBox<T> combo(T[] items) {
        JComboBox<T> box = new JComboBox<>(items);
        StyledComboBoxUI.install(box);
        return box;
    }

    public static JSpinner spinner(int value, int min, int max) {
        JSpinner spinner = new JSpinner(new SpinnerNumberModel(value, min, max, 1));
        spinner.setFont(Theme.regular(13));
        spinner.setBorder(BorderFactory.createCompoundBorder(
                new javax.swing.border.LineBorder(Theme.BORDER, 1, true), new EmptyBorder(4, 6, 4, 2)));
        spinner.setPreferredSize(new Dimension(120, 38));
        lspulibrary.ui.components.StyledSpinnerUI.install(spinner);
        return spinner;
    }

    public static JPanel header(String title, String subtitle, Component... actions) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(0, 0, 18, 0));

        JPanel texts = new JPanel();
        texts.setOpaque(false);
        texts.setLayout(new BoxLayout(texts, BoxLayout.Y_AXIS));
        JLabel t = label(title, Theme.bold(24), Theme.NAVY);
        JLabel s = label(subtitle, Theme.regular(13), Theme.MUTED);
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        s.setAlignmentX(Component.LEFT_ALIGNMENT);
        texts.add(t);
        texts.add(javax.swing.Box.createVerticalStrut(2));
        texts.add(s);
        panel.add(texts, BorderLayout.WEST);

        if (actions.length > 0) {
            JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            right.setOpaque(false);
            for (Component a : actions) {
                right.add(a);
            }
            panel.add(right, BorderLayout.EAST);
        }
        return panel;
    }

    public static JPanel transparent(java.awt.LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setOpaque(false);
        return p;
    }

    public static RoundedPanel card(String title, JComponent content, Component... headerRight) {
        RoundedPanel card = RoundedPanel.card(new BorderLayout(0, 12), 16);
        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.add(sectionTitle(title), BorderLayout.WEST);
        if (headerRight.length > 0) {
            JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            right.setOpaque(false);
            for (Component c : headerRight) {
                right.add(c);
            }
            head.add(right, BorderLayout.EAST);
        }
        card.add(head, BorderLayout.NORTH);
        card.add(content, BorderLayout.CENTER);
        return card;
    }

    public static JPanel toolbar(Component... left) {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bar.setOpaque(false);
        for (Component c : left) {
            bar.add(c);
        }
        return bar;
    }
}
