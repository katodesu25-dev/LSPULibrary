package lspulibrary.ui;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;

public class LogoPanel extends JComponent {
    private static final long serialVersionUID = 1L;
    private final float scale;

    public LogoPanel(float scale) {
        this.scale = scale;
        setOpaque(false);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension((int) (190 * scale), (int) (56 * scale));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        int box = (int) (46 * scale);
        int y = (getHeight() - box) / 2;
        g2.setColor(Theme.GOLD);
        g2.fillRoundRect(0, y, box, box, (int) (14 * scale), (int) (14 * scale));
        int icon = (int) (28 * scale);
        Icons.paint((Graphics2D) g2.create((box - icon) / 2, y + (box - icon) / 2, icon, icon), Icons.BOOKS, icon, Theme.NAVY);

        int textX = box + (int) (12 * scale);
        g2.setFont(Theme.bold(22 * scale));
        FontMetrics fm = g2.getFontMetrics();
        g2.setColor(Theme.WHITE);
        g2.drawString("LSPU", textX, y + (int) (22 * scale));
        g2.setFont(Theme.bold(11 * scale));
        g2.setColor(Theme.GOLD);
        g2.drawString("L I B R A R Y", textX, y + (int) (40 * scale));
        g2.dispose();
    }

    public static BufferedImage windowIcon() {
        BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Theme.NAVY);
        g2.fillRoundRect(0, 0, 64, 64, 18, 18);
        Icons.paint((Graphics2D) g2.create(10, 10, 44, 44), Icons.BOOKS, 44, Theme.GOLD);
        g2.dispose();
        return img;
    }
}
