package lspulibrary.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

public final class Toast extends JComponent {
    private static final long serialVersionUID = 1L;
    private static final String KEY = "lspu.toast";
    private final Color accent;

    private Toast(String message, boolean success) {
        this.accent = success ? Theme.SUCCESS : Theme.DANGER;
        setLayout(new java.awt.BorderLayout());
        setBorder(new EmptyBorder(14, 22, 14, 20));
        JLabel label = new JLabel("<html><body style='width:280px'>" + message.replace("<", "&lt;").replace("\n", "<br>")
                + "</body></html>");
        label.setFont(Theme.bold(13));
        label.setForeground(Theme.TEXT_STRONG);
        add(label);
    }

    public static void show(Component anchor, String message, boolean success) {
        JRootPane root = anchor == null ? null : SwingUtilities.getRootPane(anchor);
        if (root == null) {
            return;
        }
        JLayeredPane layer = root.getLayeredPane();
        Object previous = root.getClientProperty(KEY);
        if (previous instanceof Toast) {
            layer.remove((Toast) previous);
        }
        Toast toast = new Toast(message, success);
        Dimension size = toast.getPreferredSize();
        toast.setBounds(layer.getWidth() - size.width - 28, layer.getHeight() - size.height - 28, size.width, size.height);
        layer.add(toast, JLayeredPane.POPUP_LAYER);
        root.putClientProperty(KEY, toast);
        layer.repaint();
        Timer timer = new Timer(3600, e -> {
            layer.remove(toast);
            layer.repaint();
        });
        timer.setRepeats(false);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(15, 23, 42, 30));
        g2.fillRoundRect(0, 3, getWidth(), getHeight() - 3, 16, 16);
        g2.setColor(Theme.WHITE);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 4, 14, 14);
        g2.setColor(Theme.BORDER);
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 4, 14, 14);
        g2.setColor(accent);
        g2.fillRoundRect(0, 0, 8, getHeight() - 3, 8, 8);
        g2.fillRect(4, 0, 6, getHeight() - 3);
        g2.setColor(Theme.WHITE);
        g2.fillRect(8, 1, 4, getHeight() - 5);
        g2.dispose();
        super.paintComponent(g);
    }

    @Override
    public boolean contains(int x, int y) {
        return super.contains(x, y);
    }
}
