package lspulibrary.ui;

public final class Modules {
    public static final String DASHBOARD = "dashboard";
    public static final String BOOKS = "books";
    public static final String BORROWERS = "borrowers";
    public static final String BORROW = "borrow";
    public static final String RETURN = "return";
    public static final String TRANSACTIONS = "transactions";
    public static final String REPORTS = "reports";
    public static final String SETTINGS = "settings";

    private Modules() {
    }
}
