package lspulibrary.ui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import lspulibrary.AppContext;
import lspulibrary.models.Administrator;
import lspulibrary.ui.dialogs.SearchResultsDialog;
import lspulibrary.ui.panels.BooksPanel;
import lspulibrary.ui.panels.BorrowPanel;
import lspulibrary.ui.panels.BorrowersPanel;
import lspulibrary.ui.panels.DashboardPanel;
import lspulibrary.ui.panels.ModulePanel;
import lspulibrary.ui.panels.ReportsPanel;
import lspulibrary.ui.panels.ReturnPanel;
import lspulibrary.ui.panels.SettingsPanel;
import lspulibrary.ui.panels.TransactionsPanel;

public class AppShell extends JPanel implements Navigator {
    private static final long serialVersionUID = 1L;
    private final AppContext ctx;
    private final Administrator admin;
    private final Runnable onLogout;
    private final Runnable onExit;
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final Map<String, ModulePanel> modules = new LinkedHashMap<>();
    private final Sidebar sidebar;
    private final TopBar topBar;
    private String current = Modules.DASHBOARD;

    public AppShell(AppContext ctx, Administrator admin, Runnable onLogout, Runnable onExit) {
        super(new BorderLayout());
        this.ctx = ctx;
        this.admin = admin;
        this.onLogout = onLogout;
        this.onExit = onExit;
        setBackground(Theme.BACKGROUND);

        sidebar = new Sidebar(this::navigate, this::confirmLogoutOrExit);
        topBar = new TopBar(ctx, this, admin, this::globalSearch);
        content.setBackground(Theme.BACKGROUND);

        register(Modules.DASHBOARD, new DashboardPanel(ctx, this));
        register(Modules.BOOKS, new BooksPanel(ctx, this));
        register(Modules.BORROWERS, new BorrowersPanel(ctx, this));
        register(Modules.BORROW, new BorrowPanel(ctx, this));
        register(Modules.RETURN, new ReturnPanel(ctx, this));
        register(Modules.TRANSACTIONS, new TransactionsPanel(ctx, this));
        register(Modules.REPORTS, new ReportsPanel(ctx, this));
        register(Modules.SETTINGS, new SettingsPanel(ctx, this));

        JPanel main = new JPanel(new BorderLayout());
        main.setOpaque(false);
        main.add(topBar, BorderLayout.NORTH);
        main.add(content, BorderLayout.CENTER);

        add(sidebar, BorderLayout.WEST);
        add(main, BorderLayout.CENTER);
        navigate(Modules.DASHBOARD);
    }

    private void register(String key, ModulePanel panel) {
        modules.put(key, panel);
        content.add(panel, key);
    }

    @Override
    public void navigate(String module) {
        ModulePanel panel = modules.get(module);
        if (panel == null) {
            return;
        }
        current = module;
        panel.refresh();
        cards.show(content, module);
        sidebar.setActive(module);
        topBar.updateNotifications();
    }

    @Override
    public void navigate(String module, String search) {
        navigate(module);
        ModulePanel panel = modules.get(module);
        if (panel != null) {
            panel.applySearch(search);
        }
    }

    @Override
    public void dataChanged() {
        ModulePanel panel = modules.get(current);
        if (panel != null) {
            panel.refresh();
        }
        topBar.updateNotifications();
    }

    @Override
    public void toast(String message, boolean success) {
        Toast.show(this, message, success);
    }

    @Override
    public Component dialogParent() {
        return this;
    }

    @Override
    public Administrator administrator() {
        return admin;
    }

    @Override
    public void logout() {
        if (Dialogs.confirm(this, "Log out", "Do you want to log out of the system?", "Log out", false)) {
            onLogout.run();
        }
    }

    private void confirmLogoutOrExit() {
        int choice = lspulibrary.ui.dialogs.ExitChoiceDialog.ask(this);
        if (choice == 1) {
            onLogout.run();
        } else if (choice == 2) {
            onExit.run();
        }
    }

    private void globalSearch(String query) {
        SearchResultsDialog.show(this, ctx, query, this);
    }

    public Component window() {
        return SwingUtilities.getWindowAncestor(this);
    }
}
