package lspulibrary.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Window;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import lspulibrary.ui.components.ModernButton;

public final class Dialogs {
    private enum Kind { SUCCESS, ERROR, INFO, CONFIRM, DANGER }

    private Dialogs() {
    }

    public static void success(Component parent, String title, String message) {
        show(parent, Kind.SUCCESS, title, message, "OK", null);
    }

    public static void info(Component parent, String title, String message) {
        show(parent, Kind.INFO, title, message, "OK", null);
    }

    public static void error(Component parent, String message) {
        show(parent, Kind.ERROR, "Action not completed", message, "OK", null);
    }

    public static boolean confirm(Component parent, String title, String message, String confirmLabel, boolean danger) {
        return show(parent, danger ? Kind.DANGER : Kind.CONFIRM, title, message, confirmLabel, "Cancel");
    }

    private static boolean show(Component parent, Kind kind, String title, String message, String okLabel,
                                String cancelLabel) {
        Window owner = parent == null ? null : SwingUtilities.getWindowAncestor(parent);
        JDialog dialog = new JDialog(owner, title, JDialog.ModalityType.APPLICATION_MODAL);
        final boolean[] result = {false};

        java.awt.Color color = kind == Kind.SUCCESS ? Theme.SUCCESS
                : kind == Kind.ERROR || kind == Kind.DANGER ? Theme.DANGER
                : kind == Kind.CONFIRM ? Theme.GOLD_DARK : Theme.INFO;

        JComponent badge = new JComponent() {
            private static final long serialVersionUID = 1L;

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(52, 52);
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(Theme.alpha(color, 30));
                g2.fillOval(0, 0, 52, 52);
                if (kind == Kind.SUCCESS) {
                    Icons.paint((Graphics2D) g2.create(14, 14, 24, 24), Icons.CHECK, 24, color);
                } else if (kind == Kind.ERROR || kind == Kind.DANGER) {
                    Icons.paint((Graphics2D) g2.create(14, 14, 24, 24), Icons.WARNING, 24, color);
                } else {
                    g2.setColor(color);
                    g2.setFont(Theme.bold(24));
                    String symbol = kind == Kind.CONFIRM ? "?" : "i";
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(symbol, (52 - fm.stringWidth(symbol)) / 2, 34);
                }
                g2.dispose();
            }
        };

        JLabel heading = UI.label(title, Theme.bold(16), Theme.NAVY);
        String html = "<html><body style='width:300px'>" + message.replace("&", "&amp;").replace("<", "&lt;")
                .replace("\n", "<br>") + "</body></html>";
        JLabel text = UI.label(html, Theme.regular(13), Theme.TEXT);

        JPanel textBox = new JPanel(new BorderLayout(0, 8));
        textBox.setOpaque(false);
        textBox.add(heading, BorderLayout.NORTH);
        textBox.add(text, BorderLayout.CENTER);

        JPanel badgeHolder = new JPanel(new BorderLayout());
        badgeHolder.setOpaque(false);
        badgeHolder.add(badge, BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(18, 0));
        body.setBackground(Theme.WHITE);
        body.setBorder(new EmptyBorder(26, 26, 18, 26));
        body.add(badgeHolder, BorderLayout.WEST);
        body.add(textBox, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        footer.setBackground(Theme.WHITE);
        footer.setBorder(new EmptyBorder(0, 20, 18, 20));
        if (cancelLabel != null) {
            ModernButton cancel = new ModernButton(cancelLabel, ModernButton.Style.OUTLINE);
            cancel.addActionListener(e -> dialog.dispose());
            footer.add(cancel);
        }
        ModernButton ok = new ModernButton(okLabel, kind == Kind.DANGER || kind == Kind.ERROR
                ? ModernButton.Style.DANGER : ModernButton.Style.PRIMARY);
        if (kind == Kind.SUCCESS || kind == Kind.INFO) {
            ok = new ModernButton(okLabel, ModernButton.Style.SECONDARY);
        }
        ok.addActionListener(e -> {
            result[0] = true;
            dialog.dispose();
        });
        footer.add(ok);

        dialog.getContentPane().setBackground(Theme.WHITE);
        dialog.getContentPane().add(body, BorderLayout.CENTER);
        dialog.getContentPane().add(footer, BorderLayout.SOUTH);
        dialog.getRootPane().setDefaultButton(ok);
        dialog.setResizable(false);
        dialog.pack();
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
        return result[0];
    }
}
