package lspulibrary.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import lspulibrary.AppContext;
import lspulibrary.models.Administrator;
import lspulibrary.models.Borrowing;
import lspulibrary.ui.components.StyledTextField;
import lspulibrary.util.Format;

public class TopBar extends JPanel {
    private static final long serialVersionUID = 1L;
    private final AppContext ctx;
    private final Navigator nav;
    private final JLabel clock = UI.label("", Theme.regular(11), Theme.MUTED);
    private final Bell bell = new Bell();
    private final StyledTextField search = new StyledTextField(26, "Search books, borrowers, transactions...", true);

    public TopBar(AppContext ctx, Navigator nav, Administrator admin, Consumer<String> onSearch) {
        this.ctx = ctx;
        this.nav = nav;
        setBackground(Theme.WHITE);
        setLayout(new BorderLayout(16, 0));
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER), new EmptyBorder(10, 26, 10, 22)));
        setPreferredSize(new Dimension(100, 68));

        JPanel left = UI.transparent(new FlowLayout(FlowLayout.LEFT, 0, 0));
        JPanel titleBox = UI.transparent(new BorderLayout());
        titleBox.add(UI.label("LSPU Library Borrowing Management System", Theme.bold(15), Theme.NAVY), BorderLayout.NORTH);
        JLabel mode = UI.label(ctx.isPersistent() ? "Laguna State Polytechnic University"
                : "Temporary data - changes will not be saved", Theme.regular(11),
                ctx.isPersistent() ? Theme.MUTED : Theme.WARNING);
        titleBox.add(mode, BorderLayout.SOUTH);
        left.add(titleBox);
        add(left, BorderLayout.WEST);

        JPanel center = UI.transparent(new lspulibrary.ui.components.ClampLayout(420));
        search.setPreferredSize(new Dimension(420, 40));
        search.setMinimumSize(new Dimension(140, 40));
        search.addActionListener(e -> {
            String q = search.getText().trim();
            if (!q.isEmpty()) {
                onSearch.accept(q);
            }
        });
        center.add(search);
        add(center, BorderLayout.CENTER);

        JPanel right = UI.transparent(new FlowLayout(FlowLayout.RIGHT, 16, 0));
        clock.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        right.add(clock);
        right.add(bell);
        right.add(new Profile(admin));
        add(right, BorderLayout.EAST);

        updateClock();
        Timer timer = new Timer(1000, e -> updateClock());
        timer.setInitialDelay(0);
        timer.start();
        updateNotifications();
    }

    private void updateClock() {
        LocalDateTime now = LocalDateTime.now();
        clock.setText("<html><div style='text-align:right'><b style='color:#111827'>" + Format.clockTime(now)
                + "</b><br><span style='color:#6B7280'>" + Format.clockDate(now) + "</span></div></html>");
    }

    public void focusSearch() {
        search.requestFocusInWindow();
    }

    public void updateNotifications() {
        bell.setCount(ctx.reports().overdueLoans().size());
    }

    private void showOverduePopup(Component anchor) {
        List<Borrowing> overdue = ctx.reports().overdueLoans();
        LocalDateTime now = LocalDateTime.now();
        JPopupMenu menu = new JPopupMenu();
        menu.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        menu.setBackground(Theme.WHITE);
        JLabel title = UI.label(overdue.isEmpty() ? "No overdue books" : Format.plural(overdue.size(), "overdue book"),
                Theme.bold(13), Theme.NAVY);
        title.setBorder(new EmptyBorder(10, 14, 8, 14));
        menu.add(title);
        for (int i = 0; i < Math.min(6, overdue.size()); i++) {
            Borrowing b = overdue.get(i);
            JMenuItem item = new JMenuItem("<html><b>" + escape(b.getBorrower().getName()) + "</b><br><span style='color:#6B7280'>"
                    + escape(b.getBook().getTitle()) + " - " + b.daysOverdue(now) + " day(s) late</span></html>");
            item.setFont(Theme.regular(12));
            item.setBackground(Theme.WHITE);
            item.setBorder(new EmptyBorder(6, 14, 6, 14));
            item.addActionListener(e -> nav.navigate(Modules.TRANSACTIONS, "status:Overdue"));
            menu.add(item);
        }
        if (!overdue.isEmpty()) {
            JMenuItem all = new JMenuItem("View all overdue transactions");
            all.setFont(Theme.bold(12));
            all.setForeground(Theme.INFO);
            all.setBackground(Theme.WHITE);
            all.setBorder(new EmptyBorder(10, 14, 10, 14));
            all.addActionListener(e -> nav.navigate(Modules.TRANSACTIONS, "status:Overdue"));
            menu.addSeparator();
            menu.add(all);
        }
        menu.show(anchor, anchor.getWidth() - 300, anchor.getHeight() + 6);
    }

    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;");
    }

    private class Bell extends JComponent {
        private static final long serialVersionUID = 1L;
        private int count;

        Bell() {
            setPreferredSize(new Dimension(40, 40));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setToolTipText("Notifications");
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    showOverduePopup(Bell.this);
                }
            });
        }

        void setCount(int count) {
            this.count = count;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(new Color(0xF3F4F6));
            g2.fillOval(0, 0, 40, 40);
            Icons.paint((Graphics2D) g2.create(10, 10, 20, 20), Icons.BELL, 20, Theme.NAVY);
            if (count > 0) {
                String text = count > 99 ? "99+" : String.valueOf(count);
                g2.setFont(Theme.bold(10));
                FontMetrics fm = g2.getFontMetrics();
                int w = Math.max(16, fm.stringWidth(text) + 8);
                g2.setColor(Theme.DANGER);
                g2.fillRoundRect(40 - w, 0, w, 16, 16, 16);
                g2.setColor(Theme.WHITE);
                g2.drawString(text, 40 - w + (w - fm.stringWidth(text)) / 2, 12);
            }
            g2.dispose();
        }
    }

    private class Profile extends JComponent {
        private static final long serialVersionUID = 1L;
        private final Administrator admin;

        Profile(Administrator admin) {
            this.admin = admin;
            setPreferredSize(new Dimension(215, 44));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    JPopupMenu menu = new JPopupMenu();
                    menu.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
                    JMenuItem settings = new JMenuItem("Account settings");
                    settings.setFont(Theme.regular(13));
                    settings.setBorder(new EmptyBorder(8, 14, 8, 24));
                    settings.addActionListener(a -> nav.navigate(Modules.SETTINGS));
                    JMenuItem logout = new JMenuItem("Logout");
                    logout.setFont(Theme.regular(13));
                    logout.setBorder(new EmptyBorder(8, 14, 8, 24));
                    logout.addActionListener(a -> nav.logout());
                    menu.add(settings);
                    menu.add(logout);
                    menu.show(Profile.this, 0, getHeight() + 4);
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int y = (getHeight() - 40) / 2;
            g2.setColor(Theme.GOLD);
            g2.fillOval(0, y, 40, 40);
            g2.setColor(Theme.NAVY);
            g2.setFont(Theme.bold(14));
            FontMetrics fm = g2.getFontMetrics();
            String initials = admin.getInitials();
            g2.drawString(initials, (40 - fm.stringWidth(initials)) / 2, y + (40 - fm.getHeight()) / 2 + fm.getAscent());
            g2.setFont(Theme.bold(13));
            g2.setColor(Theme.TEXT_STRONG);
            fm = g2.getFontMetrics();
            g2.drawString(fit(admin.getFullName(), fm, getWidth() - 52), 50, y + 17);
            g2.setFont(Theme.regular(11));
            g2.setColor(Theme.MUTED);
            fm = g2.getFontMetrics();
            g2.drawString(fit(admin.getRole(), fm, getWidth() - 52), 50, y + 33);
            g2.dispose();
        }

        private String fit(String text, FontMetrics fm, int width) {
            String cut = text;
            while (cut.length() > 3 && fm.stringWidth(cut) > width) {
                cut = cut.substring(0, cut.length() - 2);
            }
            return cut.equals(text) ? text : cut + "...";
        }
    }
}
