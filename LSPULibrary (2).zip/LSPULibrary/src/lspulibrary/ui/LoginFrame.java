package lspulibrary.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import lspulibrary.AppContext;
import lspulibrary.models.Administrator;
import lspulibrary.services.AuthService;
import lspulibrary.ui.components.ModernButton;
import lspulibrary.ui.components.StyledPasswordField;
import lspulibrary.ui.components.StyledTextField;
import lspulibrary.ui.dialogs.BaseDialog;

public class LoginFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private final AppContext ctx;
    private final Consumer<Administrator> onSuccess;
    private final StyledTextField username = new StyledTextField(20, "Username");
    private final StyledPasswordField password = new StyledPasswordField(20, "Password");
    private final JLabel error = UI.label(" ", Theme.bold(12), Theme.DANGER);

    public LoginFrame(AppContext ctx, Consumer<Administrator> onSuccess) {
        super("LSPU Library Borrowing Management System - Sign in");
        this.ctx = ctx;
        this.onSuccess = onSuccess;
        setIconImage(LogoPanel.windowIcon());
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel root = new JPanel(new GridLayout(1, 2));
        root.add(brandPanel());
        root.add(formPanel());
        setContentPane(root);
        setSize(Math.min(960, java.awt.Toolkit.getDefaultToolkit().getScreenSize().width - 40), 580);
        setMinimumSize(new Dimension(760, 520));
        setLocationRelativeTo(null);
    }

    public JPanel contentForPreview() {
        return (JPanel) getContentPane();
    }

    private JPanel brandPanel() {
        JPanel panel = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.NAVY);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 10));
                g2.fillOval(-120, getHeight() - 260, 380, 380);
                g2.setColor(Theme.alpha(Theme.GOLD, 30));
                g2.fillOval(getWidth() - 170, -90, 280, 280);
                g2.dispose();
            }
        };
        panel.setBorder(BorderFactory.createEmptyBorder(40, 44, 36, 40));
        panel.add(new LogoPanel(1.2f), BorderLayout.NORTH);

        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.add(Box(UI.label("Library Borrowing", Theme.bold(30), Theme.WHITE)));
        text.add(Box(UI.label("Management System", Theme.bold(30), Theme.GOLD)));
        text.add(javax.swing.Box.createVerticalStrut(16));
        text.add(Box(UI.label("<html><body style='width:320px'>Manage books, borrowers and borrowing transactions "
                + "from one clean workspace.</body></html>", Theme.regular(14), Theme.SIDEBAR_TEXT)));
        text.add(javax.swing.Box.createVerticalStrut(26));
        for (String line : new String[]{"Track every book and copy", "Enforce borrowing limits and due dates",
            "Calculate fines automatically", "Reports and analytics at a glance"}) {
            text.add(Box(UI.label("\u2022  " + line, Theme.regular(13), Theme.WHITE)));
            text.add(javax.swing.Box.createVerticalStrut(8));
        }
        JPanel centerWrap = new JPanel(new GridBagLayout());
        centerWrap.setOpaque(false);
        centerWrap.add(text);
        panel.add(centerWrap, BorderLayout.CENTER);
        panel.add(UI.label("Laguna State Polytechnic University", Theme.regular(12), Theme.SIDEBAR_TEXT), BorderLayout.SOUTH);
        return panel;
    }

    private static JComponent Box(JComponent c) {
        c.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        return c;
    }

    private JPanel formPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Theme.WHITE);

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.add(Box(UI.label("Welcome back", Theme.bold(26), Theme.NAVY)));
        form.add(javax.swing.Box.createVerticalStrut(4));
        form.add(Box(UI.label("Sign in with your administrator account", Theme.regular(13), Theme.MUTED)));
        form.add(javax.swing.Box.createVerticalStrut(26));
        JComponent userBox = BaseDialog.fieldBox("Username", username);
        JComponent passBox = BaseDialog.fieldBox("Password", password);
        form.add(Box(userBox));
        form.add(Box(passBox));
        form.add(Box(error));
        form.add(javax.swing.Box.createVerticalStrut(10));

        ModernButton signIn = new ModernButton("Sign In", ModernButton.Style.PRIMARY);
        signIn.setPreferredSize(new Dimension(320, 44));
        signIn.addActionListener(e -> attemptLogin());
        JPanel buttonRow = new JPanel(new BorderLayout());
        buttonRow.setOpaque(false);
        buttonRow.add(signIn);
        form.add(Box(buttonRow));
        form.add(javax.swing.Box.createVerticalStrut(18));
        form.add(Box(UI.label("<html><body style='width:320px'>Default account: <b>" + AuthService.DEFAULT_USERNAME
                + "</b> / <b>" + AuthService.DEFAULT_PASSWORD + "</b><br>You can change it later in Settings.</body></html>",
                Theme.regular(12), Theme.MUTED)));
        if (!ctx.isPersistent()) {
            form.add(javax.swing.Box.createVerticalStrut(12));
            form.add(Box(UI.label("<html><body style='width:320px'>Running with temporary data. Nothing will be saved "
                    + "when you close the application.</body></html>", Theme.bold(12), Theme.WARNING)));
        }
        form.setPreferredSize(new Dimension(340, form.getPreferredSize().height));
        panel.add(form, new GridBagConstraints(0, 0, 1, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(20, 20, 20, 20), 0, 0));
        getRootPane().setDefaultButton(signIn);
        return panel;
    }

    private void attemptLogin() {
        try {
            Administrator admin = ctx.auth().login(username.getText(), password.getPassword());
            password.setText("");
            dispose();
            onSuccess.accept(admin);
        } catch (IllegalArgumentException ex) {
            error.setText(ex.getMessage());
            password.setText("");
            password.requestFocusInWindow();
        }
    }
}
