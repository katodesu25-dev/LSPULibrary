package lspulibrary.models;

import lspulibrary.contracts.Borrowable;

public class Book implements Borrowable {
    private final int id;
    private String title;
    private String author;
    private String category;
    private int copiesTotal;
    private int copiesAvailable;

    public Book(int id, String title, String author, String category, int copiesTotal) {
        this(id, title, author, category, copiesTotal, copiesTotal);
    }

    public Book(int id, String title, String author, String category, int copiesTotal, int copiesAvailable) {
        if (copiesTotal < 1) {
            throw new IllegalArgumentException("A book must have at least 1 copy.");
        }
        if (copiesAvailable < 0 || copiesAvailable > copiesTotal) {
            throw new IllegalArgumentException("Available copies must be between 0 and the total copies.");
        }
        this.id = id;
        setTitle(title);
        setAuthor(author);
        setCategory(category);
        this.copiesTotal = copiesTotal;
        this.copiesAvailable = copiesAvailable;
    }

    public int getId() {
        return id;
    }

    @Override
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Title cannot be empty.");
        }
        this.title = title.trim();
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author == null ? "" : author.trim();
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category == null ? "" : category.trim();
    }

    public int getTotalCopies() {
        return copiesTotal;
    }

    public int getAvailableCopies() {
        return copiesAvailable;
    }

    public int getBorrowedCopies() {
        return copiesTotal - copiesAvailable;
    }

    @Override
    public boolean isAvailable() {
        return copiesAvailable > 0;
    }

    @Override
    public void checkOut() {
        if (!isAvailable()) {
            throw new IllegalStateException("No copies of \"" + title + "\" are available right now.");
        }
        copiesAvailable--;
    }

    @Override
    public void checkIn() {
        if (copiesAvailable >= copiesTotal) {
            throw new IllegalStateException("All copies of \"" + title + "\" are already on the shelf.");
        }
        copiesAvailable++;
    }

    public void resizeCopies(int newTotal) {
        if (newTotal < 1) {
            throw new IllegalArgumentException("A book must have at least 1 copy.");
        }
        int difference = newTotal - copiesTotal;
        if (copiesAvailable + difference < 0) {
            throw new IllegalStateException("Cannot set fewer copies than are currently borrowed ("
                    + getBorrowedCopies() + " on loan).");
        }
        copiesTotal = newTotal;
        copiesAvailable += difference;
    }
}
