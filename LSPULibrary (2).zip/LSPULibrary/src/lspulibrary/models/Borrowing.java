package lspulibrary.models;

import java.time.Duration;
import java.time.LocalDateTime;

public class Borrowing {
    private final int id;
    private final Book book;
    private final Borrower borrower;
    private final LocalDateTime borrowedAt;
    private final LocalDateTime dueAt;
    private LocalDateTime returnedAt;
    private double fine;

    public Borrowing(int id, Book book, Borrower borrower, LocalDateTime borrowedAt, LocalDateTime dueAt) {
        this(id, book, borrower, borrowedAt, dueAt, null, 0);
    }

    public Borrowing(int id, Book book, Borrower borrower, LocalDateTime borrowedAt, LocalDateTime dueAt,
                     LocalDateTime returnedAt, double fine) {
        this.id = id;
        this.book = book;
        this.borrower = borrower;
        this.borrowedAt = borrowedAt;
        this.dueAt = dueAt;
        this.returnedAt = returnedAt;
        this.fine = fine;
    }

    public int getId() {
        return id;
    }

    public Book getBook() {
        return book;
    }

    public Borrower getBorrower() {
        return borrower;
    }

    public LocalDateTime getBorrowedAt() {
        return borrowedAt;
    }

    public LocalDateTime getDueAt() {
        return dueAt;
    }

    public LocalDateTime getReturnedAt() {
        return returnedAt;
    }

    public double getFine() {
        return fine;
    }

    public boolean isReturned() {
        return returnedAt != null;
    }

    public int daysOverdue(LocalDateTime asOf) {
        LocalDateTime end = returnedAt != null ? returnedAt : asOf;
        long seconds = Duration.between(dueAt, end).getSeconds();
        return seconds <= 0 ? 0 : (int) Math.ceil(seconds / 86400.0);
    }

    public boolean isOverdue(LocalDateTime asOf) {
        return !isReturned() && daysOverdue(asOf) > 0;
    }

    public String statusAt(LocalDateTime asOf) {
        if (isReturned()) {
            return "Returned";
        }
        return isOverdue(asOf) ? "Overdue" : "Borrowed";
    }

    public void markReturned(LocalDateTime when, double fine) {
        this.returnedAt = when;
        this.fine = fine;
    }
}
