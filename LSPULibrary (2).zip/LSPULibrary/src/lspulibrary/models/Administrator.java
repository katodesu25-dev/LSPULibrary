package lspulibrary.models;

public class Administrator {
    private final int id;
    private final String username;
    private String fullName;
    private final String role;
    private String salt;
    private String passwordHash;

    public Administrator(int id, String username, String fullName, String role, String salt, String passwordHash) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty.");
        }
        this.id = id;
        this.username = username.trim();
        this.role = role;
        this.salt = salt;
        this.passwordHash = passwordHash;
        setFullName(fullName);
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new IllegalArgumentException("Full name cannot be empty.");
        }
        this.fullName = fullName.trim();
    }

    public String getRole() {
        return role;
    }

    public String getSalt() {
        return salt;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setCredentials(String salt, String passwordHash) {
        this.salt = salt;
        this.passwordHash = passwordHash;
    }

    public String getInitials() {
        String[] parts = fullName.split("\\s+");
        String first = parts[0].substring(0, 1);
        String last = parts.length > 1 ? parts[parts.length - 1].substring(0, 1) : "";
        return (first + last).toUpperCase();
    }
}
