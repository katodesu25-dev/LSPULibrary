package lspulibrary.models;

import lspulibrary.members.LibraryMember;
import lspulibrary.members.MemberFactory;

public class Borrower {
    private final int id;
    private String name;
    private String idNumber;
    private String email;
    private String type;
    private boolean active;

    public Borrower(int id, String name, String idNumber, String email, String type) {
        this(id, name, idNumber, email, type, true);
    }

    public Borrower(int id, String name, String idNumber, String email, String type, boolean active) {
        this.id = id;
        this.active = active;
        assign(name, idNumber, email, type);
    }

    private void assign(String name, String idNumber, String email, String type) {
        LibraryMember checked = MemberFactory.make(type, name, idNumber, email, 0);
        this.name = checked.getName();
        this.idNumber = checked.getIdNumber();
        this.email = checked.getEmail();
        this.type = type.trim().toLowerCase();
    }

    public void update(String name, String idNumber, String email, String type) {
        assign(name, idNumber, email, type);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getType() {
        return type;
    }

    public String getTypeLabel() {
        return asMember(0).getRole();
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public LibraryMember asMember(int activeLoans) {
        return MemberFactory.make(type, name, idNumber, email, activeLoans);
    }
}
