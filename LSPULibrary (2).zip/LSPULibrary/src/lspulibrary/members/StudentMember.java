package lspulibrary.members;

public class StudentMember extends LibraryMember {
    public StudentMember(String name, String idNumber, String email, int activeLoans) {
        super(name, idNumber, email, activeLoans);
    }

    @Override
    public String getRole() {
        return "Student";
    }

    @Override
    public int getBorrowLimit() {
        return 3;
    }

    @Override
    public int getLoanDays() {
        return 7;
    }

    @Override
    public double getFinePerDay() {
        return 5.00;
    }
}
