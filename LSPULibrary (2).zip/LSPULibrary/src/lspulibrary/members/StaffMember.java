package lspulibrary.members;

public class StaffMember extends LibraryMember {
    private static final double MAX_FINE = 100.00;

    public StaffMember(String name, String idNumber, String email, int activeLoans) {
        super(name, idNumber, email, activeLoans);
    }

    @Override
    public String getRole() {
        return "Staff";
    }

    @Override
    public int getBorrowLimit() {
        return 5;
    }

    @Override
    public int getLoanDays() {
        return 14;
    }

    @Override
    public double getFinePerDay() {
        return 3.00;
    }

    @Override
    public double computeFine(int daysOverdue) {
        return Math.min(super.computeFine(daysOverdue), MAX_FINE);
    }
}
