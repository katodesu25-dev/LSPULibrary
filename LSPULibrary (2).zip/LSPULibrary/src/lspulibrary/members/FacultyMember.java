package lspulibrary.members;

public class FacultyMember extends LibraryMember {
    public FacultyMember(String name, String idNumber, String email, int activeLoans) {
        super(name, idNumber, email, activeLoans);
    }

    @Override
    public String getRole() {
        return "Faculty";
    }

    @Override
    public int getBorrowLimit() {
        return 10;
    }

    @Override
    public int getLoanDays() {
        return 30;
    }

    @Override
    public double getFinePerDay() {
        return 2.00;
    }
}
