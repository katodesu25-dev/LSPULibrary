package lspulibrary.members;

import java.util.List;

public final class MemberFactory {
    private MemberFactory() {
    }

    public static LibraryMember make(String type, String name, String idNumber, String email, int activeLoans) {
        String key = type == null ? "" : type.trim().toLowerCase();
        switch (key) {
            case "student":
                return new StudentMember(name, idNumber, email, activeLoans);
            case "faculty":
                return new FacultyMember(name, idNumber, email, activeLoans);
            case "staff":
                return new StaffMember(name, idNumber, email, activeLoans);
            default:
                throw new IllegalArgumentException("Unknown borrower type: " + type);
        }
    }

    public static List<String> types() {
        return List.of("student", "faculty", "staff");
    }
}
