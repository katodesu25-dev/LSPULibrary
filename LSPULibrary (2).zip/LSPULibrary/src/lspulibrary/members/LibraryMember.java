package lspulibrary.members;

public abstract class LibraryMember extends Person {
    private String idNumber;
    private int activeLoans;

    public LibraryMember(String name, String idNumber, String email, int activeLoans) {
        super(name, email);
        setIdNumber(idNumber);
        setActiveLoans(activeLoans);
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        if (idNumber == null || idNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("ID number cannot be empty.");
        }
        this.idNumber = idNumber.trim();
    }

    public int getActiveLoans() {
        return activeLoans;
    }

    public void setActiveLoans(int activeLoans) {
        if (activeLoans < 0) {
            throw new IllegalArgumentException("Active loans cannot be negative.");
        }
        this.activeLoans = activeLoans;
    }

    public abstract int getBorrowLimit();

    public abstract int getLoanDays();

    public abstract double getFinePerDay();

    public boolean canBorrow() {
        return activeLoans < getBorrowLimit();
    }

    public double computeFine(int daysOverdue) {
        return Math.max(0, daysOverdue) * getFinePerDay();
    }

    public String describe() {
        return String.format("%s (%s) - up to %d books for %d days, fine P%.2f/day",
                getName(), getRole(), getBorrowLimit(), getLoanDays(), getFinePerDay());
    }
}
