package lspulibrary.contracts;

public interface Borrowable {
    String getTitle();
    boolean isAvailable();
    void checkOut();
    void checkIn();
}
