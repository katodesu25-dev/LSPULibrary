package lspulibrary.data;

import java.util.ArrayList;
import java.util.List;
import lspulibrary.models.Administrator;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;

public class InMemoryLibraryRepository implements LibraryRepository {
    private final List<Book> books = new ArrayList<>();
    private final List<Borrower> borrowers = new ArrayList<>();
    private final List<Borrowing> borrowings = new ArrayList<>();
    private final List<Administrator> administrators = new ArrayList<>();
    private int nextBookId = 1;
    private int nextBorrowerId = 1;
    private int nextBorrowingId = 1;
    private int nextAdminId = 1;

    @Override
    public List<Book> findBooks() {
        return new ArrayList<>(books);
    }

    @Override
    public Book findBook(int id) {
        for (Book b : books) {
            if (b.getId() == id) {
                return b;
            }
        }
        return null;
    }

    @Override
    public Book saveBook(Book book) {
        if (book.getId() == 0) {
            Book stored = new Book(nextBookId++, book.getTitle(), book.getAuthor(), book.getCategory(),
                    book.getTotalCopies(), book.getAvailableCopies());
            books.add(stored);
            return stored;
        }
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId() == book.getId()) {
                books.set(i, book);
                return book;
            }
        }
        throw new DataAccessException("Book #" + book.getId() + " does not exist.", null);
    }

    @Override
    public void deleteBook(int id) {
        books.removeIf(b -> b.getId() == id);
    }

    @Override
    public List<Borrower> findBorrowers() {
        return new ArrayList<>(borrowers);
    }

    @Override
    public Borrower findBorrower(int id) {
        for (Borrower b : borrowers) {
            if (b.getId() == id) {
                return b;
            }
        }
        return null;
    }

    @Override
    public Borrower saveBorrower(Borrower borrower) {
        if (borrower.getId() == 0) {
            Borrower stored = new Borrower(nextBorrowerId++, borrower.getName(), borrower.getIdNumber(),
                    borrower.getEmail(), borrower.getType(), borrower.isActive());
            borrowers.add(stored);
            return stored;
        }
        for (int i = 0; i < borrowers.size(); i++) {
            if (borrowers.get(i).getId() == borrower.getId()) {
                borrowers.set(i, borrower);
                return borrower;
            }
        }
        throw new DataAccessException("Borrower #" + borrower.getId() + " does not exist.", null);
    }

    @Override
    public void deleteBorrower(int id) {
        borrowers.removeIf(b -> b.getId() == id);
    }

    @Override
    public List<Borrowing> findBorrowings() {
        return new ArrayList<>(borrowings);
    }

    @Override
    public Borrowing findBorrowing(int id) {
        for (Borrowing b : borrowings) {
            if (b.getId() == id) {
                return b;
            }
        }
        return null;
    }

    @Override
    public Borrowing saveBorrowing(Borrowing borrowing) {
        if (borrowing.getId() == 0) {
            Borrowing stored = new Borrowing(nextBorrowingId++, borrowing.getBook(), borrowing.getBorrower(),
                    borrowing.getBorrowedAt(), borrowing.getDueAt(), borrowing.getReturnedAt(), borrowing.getFine());
            borrowings.add(stored);
            return stored;
        }
        for (int i = 0; i < borrowings.size(); i++) {
            if (borrowings.get(i).getId() == borrowing.getId()) {
                borrowings.set(i, borrowing);
                return borrowing;
            }
        }
        throw new DataAccessException("Transaction #" + borrowing.getId() + " does not exist.", null);
    }

    @Override
    public Administrator findAdministrator(String username) {
        for (Administrator a : administrators) {
            if (a.getUsername().equalsIgnoreCase(username)) {
                return a;
            }
        }
        return null;
    }

    @Override
    public Administrator saveAdministrator(Administrator administrator) {
        if (administrator.getId() == 0) {
            Administrator stored = new Administrator(nextAdminId++, administrator.getUsername(),
                    administrator.getFullName(), administrator.getRole(), administrator.getSalt(),
                    administrator.getPasswordHash());
            administrators.add(stored);
            return stored;
        }
        return administrator;
    }

    @Override
    public boolean hasAdministrators() {
        return !administrators.isEmpty();
    }

    @Override
    public void clearLibraryData() {
        books.clear();
        borrowers.clear();
        borrowings.clear();
        nextBookId = 1;
        nextBorrowerId = 1;
        nextBorrowingId = 1;
    }

    @Override
    public void inTransaction(Runnable work) {
        work.run();
    }

    @Override
    public boolean isPersistent() {
        return false;
    }

    @Override
    public String describe() {
        return "Temporary in-memory storage (data is lost when the program closes)";
    }

    @Override
    public void close() {
    }
}
