package lspulibrary.data;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;

public final class RepositoryFactory {
    public static final Path DATABASE_FILE = Paths.get("data", "lspu_library.db");

    private RepositoryFactory() {
    }

    public static LibraryRepository openSqlite() throws SQLException {
        return new SqliteLibraryRepository(DATABASE_FILE);
    }

    public static LibraryRepository openInMemory() {
        return new InMemoryLibraryRepository();
    }
}
