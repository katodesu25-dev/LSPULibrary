package lspulibrary.data;

import java.util.List;
import lspulibrary.models.Administrator;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;

public interface LibraryRepository {
    List<Book> findBooks();

    Book findBook(int id);

    Book saveBook(Book book);

    void deleteBook(int id);

    List<Borrower> findBorrowers();

    Borrower findBorrower(int id);

    Borrower saveBorrower(Borrower borrower);

    void deleteBorrower(int id);

    List<Borrowing> findBorrowings();

    Borrowing findBorrowing(int id);

    Borrowing saveBorrowing(Borrowing borrowing);

    Administrator findAdministrator(String username);

    Administrator saveAdministrator(Administrator administrator);

    boolean hasAdministrators();

    void clearLibraryData();

    void inTransaction(Runnable work);

    boolean isPersistent();

    String describe();

    void close();
}
