package lspulibrary.data;

public final class Sql {
    private Sql() {
    }

    public static final String[] SCHEMA = {
        "CREATE TABLE IF NOT EXISTS books ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "title TEXT NOT NULL, "
            + "author TEXT NOT NULL DEFAULT '', "
            + "category TEXT NOT NULL DEFAULT '', "
            + "copies_total INTEGER NOT NULL CHECK (copies_total >= 1), "
            + "copies_available INTEGER NOT NULL CHECK (copies_available >= 0 AND copies_available <= copies_total), "
            + "deleted INTEGER NOT NULL DEFAULT 0)",
        "CREATE TABLE IF NOT EXISTS borrowers ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "name TEXT NOT NULL, "
            + "id_number TEXT NOT NULL, "
            + "email TEXT NOT NULL DEFAULT '', "
            + "type TEXT NOT NULL CHECK (type IN ('student','faculty','staff')), "
            + "active INTEGER NOT NULL DEFAULT 1, "
            + "deleted INTEGER NOT NULL DEFAULT 0)",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_borrowers_id_number ON borrowers (id_number COLLATE NOCASE) WHERE deleted = 0",
        "CREATE TABLE IF NOT EXISTS borrowings ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "book_id INTEGER NOT NULL REFERENCES books (id), "
            + "borrower_id INTEGER NOT NULL REFERENCES borrowers (id), "
            + "borrowed_at TEXT NOT NULL, "
            + "due_at TEXT NOT NULL, "
            + "returned_at TEXT, "
            + "fine REAL NOT NULL DEFAULT 0)",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_borrowings_active_loan ON borrowings (book_id, borrower_id) WHERE returned_at IS NULL",
        "CREATE INDEX IF NOT EXISTS ix_borrowings_borrower ON borrowings (borrower_id)",
        "CREATE TABLE IF NOT EXISTS administrators ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "username TEXT NOT NULL UNIQUE, "
            + "full_name TEXT NOT NULL, "
            + "role TEXT NOT NULL, "
            + "salt TEXT NOT NULL, "
            + "password_hash TEXT NOT NULL)"
    };

    public static final String BOOK_COLUMNS = "id, title, author, category, copies_total, copies_available";
    public static final String BOOKS_ACTIVE = "SELECT " + BOOK_COLUMNS + " FROM books WHERE deleted = 0 ORDER BY title COLLATE NOCASE";
    public static final String BOOKS_ALL = "SELECT " + BOOK_COLUMNS + " FROM books";
    public static final String BOOK_BY_ID = "SELECT " + BOOK_COLUMNS + " FROM books WHERE id = ? AND deleted = 0";
    public static final String BOOK_INSERT = "INSERT INTO books (title, author, category, copies_total, copies_available) VALUES (?, ?, ?, ?, ?)";
    public static final String BOOK_UPDATE = "UPDATE books SET title = ?, author = ?, category = ?, copies_total = ?, copies_available = ? WHERE id = ?";
    public static final String BOOK_DELETE = "UPDATE books SET deleted = 1 WHERE id = ?";

    public static final String BORROWER_COLUMNS = "id, name, id_number, email, type, active";
    public static final String BORROWERS_ACTIVE = "SELECT " + BORROWER_COLUMNS + " FROM borrowers WHERE deleted = 0 ORDER BY name COLLATE NOCASE";
    public static final String BORROWERS_ALL = "SELECT " + BORROWER_COLUMNS + " FROM borrowers";
    public static final String BORROWER_BY_ID = "SELECT " + BORROWER_COLUMNS + " FROM borrowers WHERE id = ? AND deleted = 0";
    public static final String BORROWER_INSERT = "INSERT INTO borrowers (name, id_number, email, type, active) VALUES (?, ?, ?, ?, ?)";
    public static final String BORROWER_UPDATE = "UPDATE borrowers SET name = ?, id_number = ?, email = ?, type = ?, active = ? WHERE id = ?";
    public static final String BORROWER_DELETE = "UPDATE borrowers SET deleted = 1 WHERE id = ?";

    public static final String BORROWING_COLUMNS = "id, book_id, borrower_id, borrowed_at, due_at, returned_at, fine";
    public static final String BORROWINGS_ALL = "SELECT " + BORROWING_COLUMNS + " FROM borrowings ORDER BY id";
    public static final String BORROWING_BY_ID = "SELECT " + BORROWING_COLUMNS + " FROM borrowings WHERE id = ?";
    public static final String BORROWING_INSERT = "INSERT INTO borrowings (book_id, borrower_id, borrowed_at, due_at, returned_at, fine) VALUES (?, ?, ?, ?, ?, ?)";
    public static final String BORROWING_UPDATE = "UPDATE borrowings SET returned_at = ?, fine = ? WHERE id = ?";

    public static final String ADMIN_COLUMNS = "id, username, full_name, role, salt, password_hash";
    public static final String ADMIN_BY_USERNAME = "SELECT " + ADMIN_COLUMNS + " FROM administrators WHERE username = ? COLLATE NOCASE";
    public static final String ADMIN_COUNT = "SELECT COUNT(*) FROM administrators";
    public static final String ADMIN_INSERT = "INSERT INTO administrators (username, full_name, role, salt, password_hash) VALUES (?, ?, ?, ?, ?)";
    public static final String ADMIN_UPDATE = "UPDATE administrators SET full_name = ?, salt = ?, password_hash = ? WHERE id = ?";

    public static final String LAST_ID = "SELECT last_insert_rowid()";

    public static final String[] CLEAR = {
        "DELETE FROM borrowings",
        "DELETE FROM books",
        "DELETE FROM borrowers",
        "DELETE FROM sqlite_sequence WHERE name IN ('borrowings', 'books', 'borrowers')"
    };
}
