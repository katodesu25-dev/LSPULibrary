package lspulibrary.data;

import java.time.LocalDateTime;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;

public final class SampleData {
    private SampleData() {
    }

    private static final String[][] BOOKS = {
        {"Noli Me Tangere", "Jose Rizal", "Literature", "4"},
        {"El Filibusterismo", "Jose Rizal", "Literature", "3"},
        {"Introduction to Algorithms", "Cormen, Leiserson, Rivest, Stein", "Computer Science", "2"},
        {"Java: The Complete Reference", "Herbert Schildt", "Programming", "5"},
        {"Clean Code", "Robert C. Martin", "Programming", "3"},
        {"Database System Concepts", "Silberschatz, Korth, Sudarshan", "Computer Science", "3"},
        {"The Philippines: A Past Revisited", "Renato Constantino", "History", "2"},
        {"Calculus: Early Transcendentals", "James Stewart", "Mathematics", "4"},
        {"Principles of Economics", "N. Gregory Mankiw", "Economics", "3"},
        {"Campbell Biology", "Urry, Cain, Wasserman", "Science", "2"},
        {"The Pragmatic Programmer", "Hunt and Thomas", "Programming", "2"},
        {"Software Engineering", "Ian Sommerville", "Computer Science", "3"},
        {"Florante at Laura", "Francisco Balagtas", "Literature", "3"},
        {"Physics for Scientists and Engineers", "Serway and Jewett", "Science", "2"}
    };

    private static final String[][] BORROWERS = {
        {"Ana Reyes", "2024-0001", "ana.reyes@lspu.edu.ph", "student"},
        {"Mark Dela Cruz", "2024-0002", "mark.delacruz@lspu.edu.ph", "student"},
        {"Bea Santos", "2023-0145", "bea.santos@lspu.edu.ph", "student"},
        {"Carlo Mendoza", "2023-0210", "carlo.mendoza@lspu.edu.ph", "student"},
        {"Dr. Elena Garcia", "FAC-1001", "elena.garcia@lspu.edu.ph", "faculty"},
        {"Prof. Ramon Bautista", "FAC-1002", "ramon.bautista@lspu.edu.ph", "faculty"},
        {"Liza Navarro", "STF-2001", "liza.navarro@lspu.edu.ph", "staff"},
        {"Jun Villanueva", "STF-2002", "jun.villanueva@lspu.edu.ph", "staff"}
    };

    private static final int[][] RETURNED = {
        {0, 0, 100, 5}, {3, 0, 98, 6}, {0, 1, 90, 12}, {2, 2, 75, 6}, {3, 3, 70, 10}, {4, 1, 60, 7},
        {5, 4, 55, 20}, {7, 5, 50, 35}, {3, 6, 45, 14}, {3, 7, 40, 20}, {0, 2, 35, 6}, {8, 0, 30, 9},
        {1, 3, 28, 5}, {10, 1, 25, 7}, {11, 4, 22, 15}, {3, 2, 18, 4}, {12, 6, 15, 10}, {4, 5, 12, 9},
        {6, 7, 10, 3}, {13, 2, 9, 5}, {0, 0, 6, 3}, {3, 1, 5, 4}, {11, 6, 4, 2}, {8, 3, 3, 1}
    };

    private static final int[][] ACTIVE = {
        {0, 3, 3}, {1, 0, 2}, {3, 1, 1}, {9, 4, 5}, {5, 6, 4}, {4, 7, 0},
        {2, 0, 15}, {3, 2, 12}, {7, 6, 25}, {5, 5, 38}
    };

    public static void load(LibraryRepository repo) {
        repo.inTransaction(() -> {
            LocalDateTime now = LocalDateTime.now();
            Book[] books = new Book[BOOKS.length];
            for (int i = 0; i < BOOKS.length; i++) {
                String[] b = BOOKS[i];
                books[i] = repo.saveBook(new Book(0, b[0], b[1], b[2], Integer.parseInt(b[3])));
            }
            Borrower[] borrowers = new Borrower[BORROWERS.length];
            for (int i = 0; i < BORROWERS.length; i++) {
                String[] b = BORROWERS[i];
                borrowers[i] = repo.saveBorrower(new Borrower(0, b[0], b[1], b[2], b[3]));
            }

            for (int i = 0; i < RETURNED.length; i++) {
                int[] r = RETURNED[i];
                Borrower borrower = borrowers[r[1]];
                LocalDateTime borrowedAt = now.minusDays(r[2]).minusHours(1 + i % 6);
                LocalDateTime dueAt = borrowedAt.plusDays(borrower.asMember(0).getLoanDays());
                LocalDateTime returnedAt = borrowedAt.plusDays(r[3]);
                Borrowing probe = new Borrowing(0, books[r[0]], borrower, borrowedAt, dueAt);
                double fine = borrower.asMember(0).computeFine(probe.daysOverdue(returnedAt));
                repo.saveBorrowing(new Borrowing(0, books[r[0]], borrower, borrowedAt, dueAt, returnedAt, fine));
            }

            for (int i = 0; i < ACTIVE.length; i++) {
                int[] a = ACTIVE[i];
                Borrower borrower = borrowers[a[1]];
                Book book = books[a[0]];
                book.checkOut();
                repo.saveBook(book);
                LocalDateTime borrowedAt = a[2] == 0 ? now.minusHours(2) : now.minusDays(a[2]).minusHours(1 + i % 5);
                LocalDateTime dueAt = borrowedAt.plusDays(borrower.asMember(0).getLoanDays());
                repo.saveBorrowing(new Borrowing(0, book, borrower, borrowedAt, dueAt));
            }
        });
    }
}
