package lspulibrary.data;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.Properties;

public final class SqliteConnector {
    private static final String DRIVER_CLASS = "org.sqlite.JDBC";

    private SqliteConnector() {
    }

    public static Connection open(Path databaseFile) throws SQLException {
        Driver driver = locateDriver();
        Connection connection = driver.connect("jdbc:sqlite:" + databaseFile.toAbsolutePath(), new Properties());
        if (connection == null) {
            throw new SQLException("The SQLite driver did not accept the database location.");
        }
        return connection;
    }

    private static Driver locateDriver() throws SQLException {
        try {
            return (Driver) Class.forName(DRIVER_CLASS).getDeclaredConstructor().newInstance();
        } catch (ReflectiveOperationException | LinkageError ignored) {
        }

        File[] jars = new File("lib").listFiles((dir, name) -> name.toLowerCase().endsWith(".jar"));
        if (jars == null || jars.length == 0) {
            throw new SQLException("SQLite JDBC driver not found. Put sqlite-jdbc-x.x.x.x.jar (and slf4j-api-1.7.36.jar) "
                    + "in the project's lib folder, or add them to the Eclipse build path.");
        }
        try {
            URL[] urls = new URL[jars.length];
            for (int i = 0; i < jars.length; i++) {
                urls[i] = jars[i].toURI().toURL();
            }
            URLClassLoader loader = new URLClassLoader(urls, SqliteConnector.class.getClassLoader());
            return (Driver) Class.forName(DRIVER_CLASS, true, loader).getDeclaredConstructor().newInstance();
        } catch (Exception | LinkageError e) {
            throw new SQLException("The jar files in the lib folder do not contain a usable SQLite driver: "
                    + e.getMessage(), e);
        }
    }
}
