package lspulibrary.data;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lspulibrary.models.Administrator;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;

public class SqliteLibraryRepository implements LibraryRepository {
    private final Connection connection;
    private final Path file;
    private int transactionDepth;

    public SqliteLibraryRepository(Path file) throws SQLException {
        this.file = file.toAbsolutePath();
        try {
            Path parent = this.file.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
        } catch (IOException e) {
            throw new SQLException("Cannot create the database folder: " + e.getMessage(), e);
        }
        this.connection = SqliteConnector.open(this.file);
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
            for (String ddl : Sql.SCHEMA) {
                st.execute(ddl);
            }
        }
    }

    private DataAccessException fail(String action, SQLException e) {
        return new DataAccessException("Database error while " + action + ": " + e.getMessage(), e);
    }

    private Book readBook(ResultSet rs) throws SQLException {
        return new Book(rs.getInt("id"), rs.getString("title"), rs.getString("author"), rs.getString("category"),
                rs.getInt("copies_total"), rs.getInt("copies_available"));
    }

    private Borrower readBorrower(ResultSet rs) throws SQLException {
        return new Borrower(rs.getInt("id"), rs.getString("name"), rs.getString("id_number"), rs.getString("email"),
                rs.getString("type"), rs.getInt("active") == 1);
    }

    private int lastId() throws SQLException {
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(Sql.LAST_ID)) {
            rs.next();
            return rs.getInt(1);
        }
    }

    private Map<Integer, Book> booksById(String sql) throws SQLException {
        Map<Integer, Book> map = new HashMap<>();
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Book b = readBook(rs);
                map.put(b.getId(), b);
            }
        }
        return map;
    }

    private Map<Integer, Borrower> borrowersById(String sql) throws SQLException {
        Map<Integer, Borrower> map = new HashMap<>();
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Borrower b = readBorrower(rs);
                map.put(b.getId(), b);
            }
        }
        return map;
    }

    @Override
    public List<Book> findBooks() {
        List<Book> list = new ArrayList<>();
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(Sql.BOOKS_ACTIVE)) {
            while (rs.next()) {
                list.add(readBook(rs));
            }
        } catch (SQLException e) {
            throw fail("loading books", e);
        }
        return list;
    }

    @Override
    public Book findBook(int id) {
        try (PreparedStatement ps = connection.prepareStatement(Sql.BOOK_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? readBook(rs) : null;
            }
        } catch (SQLException e) {
            throw fail("loading a book", e);
        }
    }

    @Override
    public Book saveBook(Book book) {
        try {
            if (book.getId() == 0) {
                try (PreparedStatement ps = connection.prepareStatement(Sql.BOOK_INSERT)) {
                    ps.setString(1, book.getTitle());
                    ps.setString(2, book.getAuthor());
                    ps.setString(3, book.getCategory());
                    ps.setInt(4, book.getTotalCopies());
                    ps.setInt(5, book.getAvailableCopies());
                    ps.executeUpdate();
                }
                return new Book(lastId(), book.getTitle(), book.getAuthor(), book.getCategory(),
                        book.getTotalCopies(), book.getAvailableCopies());
            }
            try (PreparedStatement ps = connection.prepareStatement(Sql.BOOK_UPDATE)) {
                ps.setString(1, book.getTitle());
                ps.setString(2, book.getAuthor());
                ps.setString(3, book.getCategory());
                ps.setInt(4, book.getTotalCopies());
                ps.setInt(5, book.getAvailableCopies());
                ps.setInt(6, book.getId());
                ps.executeUpdate();
            }
            return book;
        } catch (SQLException e) {
            throw fail("saving a book", e);
        }
    }

    @Override
    public void deleteBook(int id) {
        try (PreparedStatement ps = connection.prepareStatement(Sql.BOOK_DELETE)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw fail("deleting a book", e);
        }
    }

    @Override
    public List<Borrower> findBorrowers() {
        List<Borrower> list = new ArrayList<>();
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(Sql.BORROWERS_ACTIVE)) {
            while (rs.next()) {
                list.add(readBorrower(rs));
            }
        } catch (SQLException e) {
            throw fail("loading borrowers", e);
        }
        return list;
    }

    @Override
    public Borrower findBorrower(int id) {
        try (PreparedStatement ps = connection.prepareStatement(Sql.BORROWER_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? readBorrower(rs) : null;
            }
        } catch (SQLException e) {
            throw fail("loading a borrower", e);
        }
    }

    @Override
    public Borrower saveBorrower(Borrower borrower) {
        try {
            if (borrower.getId() == 0) {
                try (PreparedStatement ps = connection.prepareStatement(Sql.BORROWER_INSERT)) {
                    ps.setString(1, borrower.getName());
                    ps.setString(2, borrower.getIdNumber());
                    ps.setString(3, borrower.getEmail());
                    ps.setString(4, borrower.getType());
                    ps.setInt(5, borrower.isActive() ? 1 : 0);
                    ps.executeUpdate();
                }
                return new Borrower(lastId(), borrower.getName(), borrower.getIdNumber(), borrower.getEmail(),
                        borrower.getType(), borrower.isActive());
            }
            try (PreparedStatement ps = connection.prepareStatement(Sql.BORROWER_UPDATE)) {
                ps.setString(1, borrower.getName());
                ps.setString(2, borrower.getIdNumber());
                ps.setString(3, borrower.getEmail());
                ps.setString(4, borrower.getType());
                ps.setInt(5, borrower.isActive() ? 1 : 0);
                ps.setInt(6, borrower.getId());
                ps.executeUpdate();
            }
            return borrower;
        } catch (SQLException e) {
            throw fail("saving a borrower", e);
        }
    }

    @Override
    public void deleteBorrower(int id) {
        try (PreparedStatement ps = connection.prepareStatement(Sql.BORROWER_DELETE)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw fail("deleting a borrower", e);
        }
    }

    private Borrowing readBorrowing(ResultSet rs, Map<Integer, Book> books, Map<Integer, Borrower> borrowers)
            throws SQLException {
        String returned = rs.getString("returned_at");
        return new Borrowing(rs.getInt("id"), books.get(rs.getInt("book_id")), borrowers.get(rs.getInt("borrower_id")),
                LocalDateTime.parse(rs.getString("borrowed_at")), LocalDateTime.parse(rs.getString("due_at")),
                returned == null ? null : LocalDateTime.parse(returned), rs.getDouble("fine"));
    }

    @Override
    public List<Borrowing> findBorrowings() {
        List<Borrowing> list = new ArrayList<>();
        try {
            Map<Integer, Book> books = booksById(Sql.BOOKS_ALL);
            Map<Integer, Borrower> borrowers = borrowersById(Sql.BORROWERS_ALL);
            try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(Sql.BORROWINGS_ALL)) {
                while (rs.next()) {
                    list.add(readBorrowing(rs, books, borrowers));
                }
            }
        } catch (SQLException e) {
            throw fail("loading transactions", e);
        }
        return list;
    }

    @Override
    public Borrowing findBorrowing(int id) {
        try {
            Map<Integer, Book> books = booksById(Sql.BOOKS_ALL);
            Map<Integer, Borrower> borrowers = borrowersById(Sql.BORROWERS_ALL);
            try (PreparedStatement ps = connection.prepareStatement(Sql.BORROWING_BY_ID)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? readBorrowing(rs, books, borrowers) : null;
                }
            }
        } catch (SQLException e) {
            throw fail("loading a transaction", e);
        }
    }

    @Override
    public Borrowing saveBorrowing(Borrowing borrowing) {
        try {
            if (borrowing.getId() == 0) {
                try (PreparedStatement ps = connection.prepareStatement(Sql.BORROWING_INSERT)) {
                    ps.setInt(1, borrowing.getBook().getId());
                    ps.setInt(2, borrowing.getBorrower().getId());
                    ps.setString(3, borrowing.getBorrowedAt().toString());
                    ps.setString(4, borrowing.getDueAt().toString());
                    if (borrowing.getReturnedAt() == null) {
                        ps.setNull(5, Types.VARCHAR);
                    } else {
                        ps.setString(5, borrowing.getReturnedAt().toString());
                    }
                    ps.setDouble(6, borrowing.getFine());
                    ps.executeUpdate();
                }
                return new Borrowing(lastId(), borrowing.getBook(), borrowing.getBorrower(), borrowing.getBorrowedAt(),
                        borrowing.getDueAt(), borrowing.getReturnedAt(), borrowing.getFine());
            }
            try (PreparedStatement ps = connection.prepareStatement(Sql.BORROWING_UPDATE)) {
                if (borrowing.getReturnedAt() == null) {
                    ps.setNull(1, Types.VARCHAR);
                } else {
                    ps.setString(1, borrowing.getReturnedAt().toString());
                }
                ps.setDouble(2, borrowing.getFine());
                ps.setInt(3, borrowing.getId());
                ps.executeUpdate();
            }
            return borrowing;
        } catch (SQLException e) {
            throw fail("saving a transaction", e);
        }
    }

    private Administrator readAdministrator(ResultSet rs) throws SQLException {
        return new Administrator(rs.getInt("id"), rs.getString("username"), rs.getString("full_name"),
                rs.getString("role"), rs.getString("salt"), rs.getString("password_hash"));
    }

    @Override
    public Administrator findAdministrator(String username) {
        try (PreparedStatement ps = connection.prepareStatement(Sql.ADMIN_BY_USERNAME)) {
            ps.setString(1, username == null ? "" : username.trim());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? readAdministrator(rs) : null;
            }
        } catch (SQLException e) {
            throw fail("loading an administrator", e);
        }
    }

    @Override
    public Administrator saveAdministrator(Administrator admin) {
        try {
            if (admin.getId() == 0) {
                try (PreparedStatement ps = connection.prepareStatement(Sql.ADMIN_INSERT)) {
                    ps.setString(1, admin.getUsername());
                    ps.setString(2, admin.getFullName());
                    ps.setString(3, admin.getRole());
                    ps.setString(4, admin.getSalt());
                    ps.setString(5, admin.getPasswordHash());
                    ps.executeUpdate();
                }
                return new Administrator(lastId(), admin.getUsername(), admin.getFullName(), admin.getRole(),
                        admin.getSalt(), admin.getPasswordHash());
            }
            try (PreparedStatement ps = connection.prepareStatement(Sql.ADMIN_UPDATE)) {
                ps.setString(1, admin.getFullName());
                ps.setString(2, admin.getSalt());
                ps.setString(3, admin.getPasswordHash());
                ps.setInt(4, admin.getId());
                ps.executeUpdate();
            }
            return admin;
        } catch (SQLException e) {
            throw fail("saving an administrator", e);
        }
    }

    @Override
    public boolean hasAdministrators() {
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(Sql.ADMIN_COUNT)) {
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            throw fail("checking administrators", e);
        }
    }

    @Override
    public void clearLibraryData() {
        inTransaction(() -> {
            try (Statement st = connection.createStatement()) {
                for (String sql : Sql.CLEAR) {
                    st.executeUpdate(sql);
                }
            } catch (SQLException e) {
                throw fail("clearing data", e);
            }
        });
    }

    @Override
    public void inTransaction(Runnable work) {
        if (transactionDepth > 0) {
            work.run();
            return;
        }
        try {
            connection.setAutoCommit(false);
            transactionDepth++;
            try {
                work.run();
                connection.commit();
            } catch (RuntimeException e) {
                connection.rollback();
                throw e;
            } finally {
                transactionDepth--;
                connection.setAutoCommit(true);
            }
        } catch (SQLException e) {
            throw fail("running a transaction", e);
        }
    }

    @Override
    public boolean isPersistent() {
        return true;
    }

    @Override
    public String describe() {
        return file.toString();
    }

    @Override
    public void close() {
        try {
            connection.close();
        } catch (SQLException ignored) {
        }
    }
}
