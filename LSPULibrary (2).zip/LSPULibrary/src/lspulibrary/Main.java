package lspulibrary;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import lspulibrary.data.DataAccessException;
import lspulibrary.data.LibraryRepository;
import lspulibrary.data.RepositoryFactory;
import lspulibrary.models.Administrator;
import lspulibrary.ui.LoginFrame;
import lspulibrary.ui.MainFrame;
import lspulibrary.ui.Theme;

public final class Main {
    private Main() {
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::start);
    }

    private static void start() {
        installLookAndFeel();
        AppContext ctx = openContext();
        if (ctx == null) {
            System.exit(0);
            return;
        }
        Runtime.getRuntime().addShutdownHook(new Thread(ctx::close));
        showLogin(ctx);
    }

    private static void installLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {
        }
        UIManager.put("ToolTip.font", Theme.regular(12));
        UIManager.put("PopupMenu.background", Theme.WHITE);
        UIManager.put("MenuItem.background", Theme.WHITE);
        UIManager.put("MenuItem.selectionBackground", Theme.ROW_SELECTED);
        UIManager.put("MenuItem.selectionForeground", Theme.TEXT_STRONG);
        UIManager.put("ComboBox.selectionBackground", Theme.ROW_SELECTED);
        UIManager.put("ComboBox.selectionForeground", Theme.TEXT_STRONG);
        UIManager.put("List.selectionBackground", Theme.ROW_SELECTED);
        UIManager.put("List.selectionForeground", Theme.TEXT_STRONG);
        UIManager.put("Button.focus", Theme.alpha(Theme.GOLD, 0));
        UIManager.put("Spinner.arrowButtonBorder", javax.swing.BorderFactory.createEmptyBorder());
    }

    private static AppContext openContext() {
        LibraryRepository repository;
        try {
            repository = RepositoryFactory.openSqlite();
        } catch (SQLException | DataAccessException e) {
            Object[] options = {"Continue with temporary data", "Exit"};
            int choice = JOptionPane.showOptionDialog(null,
                    "The SQLite database could not be opened:\n\n" + e.getMessage()
                    + "\n\nTo store data permanently, place sqlite-jdbc-x.x.x.x.jar and slf4j-api-1.7.36.jar\n"
                    + "inside the project's \"lib\" folder, then run the program again.\n\n"
                    + "You can continue now with temporary data that is lost when the program closes.",
                    "Database unavailable", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options,
                    options[0]);
            if (choice != 0) {
                return null;
            }
            repository = RepositoryFactory.openInMemory();
        }
        try {
            return AppContext.create(repository);
        } catch (DataAccessException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Startup failed", JOptionPane.ERROR_MESSAGE);
            repository.close();
            return null;
        }
    }

    private static void showLogin(AppContext ctx) {
        LoginFrame login = new LoginFrame(ctx, admin -> showMain(ctx, admin));
        login.setVisible(true);
    }

    private static void showMain(AppContext ctx, Administrator admin) {
        MainFrame frame = new MainFrame(ctx, admin, () -> showLogin(ctx));
        frame.setVisible(true);
    }
}
