package lspulibrary;

import lspulibrary.data.InMemoryLibraryRepository;
import lspulibrary.members.LibraryMember;
import lspulibrary.members.MemberFactory;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;
import lspulibrary.services.CirculationService;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ConsoleApp {
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final CirculationService service = new CirculationService(new InMemoryLibraryRepository());
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        seed();
        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            try {
                switch (choice) {
                    case "1":
                        addBook();
                        break;
                    case "2":
                        listBooks();
                        break;
                    case "3":
                        registerBorrower();
                        break;
                    case "4":
                        listBorrowers();
                        break;
                    case "5":
                        borrowBook();
                        break;
                    case "6":
                        returnBook();
                        break;
                    case "7":
                        listBorrowings();
                        break;
                    case "8":
                        polymorphismDemo();
                        break;
                    case "0":
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (RuntimeException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        System.out.println("Goodbye.");
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("===== LSPU LIBRARY BORROWING MANAGEMENT SYSTEM =====");
        System.out.println("1. Add book");
        System.out.println("2. List books");
        System.out.println("3. Register borrower");
        System.out.println("4. List borrowers");
        System.out.println("5. Borrow a book");
        System.out.println("6. Return a book");
        System.out.println("7. List transactions");
        System.out.println("8. Polymorphism demo (borrowing rules per member type)");
        System.out.println("0. Exit");
        System.out.print("Choice: ");
    }

    private static void seed() {
        service.addBook("Noli Me Tangere", "Jose Rizal", "Literature", 2);
        service.addBook("Introduction to Algorithms", "Cormen et al.", "Computer Science", 1);
        service.addBook("Java: The Complete Reference", "Herbert Schildt", "Programming", 3);
        service.registerBorrower("Ana Reyes", "2024-0001", "ana@lspu.edu.ph", "student");
        service.registerBorrower("Ben Cruz", "FAC-1001", "ben@lspu.edu.ph", "faculty");
        service.registerBorrower("Cy Santos", "STF-2001", "cy@lspu.edu.ph", "staff");
    }

    private static String ask(String label) {
        System.out.print(label + ": ");
        return scanner.nextLine();
    }

    private static int askInt(String label) {
        String text = ask(label).trim();
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("\"" + text + "\" is not a valid number.");
        }
    }

    private static void addBook() {
        String title = ask("Title");
        String author = ask("Author");
        String category = ask("Category");
        int copies = askInt("Number of copies");
        Book book = service.addBook(title, author, category, copies);
        System.out.println("Book #" + book.getId() + " added.");
    }

    private static void listBooks() {
        System.out.printf("%-4s %-34s %-18s %-18s %s%n", "ID", "Title", "Author", "Category", "Available");
        for (Book b : service.getBooks()) {
            System.out.printf("%-4d %-34s %-18s %-18s %d/%d%n", b.getId(), b.getTitle(), b.getAuthor(),
                    b.getCategory(), b.getAvailableCopies(), b.getTotalCopies());
        }
    }

    private static void registerBorrower() {
        String name = ask("Name");
        String idNumber = ask("ID number");
        String email = ask("E-mail (optional)");
        String type = ask("Type " + MemberFactory.types());
        Borrower borrower = service.registerBorrower(name, idNumber, email, type);
        System.out.println("Borrower #" + borrower.getId() + " registered.");
    }

    private static void listBorrowers() {
        System.out.printf("%-4s %-20s %-12s %-10s %s%n", "ID", "Name", "ID Number", "Type", "Active loans");
        for (Borrower b : service.getBorrowers()) {
            System.out.printf("%-4d %-20s %-12s %-10s %d%n", b.getId(), b.getName(), b.getIdNumber(),
                    b.getType(), service.countActiveLoans(b));
        }
    }

    private static void borrowBook() {
        listBooks();
        int bookId = askInt("Book ID");
        listBorrowers();
        int borrowerId = askInt("Borrower ID");
        Borrowing b = service.borrow(bookId, borrowerId);
        System.out.println("Transaction #" + b.getId() + ": \"" + b.getBook().getTitle() + "\" borrowed by "
                + b.getBorrower().getName() + ". Due " + b.getDueAt().format(FORMAT) + ".");
    }

    private static void returnBook() {
        listBorrowings();
        int id = askInt("Transaction ID");
        int late = askInt("Simulated days late (0 = returned now)");
        Borrowing b = service.returnBook(id, late);
        System.out.printf("Returned \"%s\". Days overdue: %d. Fine: P%.2f%n", b.getBook().getTitle(),
                b.daysOverdue(b.getReturnedAt()), b.getFine());
    }

    private static void listBorrowings() {
        LocalDateTime now = LocalDateTime.now();
        System.out.printf("%-4s %-30s %-16s %-17s %-10s %s%n", "ID", "Book", "Borrower", "Due", "Status", "Fine");
        for (Borrowing b : service.getBorrowings()) {
            String status = b.isReturned() ? "Returned" : (b.isOverdue(now) ? "Overdue" : "Borrowed");
            System.out.printf("%-4d %-30s %-16s %-17s %-10s P%.2f%n", b.getId(), b.getBook().getTitle(),
                    b.getBorrower().getName(), b.getDueAt().format(FORMAT), status, b.getFine());
        }
    }

    private static void polymorphismDemo() {
        LibraryMember[] members = {
            MemberFactory.make("student", "Ana", "1", "", 0),
            MemberFactory.make("faculty", "Ben", "2", "", 0),
            MemberFactory.make("staff", "Cy", "3", "", 0)
        };
        for (LibraryMember m : members) {
            System.out.println(m.describe());
            System.out.printf("  Fine for 10 days late: P%.2f | for 1000 days late: P%.2f%n",
                    m.computeFine(10), m.computeFine(1000));
        }
    }
}
