package lspulibrary.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class Format {
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a", Locale.ENGLISH);
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.ENGLISH);
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("EEE, MMM d, yyyy  |  h:mm:ss a", Locale.ENGLISH);

    private Format() {
    }

    public static String dateTime(LocalDateTime value) {
        return value == null ? "-" : value.format(DATE_TIME);
    }

    public static String date(LocalDateTime value) {
        return value == null ? "-" : value.format(DATE);
    }

    public static String clockTime(LocalDateTime value) {
        return value.format(DateTimeFormatter.ofPattern("h:mm:ss a", Locale.ENGLISH));
    }

    public static String clockDate(LocalDateTime value) {
        return value.format(DateTimeFormatter.ofPattern("EEE, MMM d, yyyy", Locale.ENGLISH));
    }

    public static String clock(LocalDateTime value) {
        return value.format(CLOCK);
    }

    public static String peso(double amount) {
        return String.format(Locale.ENGLISH, "\u20B1%,.2f", amount);
    }

    public static String plural(int count, String singular) {
        return count + " " + singular + (count == 1 ? "" : "s");
    }
}
