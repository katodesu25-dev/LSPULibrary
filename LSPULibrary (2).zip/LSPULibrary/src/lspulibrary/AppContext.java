package lspulibrary;

import lspulibrary.data.LibraryRepository;
import lspulibrary.data.SampleData;
import lspulibrary.services.AuthService;
import lspulibrary.services.CirculationService;
import lspulibrary.services.ReportService;

public class AppContext {
    private final LibraryRepository repository;
    private final CirculationService circulation;
    private final ReportService reports;
    private final AuthService auth;

    private AppContext(LibraryRepository repository) {
        this.repository = repository;
        this.circulation = new CirculationService(repository);
        this.reports = new ReportService(circulation);
        this.auth = new AuthService(repository);
    }

    public static AppContext create(LibraryRepository repository) {
        AppContext context = new AppContext(repository);
        if (context.auth.ensureDefaultAdministrator()) {
            SampleData.load(repository);
        }
        return context;
    }

    public LibraryRepository getRepository() {
        return repository;
    }

    public CirculationService circulation() {
        return circulation;
    }

    public ReportService reports() {
        return reports;
    }

    public AuthService auth() {
        return auth;
    }

    public boolean isPersistent() {
        return repository.isPersistent();
    }

    public void close() {
        repository.close();
    }
}
