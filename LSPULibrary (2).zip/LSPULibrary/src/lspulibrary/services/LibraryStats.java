package lspulibrary.services;

public class LibraryStats {
    public int titles;
    public int totalCopies;
    public int availableCopies;
    public int activeLoans;
    public int borrowers;
    public int activeBorrowers;
    public int overdue;
    public int transactions;
    public int returned;
    public double totalFines;
}
