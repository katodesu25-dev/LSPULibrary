package lspulibrary.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lspulibrary.contracts.Borrowable;
import lspulibrary.data.LibraryRepository;
import lspulibrary.members.LibraryMember;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;

public class CirculationService {
    private final LibraryRepository repository;

    public CirculationService(LibraryRepository repository) {
        this.repository = repository;
    }

    public LibraryRepository getRepository() {
        return repository;
    }

    public Book addBook(String title, String author, String category, int copies) {
        return repository.saveBook(new Book(0, title, author, category, copies));
    }

    public Book updateBook(int id, String title, String author, String category, int totalCopies) {
        Book book = findBook(id);
        book.setTitle(title);
        book.setAuthor(author);
        book.setCategory(category);
        book.resizeCopies(totalCopies);
        return repository.saveBook(book);
    }

    public void deleteBook(int id) {
        Book book = findBook(id);
        for (Borrowing b : repository.findBorrowings()) {
            if (b.getBook().getId() == id && !b.isReturned()) {
                throw new IllegalStateException("\"" + book.getTitle() + "\" has copies on loan and cannot be deleted.");
            }
        }
        repository.deleteBook(id);
    }

    public Borrower registerBorrower(String name, String idNumber, String email, String type) {
        Borrower candidate = new Borrower(0, name, idNumber, email, type);
        ensureUniqueIdNumber(candidate.getIdNumber(), 0);
        return repository.saveBorrower(candidate);
    }

    public Borrower updateBorrower(int id, String name, String idNumber, String email, String type) {
        Borrower borrower = findBorrower(id);
        borrower.update(name, idNumber, email, type);
        ensureUniqueIdNumber(borrower.getIdNumber(), id);
        return repository.saveBorrower(borrower);
    }

    public void setBorrowerActive(int id, boolean active) {
        Borrower borrower = findBorrower(id);
        borrower.setActive(active);
        repository.saveBorrower(borrower);
    }

    public void deleteBorrower(int id) {
        Borrower borrower = findBorrower(id);
        if (countActiveLoans(borrower) > 0) {
            throw new IllegalStateException(borrower.getName() + " still has borrowed books and cannot be deleted.");
        }
        repository.deleteBorrower(id);
    }

    private void ensureUniqueIdNumber(String idNumber, int exceptId) {
        for (Borrower other : repository.findBorrowers()) {
            if (other.getId() != exceptId && other.getIdNumber().equalsIgnoreCase(idNumber)) {
                throw new IllegalStateException("ID number " + idNumber + " is already registered to "
                        + other.getName() + ".");
            }
        }
    }

    public Book findBook(int id) {
        Book book = repository.findBook(id);
        if (book == null) {
            throw new IllegalArgumentException("Book #" + id + " not found.");
        }
        return book;
    }

    public Borrower findBorrower(int id) {
        Borrower borrower = repository.findBorrower(id);
        if (borrower == null) {
            throw new IllegalArgumentException("Borrower #" + id + " not found.");
        }
        return borrower;
    }

    public Borrowing findBorrowing(int id) {
        Borrowing borrowing = repository.findBorrowing(id);
        if (borrowing == null) {
            throw new IllegalArgumentException("Transaction #" + id + " not found.");
        }
        return borrowing;
    }

    public List<Book> getBooks() {
        return repository.findBooks();
    }

    public List<Borrower> getBorrowers() {
        return repository.findBorrowers();
    }

    public List<Borrowing> getBorrowings() {
        return repository.findBorrowings();
    }

    public List<Borrowing> getActiveLoans() {
        List<Borrowing> list = new ArrayList<>();
        for (Borrowing b : repository.findBorrowings()) {
            if (!b.isReturned()) {
                list.add(b);
            }
        }
        return list;
    }

    public List<Borrowing> getLoansOf(Borrower borrower) {
        List<Borrowing> list = new ArrayList<>();
        for (Borrowing b : repository.findBorrowings()) {
            if (b.getBorrower().getId() == borrower.getId()) {
                list.add(b);
            }
        }
        return list;
    }

    public int countActiveLoans(Borrower borrower) {
        int count = 0;
        for (Borrowing b : repository.findBorrowings()) {
            if (b.getBorrower().getId() == borrower.getId() && !b.isReturned()) {
                count++;
            }
        }
        return count;
    }

    public LibraryMember memberOf(Borrower borrower) {
        return borrower.asMember(countActiveLoans(borrower));
    }

    public boolean hasActiveLoan(int bookId, int borrowerId) {
        for (Borrowing b : repository.findBorrowings()) {
            if (b.getBook().getId() == bookId && b.getBorrower().getId() == borrowerId && !b.isReturned()) {
                return true;
            }
        }
        return false;
    }

    public Borrowing borrow(int bookId, int borrowerId) {
        Borrower borrower = findBorrower(borrowerId);
        Book book = findBook(bookId);
        LibraryMember member = memberOf(borrower);

        if (!borrower.isActive()) {
            throw new IllegalStateException(member.getName() + " is deactivated and cannot borrow books.");
        }
        if (!member.canBorrow()) {
            throw new IllegalStateException(String.format("%s (%s) has reached the limit of %d borrowed books.",
                    member.getName(), member.getRole(), member.getBorrowLimit()));
        }
        Borrowable item = book;
        if (hasActiveLoan(bookId, borrowerId)) {
            throw new IllegalStateException(member.getName() + " already borrowed \"" + item.getTitle() + "\".");
        }

        final Borrowing[] saved = new Borrowing[1];
        repository.inTransaction(() -> {
            item.checkOut();
            repository.saveBook(book);
            LocalDateTime now = LocalDateTime.now();
            saved[0] = repository.saveBorrowing(
                    new Borrowing(0, book, borrower, now, now.plusDays(member.getLoanDays())));
        });
        return saved[0];
    }

    public Borrowing returnBook(int borrowingId, int simulatedDaysLate) {
        Borrowing borrowing = findBorrowing(borrowingId);
        LocalDateTime returnTime = LocalDateTime.now();
        if (simulatedDaysLate > 0) {
            returnTime = borrowing.getDueAt().plusDays(simulatedDaysLate);
        }
        return returnBook(borrowingId, returnTime);
    }

    public Borrowing returnBook(int borrowingId, LocalDateTime returnTime) {
        Borrowing borrowing = findBorrowing(borrowingId);
        if (borrowing.isReturned()) {
            throw new IllegalStateException("This book was already returned.");
        }
        if (returnTime.isBefore(borrowing.getBorrowedAt())) {
            throw new IllegalArgumentException("The return date cannot be earlier than the borrowing date.");
        }

        LibraryMember member = borrowing.getBorrower().asMember(0);
        double fine = member.computeFine(borrowing.daysOverdue(returnTime));
        Book book = repository.findBook(borrowing.getBook().getId());
        if (book == null) {
            throw new IllegalStateException("The book of this transaction no longer exists.");
        }

        repository.inTransaction(() -> {
            borrowing.markReturned(returnTime, fine);
            repository.saveBorrowing(borrowing);
            book.checkIn();
            repository.saveBook(book);
        });
        return borrowing;
    }

    public double previewFine(Borrowing borrowing, LocalDateTime returnTime) {
        return borrowing.getBorrower().asMember(0).computeFine(borrowing.daysOverdue(returnTime));
    }
}
