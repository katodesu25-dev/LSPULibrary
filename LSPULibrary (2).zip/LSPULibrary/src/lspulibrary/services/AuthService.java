package lspulibrary.services;

import lspulibrary.data.LibraryRepository;
import lspulibrary.models.Administrator;

public class AuthService {
    public static final String DEFAULT_USERNAME = "admin";
    public static final String DEFAULT_PASSWORD = "admin123";
    public static final int MIN_PASSWORD_LENGTH = 6;

    private final LibraryRepository repository;

    public AuthService(LibraryRepository repository) {
        this.repository = repository;
    }

    public boolean ensureDefaultAdministrator() {
        if (repository.hasAdministrators()) {
            return false;
        }
        String salt = PasswordHasher.newSalt();
        String hash = PasswordHasher.hash(DEFAULT_PASSWORD.toCharArray(), salt);
        repository.saveAdministrator(new Administrator(0, DEFAULT_USERNAME, "System Administrator",
                "Library Administrator", salt, hash));
        return true;
    }

    public Administrator login(String username, char[] password) {
        if (username == null || username.trim().isEmpty() || password == null || password.length == 0) {
            throw new IllegalArgumentException("Enter your username and password.");
        }
        Administrator admin = repository.findAdministrator(username.trim());
        if (admin == null || !PasswordHasher.matches(password, admin.getSalt(), admin.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid username or password.");
        }
        return admin;
    }

    public void updateFullName(Administrator admin, String fullName) {
        admin.setFullName(fullName);
        repository.saveAdministrator(admin);
    }

    public void changePassword(Administrator admin, char[] current, char[] replacement, char[] confirmation) {
        if (!PasswordHasher.matches(current, admin.getSalt(), admin.getPasswordHash())) {
            throw new IllegalArgumentException("The current password is incorrect.");
        }
        if (replacement.length < MIN_PASSWORD_LENGTH) {
            throw new IllegalArgumentException("The new password must be at least " + MIN_PASSWORD_LENGTH
                    + " characters long.");
        }
        if (!new String(replacement).equals(new String(confirmation))) {
            throw new IllegalArgumentException("The new password and its confirmation do not match.");
        }
        String salt = PasswordHasher.newSalt();
        admin.setCredentials(salt, PasswordHasher.hash(replacement, salt));
        repository.saveAdministrator(admin);
    }
}
