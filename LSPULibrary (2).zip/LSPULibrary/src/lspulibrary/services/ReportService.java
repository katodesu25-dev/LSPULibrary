package lspulibrary.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import lspulibrary.models.Book;
import lspulibrary.models.Borrower;
import lspulibrary.models.Borrowing;

public class ReportService {
    private final CirculationService circulation;

    public ReportService(CirculationService circulation) {
        this.circulation = circulation;
    }

    public LibraryStats snapshot() {
        LocalDateTime now = LocalDateTime.now();
        LibraryStats s = new LibraryStats();
        List<Book> books = circulation.getBooks();
        s.titles = books.size();
        for (Book b : books) {
            s.totalCopies += b.getTotalCopies();
            s.availableCopies += b.getAvailableCopies();
        }
        s.borrowers = circulation.getBorrowers().size();
        Set<Integer> borrowing = new HashSet<>();
        for (Borrowing b : circulation.getBorrowings()) {
            s.transactions++;
            s.totalFines += b.getFine();
            if (b.isReturned()) {
                s.returned++;
            } else {
                s.activeLoans++;
                borrowing.add(b.getBorrower().getId());
                if (b.isOverdue(now)) {
                    s.overdue++;
                }
            }
        }
        s.activeBorrowers = borrowing.size();
        return s;
    }

    public List<Map.Entry<String, Integer>> mostBorrowed(int limit) {
        Map<String, Integer> counts = new HashMap<>();
        for (Borrowing b : circulation.getBorrowings()) {
            counts.merge(b.getBook().getTitle(), 1, Integer::sum);
        }
        List<Map.Entry<String, Integer>> list = new ArrayList<>(counts.entrySet());
        list.sort((a, b) -> {
            int c = Integer.compare(b.getValue(), a.getValue());
            return c != 0 ? c : a.getKey().compareToIgnoreCase(b.getKey());
        });
        return new ArrayList<>(list.subList(0, Math.min(limit, list.size())));
    }

    public Map<String, int[]> activityLastDays(int days) {
        Map<LocalDate, int[]> byDay = new LinkedHashMap<>();
        LocalDate today = LocalDate.now();
        for (int i = days - 1; i >= 0; i--) {
            byDay.put(today.minusDays(i), new int[2]);
        }
        for (Borrowing b : circulation.getBorrowings()) {
            int[] borrowedDay = byDay.get(b.getBorrowedAt().toLocalDate());
            if (borrowedDay != null) {
                borrowedDay[0]++;
            }
            if (b.isReturned()) {
                int[] returnedDay = byDay.get(b.getReturnedAt().toLocalDate());
                if (returnedDay != null) {
                    returnedDay[1]++;
                }
            }
        }
        Map<String, int[]> labelled = new LinkedHashMap<>();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("EEE d", Locale.ENGLISH);
        for (Map.Entry<LocalDate, int[]> e : byDay.entrySet()) {
            labelled.put(e.getKey().format(fmt), e.getValue());
        }
        return labelled;
    }

    public Map<String, Integer> borrowingsByMonth(int months) {
        Map<YearMonth, Integer> byMonth = new LinkedHashMap<>();
        YearMonth current = YearMonth.now();
        for (int i = months - 1; i >= 0; i--) {
            byMonth.put(current.minusMonths(i), 0);
        }
        for (Borrowing b : circulation.getBorrowings()) {
            YearMonth ym = YearMonth.from(b.getBorrowedAt());
            if (byMonth.containsKey(ym)) {
                byMonth.merge(ym, 1, Integer::sum);
            }
        }
        Map<String, Integer> labelled = new LinkedHashMap<>();
        for (Map.Entry<YearMonth, Integer> e : byMonth.entrySet()) {
            labelled.put(e.getKey().getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH), e.getValue());
        }
        return labelled;
    }

    public Map<String, Integer> borrowingsByMemberType() {
        Map<String, Integer> counts = new LinkedHashMap<>();
        counts.put("Student", 0);
        counts.put("Faculty", 0);
        counts.put("Staff", 0);
        for (Borrowing b : circulation.getBorrowings()) {
            counts.merge(b.getBorrower().getTypeLabel(), 1, Integer::sum);
        }
        return counts;
    }

    public Map<String, Integer> statusBreakdown() {
        LocalDateTime now = LocalDateTime.now();
        Map<String, Integer> counts = new LinkedHashMap<>();
        counts.put("Borrowed", 0);
        counts.put("Overdue", 0);
        counts.put("Returned", 0);
        for (Borrowing b : circulation.getBorrowings()) {
            counts.merge(b.statusAt(now), 1, Integer::sum);
        }
        return counts;
    }

    public List<Borrowing> overdueLoans() {
        LocalDateTime now = LocalDateTime.now();
        List<Borrowing> list = new ArrayList<>();
        for (Borrowing b : circulation.getBorrowings()) {
            if (b.isOverdue(now)) {
                list.add(b);
            }
        }
        list.sort(Comparator.comparingInt((Borrowing b) -> b.daysOverdue(now)).reversed());
        return list;
    }

    public List<Borrowing> recentTransactions(int limit) {
        List<Borrowing> list = circulation.getBorrowings();
        list.sort(Comparator.comparing(Borrowing::getBorrowedAt).reversed());
        return new ArrayList<>(list.subList(0, Math.min(limit, list.size())));
    }

    public List<Map.Entry<Borrower, Integer>> activeBorrowerRanking(int limit) {
        Map<Integer, Borrower> people = new HashMap<>();
        Map<Integer, Integer> counts = new HashMap<>();
        for (Borrowing b : circulation.getBorrowings()) {
            if (!b.isReturned()) {
                people.put(b.getBorrower().getId(), b.getBorrower());
                counts.merge(b.getBorrower().getId(), 1, Integer::sum);
            }
        }
        List<Map.Entry<Borrower, Integer>> list = new ArrayList<>();
        for (Map.Entry<Integer, Integer> e : counts.entrySet()) {
            list.add(new AbstractMap.SimpleEntry<>(people.get(e.getKey()), e.getValue()));
        }
        list.sort((a, b) -> {
            int c = Integer.compare(b.getValue(), a.getValue());
            return c != 0 ? c : a.getKey().getName().compareToIgnoreCase(b.getKey().getName());
        });
        return new ArrayList<>(list.subList(0, Math.min(limit, list.size())));
    }
}
