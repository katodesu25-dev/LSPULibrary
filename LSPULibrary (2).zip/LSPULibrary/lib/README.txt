Put these two files in this folder (download from Maven Central):

  sqlite-jdbc-3.46.0.0.jar
  https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.46.0.0/sqlite-jdbc-3.46.0.0.jar

  slf4j-api-1.7.36.jar
  https://repo1.maven.org/maven2/org/slf4j/slf4j-api/1.7.36/slf4j-api-1.7.36.jar

The program finds every .jar in this folder automatically when it starts.
You do not have to edit the Eclipse build path (but adding them there also works).
