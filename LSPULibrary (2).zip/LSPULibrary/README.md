# LSPU Library Borrowing Management System (Java Swing + SQLite)

Desktop version of the Library Borrowing Management System.
Java 11 or newer is required (Eclipse with JavaSE-11, 17 or 21 works).

## 1. Set up in Eclipse

1. Download the two jar files listed in `lib/README.txt` and copy them into the `lib` folder of this project.
2. File > Import > General > Existing Projects into Workspace > select the `LSPULibrary` folder > Finish.
3. Right-click the project > Refresh (F5) so Eclipse sees the new files.
4. Open `src/lspulibrary/Main.java`, right-click > Run As > Java Application.

Sign in with:  username `admin`   password `admin123`  (change it in Settings).

The first run creates `data/lspu_library.db` and loads sample books, borrowers and transactions
so the dashboard is not empty. Use Settings > Reset All Data to start with an empty library.

If the jars are missing, the program tells you and can continue with temporary data
(nothing is saved). Add the jars and run again to use the real database.

## 2. Project structure

    src/lspulibrary/
      Main.java                 starts the GUI (run this)
      ConsoleApp.java           the original console version, still working
      AppContext.java           wires repository and services together
      contracts/                Borrowable (interface)
      members/                  Person > LibraryMember > Student / Faculty / Staff, MemberFactory
      models/                   Book, Borrower, Borrowing, Administrator
      data/                     LibraryRepository, SqliteLibraryRepository, InMemoryLibraryRepository,
                                Sql (schema and queries), SqliteConnector, SampleData
      services/                 CirculationService (borrow/return rules), ReportService, AuthService
      ui/                       login, main window, sidebar, top bar, theme, icons, dialogs
      ui/panels/                Dashboard, Books, Borrowers, Borrow, Return, Transactions, Reports, Settings
      ui/components/            buttons, fields, tables, stat cards and charts (all drawn with Java2D)
      ui/dialogs/               add/edit forms and detail windows

## 3. OOP concepts kept from the original project

* Abstraction: `Borrowable`, abstract `Person` and `LibraryMember`.
* Encapsulation: private fields with validated setters; copies change only through `checkOut`, `checkIn`, `resizeCopies`.
* Inheritance: `Person` > `LibraryMember` > `StudentMember`, `FacultyMember`, `StaffMember`.
* Polymorphism: every member type overrides `getBorrowLimit`, `getLoanDays`, `getFinePerDay`;
  `StaffMember` also overrides `computeFine` (P100 cap). The services and screens only use `LibraryMember`.

## 4. Borrowing rules

| Member  | Max books | Loan days | Fine per day | Cap   |
|---------|-----------|-----------|--------------|-------|
| Student | 3         | 7         | P5.00        | none  |
| Faculty | 10        | 30        | P2.00        | none  |
| Staff   | 5         | 14        | P3.00        | P100  |

Overdue days are counted per started day after the due time. A borrower cannot hold the same book twice,
cannot borrow while deactivated, and cannot borrow when no copy is available.

## 5. Database tables (SQLite)

`books`, `borrowers`, `borrowings` (foreign keys to books and borrowers) and `administrators`.
Books and borrowers are soft-deleted so past transactions keep their names. A unique index blocks duplicate
school ID numbers and a second active loan of the same book by the same borrower. Admin passwords are stored
as salted PBKDF2 hashes.

## 6. Notes

* The Return screen has a "Return date" field. Leave it as today for normal returns; pick a later date to
  record a late return or to try the fine calculation.
* Transactions can be exported to CSV from the Borrowing Transactions page.
* The window is resizable (minimum about 1100 x 680).
